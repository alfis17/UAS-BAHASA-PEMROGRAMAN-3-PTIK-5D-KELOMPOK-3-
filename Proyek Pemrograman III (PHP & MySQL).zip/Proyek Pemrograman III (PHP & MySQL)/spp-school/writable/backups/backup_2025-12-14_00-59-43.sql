-- Database Backup
-- Generated: 2025-12-14 01:01:37
-- Tables: backups, kelas, logs, migrations, pembayaran, settings, siswa, spp, users


-- Table structure for table `backups`
DROP TABLE IF EXISTS `backups`;
CREATE TABLE `backups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'full',
  `description` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `kelas`
DROP TABLE IF EXISTS `kelas`;
CREATE TABLE `kelas` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nama_kelas` varchar(50) NOT NULL,
  `tingkat` enum('X','XI','XII') NOT NULL DEFAULT 'X',
  `jurusan` varchar(50) NOT NULL,
  `wali_kelas` varchar(100) DEFAULT NULL,
  `kapasitas` int(3) unsigned NOT NULL DEFAULT 40,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_kelas_unique` (`nama_kelas`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `kelas`
INSERT INTO `kelas` VALUES ('25', 'X MIPA 1', 'X', 'IPA', 'Fauzan Ikhwan', '30', '2025-12-06 09:53:38', '2025-12-06 09:54:59');
INSERT INTO `kelas` VALUES ('26', 'XI MIPA 1', 'XI', 'IPA', 'Wahyu Dwi', '34', '2025-12-06 09:54:51', '2025-12-07 08:45:45');
INSERT INTO `kelas` VALUES ('27', 'XII MIPA 1', 'XII', 'IPA', 'alfis', '30', '2025-12-06 09:55:22', '2025-12-06 09:55:22');


-- Table structure for table `logs`
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_type` (`action_type`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `migrations`
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `migrations`
INSERT INTO `migrations` VALUES ('1', '2025-12-06-053518', 'App\\Database\\Migrations\\CreateUsersTable', 'default', 'App', '1764999458', '1');
INSERT INTO `migrations` VALUES ('2', '2025-12-06-053539', 'App\\Database\\Migrations\\CreateKelasTable', 'default', 'App', '1764999458', '1');
INSERT INTO `migrations` VALUES ('3', '2025-12-06-053549', 'App\\Database\\Migrations\\CreateSiswaTable', 'default', 'App', '1764999458', '1');
INSERT INTO `migrations` VALUES ('4', '2025-12-06-053559', 'App\\Database\\Migrations\\CreateSPPTable', 'default', 'App', '1764999458', '1');
INSERT INTO `migrations` VALUES ('5', '2025-12-06-053608', 'App\\Database\\Migrations\\CreatePembayaranTable', 'default', 'App', '1764999458', '1');
INSERT INTO `migrations` VALUES ('6', '2025-12-14-005126', 'App\\Database\\Migrations\\CreateAdminTables', 'default', 'App', '1765673641', '2');


-- Table structure for table `pembayaran`
DROP TABLE IF EXISTS `pembayaran`;
CREATE TABLE `pembayaran` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_siswa` int(11) unsigned NOT NULL,
  `id_spp` int(11) unsigned DEFAULT NULL,
  `bulan` enum('Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember') NOT NULL,
  `tahun` year(4) NOT NULL,
  `tanggal_bayar` date NOT NULL,
  `jumlah_bayar` decimal(12,2) NOT NULL DEFAULT 0.00,
  `metode_pembayaran` enum('Tunai','Transfer','QRIS') NOT NULL DEFAULT 'Tunai',
  `keterangan` text DEFAULT NULL,
  `id_user` int(11) unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pembayaran_id_siswa_foreign` (`id_siswa`),
  KEY `pembayaran_id_spp_foreign` (`id_spp`),
  KEY `pembayaran_id_user_foreign` (`id_user`),
  KEY `idx_bulan_tahun` (`bulan`,`tahun`),
  CONSTRAINT `pembayaran_id_siswa_foreign` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pembayaran_id_spp_foreign` FOREIGN KEY (`id_spp`) REFERENCES `spp` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pembayaran_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `settings`
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `key` varchar(100) NOT NULL,
  `value` text NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'string',
  `group` varchar(50) NOT NULL DEFAULT 'general',
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `settings`
INSERT INTO `settings` VALUES ('school_name', 'Sekolah Menengah Atas Negeri 1', 'string', 'general', NULL);
INSERT INTO `settings` VALUES ('academic_year', '2025/2026', 'string', 'general', NULL);
INSERT INTO `settings` VALUES ('due_date', '10', 'integer', 'payment', NULL);
INSERT INTO `settings` VALUES ('late_fee', '10000', 'integer', 'payment', NULL);
INSERT INTO `settings` VALUES ('notify_payment', '1', 'boolean', 'notification', NULL);


-- Table structure for table `siswa`
DROP TABLE IF EXISTS `siswa`;
CREATE TABLE `siswa` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nisn` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nama_siswa` varchar(150) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL DEFAULT 'L',
  `tempat_lahir` varchar(100) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `id_kelas` int(11) unsigned DEFAULT NULL,
  `tahun_masuk` year(4) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nisn` (`nisn`),
  KEY `siswa_id_kelas_foreign` (`id_kelas`),
  CONSTRAINT `siswa_id_kelas_foreign` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `siswa`
INSERT INTO `siswa` VALUES ('10', '1234567890', '$2y$10$1kxAzSWqXcW59DC1FhkKpe7bFrMy4.y10u9qAOPFBqHyTf.e20M86', 'Muhammad Alfis Azis', 'L', 'Batusangkar', '2025-12-26', 'bkt', '082299129507', '25', '2025', '2025-12-13 15:06:46', '2025-12-13 23:38:04', '2025-12-13 23:38:04');


-- Table structure for table `spp`
DROP TABLE IF EXISTS `spp`;
CREATE TABLE `spp` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tahun_ajaran` varchar(9) NOT NULL,
  `tingkat` enum('X','XI','XII') NOT NULL,
  `nominal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(150) NOT NULL,
  `role` enum('admin','petugas') NOT NULL DEFAULT 'petugas',
  `remember_token` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `users`
INSERT INTO `users` VALUES ('6', 'admin', 'alfis@gmail.com', '$2y$10$dBlbgvtqzzVhWLoOJskWPOJGLN.JsrSIU7wHxOgKMmVcZfN/l7E/m', 'admin', 'admin', NULL, '2025-12-14 00:26:13', 'active', '2025-12-13 16:23:59', '2025-12-14 00:26:13');

