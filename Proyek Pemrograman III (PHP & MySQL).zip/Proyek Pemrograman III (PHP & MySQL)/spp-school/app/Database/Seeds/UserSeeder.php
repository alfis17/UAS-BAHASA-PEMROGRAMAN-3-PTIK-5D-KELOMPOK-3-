<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'username' => 'admin',
                'email' => 'admin@spp.com',
                'password' => password_hash('admin123', PASSWORD_DEFAULT),
                'nama_lengkap' => 'Administrator Sistem',
                'role' => 'admin',
                'created_at' => date('Y-m-d H:i:s'),
            ],
            [
                'username' => 'petugas1',
                'email' => 'petugas@spp.com',
                'password' => password_hash('petugas123', PASSWORD_DEFAULT),
                'nama_lengkap' => 'Petugas Administrasi',
                'role' => 'petugas',
                'created_at' => date('Y-m-d H:i:s'),
            ],
        ];
        
        $this->db->table('users')->insertBatch($data);
    }
}