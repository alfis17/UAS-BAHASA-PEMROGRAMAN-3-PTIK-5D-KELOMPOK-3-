<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSiswaTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'nisn' => [
                'type' => 'VARCHAR',
                'constraint' => 20,
                'unique' => true,
            ],
            'nama_siswa' => [
                'type' => 'VARCHAR',
                'constraint' => 150,
            ],
            'jenis_kelamin' => [
                'type' => 'ENUM',
                'constraint' => ['L', 'P'],
                'default' => 'L',
            ],
            'tempat_lahir' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'tanggal_lahir' => [
                'type' => 'DATE',
            ],
            'alamat' => [
                'type' => 'TEXT',
            ],
            'no_hp' => [
                'type' => 'VARCHAR',
                'constraint' => 15,
            ],
            'id_kelas' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'null' => true,
            ],
            'tahun_masuk' => [
                'type' => 'YEAR',
                'constraint' => 4,
            ],
            'password' => [ // TAMBAHKAN FIELD PASSWORD
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true,
            ],
            'remember_token' => [ // TAMBAHKAN FIELD REMEMBER_TOKEN
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true,
            ],
            'last_login' => [ // TAMBAHKAN FIELD LAST_LOGIN
                'type' => 'DATETIME',
                'null' => true,
            ],
            'status' => [ // TAMBAHKAN FIELD STATUS
                'type' => 'ENUM',
                'constraint' => ['active', 'inactive', 'suspended'],
                'default' => 'active',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('id_kelas', 'kelas', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('siswa', true);
    }

    public function down()
    {
        $this->forge->dropTable('siswa');
    }
}