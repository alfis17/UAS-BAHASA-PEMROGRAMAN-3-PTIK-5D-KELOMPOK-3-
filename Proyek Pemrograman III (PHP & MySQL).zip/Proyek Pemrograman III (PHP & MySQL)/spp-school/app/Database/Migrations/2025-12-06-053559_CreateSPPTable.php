<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

class CreateSPPTable extends Migration
{
    public function up()
    {
        // Enable foreign key checks
        $this->db->query('SET FOREIGN_KEY_CHECKS=0');
        
        // Drop table if exists
        if ($this->db->tableExists('spp')) {
            // Drop foreign keys first
            $this->dropForeignKeys();
            
            // Drop table
            $this->forge->dropTable('spp', true);
        }
        
        // Create spp table with proper structure
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'tahun_ajaran' => [
                'type' => 'VARCHAR',
                'constraint' => 9,
                'null' => false,
                'comment' => 'Format: YYYY/YYYY (Contoh: 2023/2024)'
            ],
            'tingkat' => [
                'type' => 'ENUM',
                'constraint' => ['X', 'XI', 'XII'],
                'null' => false,
                'default' => 'X',
                'comment' => 'Tingkat kelas (X, XI, XII)'
            ],
            'nominal' => [
                'type' => 'DECIMAL',
                'constraint' => '15,2',
                'null' => false,
                'default' => 0.00,
                'comment' => 'Nominal SPP per bulan dalam Rupiah'
            ],
            'keterangan' => [
                'type' => 'TEXT',
                'null' => true,
                'comment' => 'Keterangan tambahan (opsional)'
            ],
            'status' => [
                'type' => 'ENUM',
                'constraint' => ['aktif', 'nonaktif', 'arsip'],
                'null' => false,
                'default' => 'aktif',
                'comment' => 'Status data SPP'
            ],
            'created_by' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'null' => true,
                'comment' => 'ID user yang membuat data'
            ],
            'updated_by' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'null' => true,
                'comment' => 'ID user yang terakhir mengupdate data'
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => false,
                'default' => new RawSql('CURRENT_TIMESTAMP'),
                'comment' => 'Waktu data dibuat'
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => false,
                'default' => new RawSql('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
                'comment' => 'Waktu data terakhir diupdate'
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
                'comment' => 'Waktu data dihapus (soft delete)'
            ]
        ]);
        
        // Add primary key
        $this->forge->addPrimaryKey('id');
        
        // Add unique key constraint untuk tahun_ajaran dan tingkat
        $this->forge->addUniqueKey(['tahun_ajaran', 'tingkat'], 'unique_tahun_tingkat');
        
        // Add indexes for performance
        $this->forge->addKey('tahun_ajaran', false, false, 'idx_tahun_ajaran');
        $this->forge->addKey('tingkat', false, false, 'idx_tingkat');
        $this->forge->addKey('status', false, false, 'idx_status');
        $this->forge->addKey('created_at', false, false, 'idx_created_at');
        $this->forge->addKey('updated_at', false, false, 'idx_updated_at');
        $this->forge->addKey('created_by', false, false, 'idx_created_by');
        $this->forge->addKey('updated_by', false, false, 'idx_updated_by');
        
        // Add table attributes
        $attributes = [
            'ENGINE' => 'InnoDB',
            'CHARSET' => 'utf8mb4',
            'COLLATE' => 'utf8mb4_unicode_ci',
            'COMMENT' => 'Tabel data SPP (Sumbangan Pembinaan Pendidikan)'
        ];
        
        // Create table
        $this->forge->createTable('spp', true, $attributes);
        
        // Create activity_logs table for logging
        $this->createActivityLogsTable();
        
        // Create triggers for logging changes
        $this->createTriggers();
        
        // Insert sample data
        $this->insertSampleData();
        
        // Insert reference data
        $this->insertReferenceData();
        
        // Enable foreign key checks
        $this->db->query('SET FOREIGN_KEY_CHECKS=1');
    }

    public function down()
    {
        // Enable foreign key checks
        $this->db->query('SET FOREIGN_KEY_CHECKS=0');
        
        // Drop triggers first
        $this->dropTriggers();
        
        // Drop tables
        $this->forge->dropTable('spp', true);
        $this->forge->dropTable('activity_logs', true);
        
        // Re-enable foreign key checks
        $this->db->query('SET FOREIGN_KEY_CHECKS=1');
    }
    
    /**
     * Drop existing foreign keys
     */
    private function dropForeignKeys()
    {
        $foreignKeys = [
            'spp_created_by_foreign',
            'spp_updated_by_foreign'
        ];
        
        foreach ($foreignKeys as $foreignKey) {
            $sql = "ALTER TABLE spp DROP FOREIGN KEY IF EXISTS `{$foreignKey}`";
            $this->db->query($sql);
        }
    }
    
    /**
     * Create activity logs table
     */
    private function createActivityLogsTable()
    {
        if ($this->db->tableExists('activity_logs')) {
            $this->forge->dropTable('activity_logs', true);
        }
        
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'user_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'null' => true,
                'comment' => 'ID user yang melakukan aktivitas'
            ],
            'username' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
                'null' => true,
                'comment' => 'Username user'
            ],
            'module' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
                'null' => false,
                'comment' => 'Module/controller yang diakses'
            ],
            'activity' => [
                'type' => 'TEXT',
                'null' => false,
                'comment' => 'Deskripsi aktivitas'
            ],
            'data_before' => [
                'type' => 'TEXT',
                'null' => true,
                'comment' => 'Data sebelum perubahan (JSON format)'
            ],
            'data_after' => [
                'type' => 'TEXT',
                'null' => true,
                'comment' => 'Data setelah perubahan (JSON format)'
            ],
            'ip_address' => [
                'type' => 'VARCHAR',
                'constraint' => 45,
                'null' => true,
                'comment' => 'IP address user'
            ],
            'user_agent' => [
                'type' => 'TEXT',
                'null' => true,
                'comment' => 'User agent browser'
            ],
            'request_method' => [
                'type' => 'VARCHAR',
                'constraint' => 10,
                'null' => true,
                'comment' => 'HTTP request method (GET, POST, etc)'
            ],
            'request_url' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true,
                'comment' => 'URL yang diakses'
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => false,
                'default' => new RawSql('CURRENT_TIMESTAMP'),
                'comment' => 'Waktu aktivitas'
            ]
        ]);
        
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey('user_id', false, false, 'idx_user_id');
        $this->forge->addKey('username', false, false, 'idx_username');
        $this->forge->addKey('module', false, false, 'idx_module');
        $this->forge->addKey('created_at', false, false, 'idx_created_at');
        
        $attributes = [
            'ENGINE' => 'InnoDB',
            'CHARSET' => 'utf8mb4',
            'COLLATE' => 'utf8mb4_unicode_ci',
            'COMMENT' => 'Tabel log aktivitas sistem'
        ];
        
        $this->forge->createTable('activity_logs', true, $attributes);
    }
    
    /**
     * Create database triggers for automatic logging
     */
    private function createTriggers()
    {
        // Trigger untuk log INSERT
        $insertTrigger = "
        CREATE TRIGGER spp_after_insert 
        AFTER INSERT ON spp 
        FOR EACH ROW 
        BEGIN
            INSERT INTO activity_logs (
                user_id, 
                username, 
                module, 
                activity, 
                data_after, 
                request_method,
                created_at
            ) VALUES (
                NEW.created_by,
                (SELECT username FROM users WHERE id = NEW.created_by LIMIT 1),
                'spp',
                CONCAT('Menambahkan data SPP: ', NEW.tahun_ajaran, ' - Kelas ', NEW.tingkat),
                JSON_OBJECT(
                    'id', NEW.id,
                    'tahun_ajaran', NEW.tahun_ajaran,
                    'tingkat', NEW.tingkat,
                    'nominal', NEW.nominal,
                    'status', NEW.status,
                    'created_by', NEW.created_by
                ),
                'POST',
                NOW()
            );
        END";
        
        // Trigger untuk log UPDATE
        $updateTrigger = "
        CREATE TRIGGER spp_after_update 
        AFTER UPDATE ON spp 
        FOR EACH ROW 
        BEGIN
            IF OLD.nominal != NEW.nominal OR OLD.status != NEW.status THEN
                INSERT INTO activity_logs (
                    user_id, 
                    username, 
                    module, 
                    activity, 
                    data_before, 
                    data_after, 
                    request_method,
                    created_at
                ) VALUES (
                    NEW.updated_by,
                    (SELECT username FROM users WHERE id = NEW.updated_by LIMIT 1),
                    'spp',
                    CONCAT('Memperbarui data SPP ID: ', NEW.id, ' - ', NEW.tahun_ajaran, ' - Kelas ', NEW.tingkat),
                    JSON_OBJECT(
                        'id', OLD.id,
                        'tahun_ajaran', OLD.tahun_ajaran,
                        'tingkat', OLD.tingkat,
                        'nominal', OLD.nominal,
                        'status', OLD.status,
                        'updated_by', OLD.updated_by
                    ),
                    JSON_OBJECT(
                        'id', NEW.id,
                        'tahun_ajaran', NEW.tahun_ajaran,
                        'tingkat', NEW.tingkat,
                        'nominal', NEW.nominal,
                        'status', NEW.status,
                        'updated_by', NEW.updated_by
                    ),
                    'POST',
                    NOW()
                );
            END IF;
        END";
        
        // Trigger untuk log DELETE
        $deleteTrigger = "
        CREATE TRIGGER spp_before_delete 
        BEFORE DELETE ON spp 
        FOR EACH ROW 
        BEGIN
            INSERT INTO activity_logs (
                user_id, 
                username, 
                module, 
                activity, 
                data_before, 
                request_method,
                created_at
            ) VALUES (
                OLD.updated_by,
                (SELECT username FROM users WHERE id = OLD.updated_by LIMIT 1),
                'spp',
                CONCAT('Menghapus data SPP ID: ', OLD.id, ' - ', OLD.tahun_ajaran, ' - Kelas ', OLD.tingkat),
                JSON_OBJECT(
                    'id', OLD.id,
                    'tahun_ajaran', OLD.tahun_ajaran,
                    'tingkat', OLD.tingkat,
                    'nominal', OLD.nominal,
                    'status', OLD.status
                ),
                'DELETE',
                NOW()
            );
        END";
        
        try {
            $this->db->query("DROP TRIGGER IF EXISTS spp_after_insert");
            $this->db->query("DROP TRIGGER IF EXISTS spp_after_update");
            $this->db->query("DROP TRIGGER IF EXISTS spp_before_delete");
            
            $this->db->query($insertTrigger);
            $this->db->query($updateTrigger);
            $this->db->query($deleteTrigger);
            
        } catch (\Exception $e) {
            log_message('error', 'Error creating triggers: ' . $e->getMessage());
        }
    }
    
    /**
     * Drop triggers
     */
    private function dropTriggers()
    {
        try {
            $this->db->query("DROP TRIGGER IF EXISTS spp_after_insert");
            $this->db->query("DROP TRIGGER IF EXISTS spp_after_update");
            $this->db->query("DROP TRIGGER IF EXISTS spp_before_delete");
        } catch (\Exception $e) {
            log_message('error', 'Error dropping triggers: ' . $e->getMessage());
        }
    }
    
    /**
     * Insert sample data
     */
    private function insertSampleData()
    {
        $sampleData = [
            [
                'tahun_ajaran' => '2024/2025',
                'tingkat' => 'X',
                'nominal' => 500000.00,
                'keterangan' => 'SPP Tahun Ajaran 2024/2025 untuk Kelas X',
                'status' => 'aktif',
                'created_by' => 1,
                'updated_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2024/2025',
                'tingkat' => 'XI',
                'nominal' => 550000.00,
                'keterangan' => 'SPP Tahun Ajaran 2024/2025 untuk Kelas XI',
                'status' => 'aktif',
                'created_by' => 1,
                'updated_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2024/2025',
                'tingkat' => 'XII',
                'nominal' => 600000.00,
                'keterangan' => 'SPP Tahun Ajaran 2024/2025 untuk Kelas XII',
                'status' => 'aktif',
                'created_by' => 1,
                'updated_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2023/2024',
                'tingkat' => 'X',
                'nominal' => 450000.00,
                'keterangan' => 'SPP Tahun Ajaran 2023/2024 untuk Kelas X',
                'status' => 'arsip',
                'created_by' => 1,
                'updated_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2023/2024',
                'tingkat' => 'XI',
                'nominal' => 500000.00,
                'keterangan' => 'SPP Tahun Ajaran 2023/2024 untuk Kelas XI',
                'status' => 'arsip',
                'created_by' => 1,
                'updated_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2023/2024',
                'tingkat' => 'XII',
                'nominal' => 550000.00,
                'keterangan' => 'SPP Tahun Ajaran 2023/2024 untuk Kelas XII',
                'status' => 'arsip',
                'created_by' => 1,
                'updated_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2022/2023',
                'tingkat' => 'X',
                'nominal' => 400000.00,
                'keterangan' => 'SPP Tahun Ajaran 2022/2023 untuk Kelas X',
                'status' => 'arsip',
                'created_by' => 1,
                'updated_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2022/2023',
                'tingkat' => 'XI',
                'nominal' => 450000.00,
                'keterangan' => 'SPP Tahun Ajaran 2022/2023 untuk Kelas XI',
                'status' => 'arsip',
                'created_by' => 1,
                'updated_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2022/2023',
                'tingkat' => 'XII',
                'nominal' => 500000.00,
                'keterangan' => 'SPP Tahun Ajaran 2022/2023 untuk Kelas XII',
                'status' => 'arsip',
                'created_by' => 1,
                'updated_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]
        ];
        
        $this->db->table('spp')->insertBatch($sampleData);
    }
    
    /**
     * Insert reference data (tahun ajaran, bulan, dll)
     */
    private function insertReferenceData()
    {
        // Insert tahun ajaran reference
        $tahunAjaran = [
            ['tahun' => '2024/2025', 'status' => 'aktif'],
            ['tahun' => '2023/2024', 'status' => 'selesai'],
            ['tahun' => '2022/2023', 'status' => 'selesai'],
            ['tahun' => '2021/2022', 'status' => 'selesai']
        ];
        
        // Insert bulan reference
        $bulan = [
            ['kode' => '01', 'nama' => 'Januari', 'nama_pendek' => 'Jan'],
            ['kode' => '02', 'nama' => 'Februari', 'nama_pendek' => 'Feb'],
            ['kode' => '03', 'nama' => 'Maret', 'nama_pendek' => 'Mar'],
            ['kode' => '04', 'nama' => 'April', 'nama_pendek' => 'Apr'],
            ['kode' => '05', 'nama' => 'Mei', 'nama_pendek' => 'Mei'],
            ['kode' => '06', 'nama' => 'Juni', 'nama_pendek' => 'Jun'],
            ['kode' => '07', 'nama' => 'Juli', 'nama_pendek' => 'Jul'],
            ['kode' => '08', 'nama' => 'Agustus', 'nama_pendek' => 'Agu'],
            ['kode' => '09', 'nama' => 'September', 'nama_pendek' => 'Sep'],
            ['kode' => '10', 'nama' => 'Oktober', 'nama_pendek' => 'Okt'],
            ['kode' => '11', 'nama' => 'November', 'nama_pendek' => 'Nov'],
            ['kode' => '12', 'nama' => 'Desember', 'nama_pendek' => 'Des']
        ];
        
        // Insert initial activity log
        $this->db->table('activity_logs')->insert([
            'user_id' => 1,
            'username' => 'admin',
            'module' => 'system',
            'activity' => 'Migrasi database dan setup data awal SPP berhasil',
            'data_after' => json_encode(['table' => 'spp', 'records' => 9]),
            'ip_address' => '127.0.0.1',
            'user_agent' => 'CodeIgniter Migration',
            'request_method' => 'CLI',
            'request_url' => '/migrate',
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
}