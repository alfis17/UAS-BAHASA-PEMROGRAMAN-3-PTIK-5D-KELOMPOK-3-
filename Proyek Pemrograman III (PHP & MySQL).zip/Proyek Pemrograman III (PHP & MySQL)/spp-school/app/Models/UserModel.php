<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'username', 'email', 'password', 'nama_lengkap', 'role',
        'remember_token', 'last_login',
        'foto_profil', 'no_telepon', 'alamat',
        'created_at', 'updated_at'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation
    protected $validationRules = [
        'username' => 'required|min_length[3]|max_length[100]|is_unique[users.username,id,{id}]',
        'email' => 'required|valid_email|max_length[100]|is_unique[users.email,id,{id}]',
        'password' => 'required|min_length[6]',
        'nama_lengkap' => 'required|max_length[150]',
        'role' => 'required|in_list[admin,petugas]',
    ];

    protected $validationMessages = [
        'username' => [
            'required' => 'Username harus diisi',
            'min_length' => 'Username minimal 3 karakter',
            'max_length' => 'Username maksimal 100 karakter',
            'is_unique' => 'Username sudah digunakan'
        ],
        'email' => [
            'required' => 'Email harus diisi',
            'valid_email' => 'Email tidak valid',
            'max_length' => 'Email maksimal 100 karakter',
            'is_unique' => 'Email sudah digunakan'
        ],
        'password' => [
            'required' => 'Password harus diisi',
            'min_length' => 'Password minimal 6 karakter'
        ],
        'nama_lengkap' => [
            'required' => 'Nama lengkap harus diisi',
            'max_length' => 'Nama lengkap maksimal 150 karakter'
        ],
        'role' => [
            'required' => 'Role harus dipilih',
            'in_list' => 'Role tidak valid'
        ]
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert = ['hashPassword'];
    protected $beforeUpdate = ['hashPassword'];

    protected function hashPassword(array $data)
    {
        if (isset($data['data']['password']) && !empty($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }
        return $data;
    }

    /**
     * Verify password
     */
    public function verifyPassword($password, $hashedPassword)
    {
        return password_verify($password, $hashedPassword);
    }

    /**
     * Update last login timestamp
     */
    public function updateLastLogin($userId)
    {
        return $this->update($userId, [
            'last_login' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Find user by username or email
     */
    public function findByUsernameOrEmail($identifier)
    {
        return $this->where('username', $identifier)
                    ->orWhere('email', $identifier)
                    ->first();
    }

    /**
     * Update remember token
     */
    public function updateRememberToken($userId, $token)
    {
        return $this->update($userId, [
            'remember_token' => $token,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Find user by remember token
     */
    public function findByRememberToken($token)
    {
        return $this->where('remember_token', $token)->first();
    }

    /**
     * Get user statistics
     */
    public function getUserStats()
    {
        $totalUsers = $this->countAllResults();
        
        $adminUsers = $this->where('role', 'admin')->countAllResults();
        $petugasUsers = $this->where('role', 'petugas')->countAllResults();
        
        // Last 7 days registration
        $sevenDaysAgo = date('Y-m-d', strtotime('-7 days'));
        $newUsers = $this->where('created_at >=', $sevenDaysAgo)
                         ->countAllResults();
        
        // Last login statistics
        $today = date('Y-m-d');
        $loggedToday = $this->where('DATE(last_login)', $today)->countAllResults();
        
        $thirtyDaysAgo = date('Y-m-d', strtotime('-30 days'));
        $activeLast30Days = $this->where('last_login >=', $thirtyDaysAgo)
                                 ->countAllResults();
        
        return [
            'total_users' => $totalUsers,
            'admin_users' => $adminUsers,
            'petugas_users' => $petugasUsers,
            'new_users_7_days' => $newUsers,
            'logged_today' => $loggedToday,
            'active_last_30_days' => $activeLast30Days,
            'activity_rate' => $totalUsers > 0 ? round(($activeLast30Days / $totalUsers) * 100, 2) : 0
        ];
    }

    /**
     * Get users with pagination
     */
    public function getUsersPaginated($perPage = 10, $search = null, $role = null)
    {
        $builder = $this->builder();
        
        if ($search) {
            $builder->groupStart()
                    ->like('username', $search)
                    ->orLike('email', $search)
                    ->orLike('nama_lengkap', $search)
                    ->groupEnd();
        }
        
        if ($role) {
            $builder->where('role', $role);
        }
        
        $builder->orderBy('created_at', 'DESC');
        
        return [
            'users' => $this->paginate($perPage),
            'pager' => $this->pager
        ];
    }

    /**
     * Get user by ID with additional info
     */
    public function getUserWithDetails($userId)
    {
        $user = $this->find($userId);
        
        if (!$user) {
            return null;
        }
        
        // Add additional calculated fields
        $user['account_age'] = $this->getAccountAge($user['created_at']);
        $user['last_login_formatted'] = $this->formatLastLogin($user['last_login']);
        
        return $user;
    }

    /**
     * Calculate account age in days
     */
    private function getAccountAge($createdAt)
    {
        if (!$createdAt) {
            return 0;
        }
        
        $created = new \DateTime($createdAt);
        $now = new \DateTime();
        $interval = $created->diff($now);
        
        return $interval->days;
    }

    /**
     * Format last login time
     */
    private function formatLastLogin($lastLogin)
    {
        if (!$lastLogin) {
            return 'Belum pernah login';
        }
        
        $lastLoginTime = new \DateTime($lastLogin);
        $now = new \DateTime();
        $interval = $lastLoginTime->diff($now);
        
        if ($interval->days > 30) {
            return $lastLoginTime->format('d M Y');
        } elseif ($interval->days > 0) {
            return $interval->days . ' hari yang lalu';
        } elseif ($interval->h > 0) {
            return $interval->h . ' jam yang lalu';
        } elseif ($interval->i > 0) {
            return $interval->i . ' menit yang lalu';
        } else {
            return 'Baru saja';
        }
    }

    /**
     * Change user role
     */
    public function changeRole($userId, $role)
    {
        $allowedRoles = ['admin', 'petugas'];
        
        if (!in_array($role, $allowedRoles)) {
            return false;
        }
        
        return $this->update($userId, [
            'role' => $role,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Change user password
     */
    public function changePassword($userId, $newPassword)
    {
        return $this->update($userId, [
            'password' => password_hash($newPassword, PASSWORD_DEFAULT),
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Check if user exists by username or email
     */
    public function userExists($username, $email, $excludeId = null)
    {
        $builder = $this->builder();
        
        $builder->groupStart()
                ->where('username', $username)
                ->orWhere('email', $email)
                ->groupEnd();
        
        if ($excludeId) {
            $builder->where('id !=', $excludeId);
        }
        
        return $builder->countAllResults() > 0;
    }

    /**
     * Get active users
     */
    public function getActiveUsers()
    {
        return $this->orderBy('nama_lengkap', 'ASC')->findAll();
    }

    /**
     * Get users by role
     */
    public function getUsersByRole($role)
    {
        return $this->where('role', $role)
                    ->orderBy('nama_lengkap', 'ASC')
                    ->findAll();
    }

    /**
     * Get recent users
     */
    public function getRecentUsers($limit = 5)
    {
        return $this->orderBy('created_at', 'DESC')
                    ->limit($limit)
                    ->findAll();
    }

    /**
     * Search users
     */
    public function searchUsers($keyword, $limit = 10)
    {
        return $this->builder()
                    ->groupStart()
                    ->like('username', $keyword)
                    ->orLike('email', $keyword)
                    ->orLike('nama_lengkap', $keyword)
                    ->orLike('no_telepon', $keyword)
                    ->orLike('alamat', $keyword)
                    ->groupEnd()
                    ->orderBy('nama_lengkap', 'ASC')
                    ->limit($limit)
                    ->get()
                    ->getResultArray();
    }

    /**
     * Export users to array for CSV/Excel
     */
    public function exportUsers($filters = [])
    {
        $builder = $this->builder();
        
        if (isset($filters['role']) && $filters['role']) {
            $builder->where('role', $filters['role']);
        }
        
        if (isset($filters['status']) && $filters['status']) {
            $builder->where('status', $filters['status']);
        }
        
        if (isset($filters['start_date']) && $filters['start_date']) {
            $builder->where('created_at >=', $filters['start_date']);
        }
        
        if (isset($filters['end_date']) && $filters['end_date']) {
            $builder->where('created_at <=', $filters['end_date']);
        }
        
        $users = $builder->orderBy('created_at', 'DESC')
                        ->get()
                        ->getResultArray();
        
        $exportData = [];
        foreach ($users as $user) {
            $exportData[] = [
                'ID' => $user['id'],
                'Username' => $user['username'],
                'Email' => $user['email'],
                'Nama Lengkap' => $user['nama_lengkap'],
                'Role' => $this->getRoleLabel($user['role']),
                'Status' => $this->getStatusLabel($user['status']),
                'Telepon' => $user['no_telepon'] ?? '',
                'Alamat' => $user['alamat'] ?? '',
                'Terakhir Login' => $user['last_login'] ? date('d/m/Y H:i', strtotime($user['last_login'])) : 'Belum login',
                'Tanggal Dibuat' => date('d/m/Y H:i', strtotime($user['created_at']))
            ];
        }
        
        return $exportData;
    }

    /**
     * Get role label for display
     */
    private function getRoleLabel($role)
    {
        $labels = [
            'admin' => 'Administrator',
            'petugas' => 'Petugas',
            'operator' => 'Operator',
            'viewer' => 'Viewer'
        ];
        
        return $labels[$role] ?? $role;
    }

    /**
     * Get status label for display
     */
    private function getStatusLabel($status)
    {
        $labels = [
            'active' => 'Aktif',
            'inactive' => 'Nonaktif',
            'suspended' => 'Ditangguhkan'
        ];
        
        return $labels[$status] ?? $status;
    }
}