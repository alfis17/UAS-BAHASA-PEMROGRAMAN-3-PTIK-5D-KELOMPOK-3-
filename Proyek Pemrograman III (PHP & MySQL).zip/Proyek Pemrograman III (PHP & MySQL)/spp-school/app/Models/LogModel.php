<?php

namespace App\Models;

use CodeIgniter\Model;

class LogModel extends Model
{
    protected $table = 'logs';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'user_id', 
        'action_type', 
        'description', 
        'ip_address', 
        'user_agent',
        'created_at'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = null;

    // Validation
    protected $validationRules = [];
    protected $validationMessages = [];
    protected $skipValidation = true; // Set ke true untuk skip validation sementara
    protected $cleanValidationRules = true;

    public function createLog($userId, $actionType, $description)
    {
        $request = \Config\Services::request();
        
        $data = [
            'user_id' => $userId,
            'action_type' => $actionType,
            'description' => $description,
            'ip_address' => $request->getIPAddress(),
            'user_agent' => $request->getUserAgent()->getAgentString(),
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        return $this->insert($data);
    }

    // Method untuk debugging - bisa dihapus setelah fix
    public function debugInsert($data)
    {
        $db = \Config\Database::connect();
        
        // Coba manual query untuk debug
        $sql = "INSERT INTO logs (user_id, action_type, description, ip_address, user_agent, created_at) 
                VALUES (?, ?, ?, ?, ?, ?)";
        
        return $db->query($sql, [
            $data['user_id'] ?? null,
            $data['action_type'] ?? null,
            $data['description'] ?? null,
            $data['ip_address'] ?? null,
            $data['user_agent'] ?? null,
            $data['created_at'] ?? date('Y-m-d H:i:s')
        ]);
    }

    public function getLastLogin($userId)
    {
        $log = $this->where('user_id', $userId)
                    ->where('action_type', 'login')
                    ->orderBy('created_at', 'DESC')
                    ->first();
        
        return $log ? $log['created_at'] : null;
    }

    public function getUserActivities($userId, $limit = 10)
    {
        $activities = $this->where('user_id', $userId)
                          ->orderBy('created_at', 'DESC')
                          ->limit($limit)
                          ->findAll();
        
        // Format for display
        $formatted = [];
        foreach ($activities as $activity) {
            $formatted[] = [
                'action' => ucfirst($activity['action_type']),
                'description' => $activity['description'],
                'created_at' => date('d/m/Y H:i', strtotime($activity['created_at'])),
                'time_ago' => $this->timeAgo($activity['created_at'])
            ];
        }
        
        return $formatted;
    }

    public function getAllLogs($limit = 50, $offset = 0)
    {
        $db = \Config\Database::connect();
        
        $builder = $db->table('logs l');
        $builder->select('l.*, u.nama_lengkap as user_name, u.role as user_role');
        $builder->join('users u', 'l.user_id = u.id', 'left');
        $builder->orderBy('l.created_at', 'DESC');
        $builder->limit($limit, $offset);
        
        return $builder->get()->getResultArray();
    }

    public function getLogTypes()
    {
        $db = \Config\Database::connect();
        
        $builder = $db->table('logs');
        $builder->select('DISTINCT(action_type)');
        $builder->orderBy('action_type', 'ASC');
        
        $result = $builder->get()->getResultArray();
        
        $types = [];
        foreach ($result as $row) {
            $types[] = $row['action_type'];
        }
        
        return $types;
    }

    public function clearOldLogs($days = 30)
    {
        $date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        return $this->where('created_at <', $date)->delete();
    }

    private function timeAgo($datetime)
    {
        $time = strtotime($datetime);
        $now = time();
        $diff = $now - $time;
        
        if ($diff < 60) {
            return 'Baru saja';
        } elseif ($diff < 3600) {
            $minutes = floor($diff / 60);
            return "{$minutes} menit lalu";
        } elseif ($diff < 86400) {
            $hours = floor($diff / 3600);
            return "{$hours} jam lalu";
        } elseif ($diff < 2592000) {
            $days = floor($diff / 86400);
            return "{$days} hari lalu";
        } elseif ($diff < 31536000) {
            $months = floor($diff / 2592000);
            return "{$months} bulan lalu";
        } else {
            $years = floor($diff / 31536000);
            return "{$years} tahun lalu";
        }
    }
}