<?php

namespace App\Models;

use CodeIgniter\Model;

class SettingModel extends Model
{
    protected $table = 'settings';
    protected $primaryKey = 'key';
    protected $allowedFields = ['key', 'value', 'type', 'group', 'updated_at'];
    
    protected $useTimestamps = false;
    protected $updatedField = 'updated_at';

    public function getAllSettings()
    {
        $settings = $this->findAll();
        $result = [];
        
        // Default settings
        $defaults = $this->getDefaultSettings();
        
        foreach ($settings as $setting) {
            $result[$setting['key']] = $this->parseValue($setting['value'], $setting['type']);
        }
        
        // Merge with defaults for missing settings
        foreach ($defaults as $key => $value) {
            if (!isset($result[$key])) {
                $result[$key] = $value;
            }
        }
        
        return $result;
    }

    public function getNotificationSettings()
    {
        return [
            'notify_payment' => true,
            'notify_late' => true,
            'notify_backup' => true,
            'notify_system' => false,
            'notification_emails' => 'admin@sekolah.com',
            'reminder_time' => 7,
            'reminder_frequency' => 'weekly'
        ];
    }

    public function saveSettings($data)
    {
        foreach ($data as $key => $value) {
            // Handle array values (like checkbox groups)
            if (is_array($value)) {
                $value = json_encode($value);
                $type = 'array';
            } else {
                $type = 'string';
            }
            
            // Check if setting exists
            $existing = $this->find($key);
            
            if ($existing) {
                $this->update($key, [
                    'value' => $value,
                    'type' => $type,
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
            } else {
                $this->insert([
                    'key' => $key,
                    'value' => $value,
                    'type' => $type,
                    'group' => $this->getSettingGroup($key),
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
            }
        }
        
        return true;
    }

    public function saveNotificationSettings($data)
    {
        return $this->saveSettings($data);
    }

    public function getSecurityChecks()
    {
        return [
            ['name' => 'Backup terbaru', 'status' => true],
            ['name' => 'Password admin kuat', 'status' => true],
            ['name' => 'Firewall aktif', 'status' => false],
            ['name' => 'SSL/TLS aktif', 'status' => true],
            ['name' => 'Update sistem terbaru', 'status' => false]
        ];
    }

    public function runSecurityChecks()
    {
        $checks = [];
        
        // Check 1: Recent backup
        $backupModel = new BackupModel();
        $lastBackupDays = $backupModel->getLastBackupDays();
        $checks[] = [
            'name' => 'Backup terbaru',
            'passed' => $lastBackupDays <= 7,
            'message' => $lastBackupDays <= 7 ? 
                "Backup terakhir {$lastBackupDays} hari yang lalu" : 
                "Belum ada backup selama {$lastBackupDays} hari"
        ];
        
        // Check 2: Admin password strength
        $userModel = new \App\Models\UserModel();
        $admin = $userModel->where('role', 'admin')->first();
        $checks[] = [
            'name' => 'Password admin kuat',
            'passed' => strlen($admin->password ?? '') >= 60, // Hash length check
            'message' => 'Password admin menggunakan hash yang aman'
        ];
        
        // Check 3: HTTPS
        $checks[] = [
            'name' => 'HTTPS aktif',
            'passed' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on',
            'message' => isset($_SERVER['HTTPS']) ? 'HTTPS aktif' : 'HTTPS tidak aktif'
        ];
        
        // Check 4: Session security
        $checks[] = [
            'name' => 'Session aman',
            'passed' => ini_get('session.cookie_secure') == '1',
            'message' => 'Session cookie secure: ' . (ini_get('session.cookie_secure') == '1' ? 'Ya' : 'Tidak')
        ];
        
        // Check 5: PHP version
        $phpVersion = PHP_VERSION;
        $checks[] = [
            'name' => 'Versi PHP',
            'passed' => version_compare($phpVersion, '7.4', '>='),
            'message' => "Versi PHP: {$phpVersion}"
        ];
        
        return $checks;
    }

    public function testEmail($email)
    {
        // Simple email test
        // In real implementation, use email library
        
        $config = [
            'protocol' => 'smtp',
            'SMTPHost' => 'smtp.gmail.com',
            'SMTPUser' => 'test@example.com',
            'SMTPPass' => 'password',
            'SMTPPort' => 587,
            'mailType' => 'html'
        ];
        
        // This is a placeholder
        // Real implementation would use CodeIgniter's email class
        
        return true; // Assume success for demo
    }

    public function testCloudConnection($data)
    {
        // Test connection to cloud storage
        // This is a placeholder
        
        if (empty($data['cloud_api_key'])) {
            return false;
        }
        
        // Simulate connection test
        sleep(1); // Simulate network delay
        
        return true;
    }

    private function getDefaultSettings()
    {
        return [
            // General
            'school_name' => 'Sekolah Menengah Atas Negeri 1',
            'school_address' => 'Jl. Pendidikan No. 123',
            'school_phone' => '(021) 12345678',
            'school_email' => 'info@sekolah.sch.id',
            'school_website' => 'https://sekolah.sch.id',
            'school_logo' => '',
            'academic_year' => date('Y') . '/' . (date('Y') + 1),
            'current_semester' => '1',
            'year_start' => date('Y-07-01'),
            'year_end' => date('Y-06-30'),
            'auto_new_year' => false,
            'timezone' => 'Asia/Jakarta',
            'date_format' => 'd/m/Y',
            'time_format' => 'H:i',
            'language' => 'id',
            'maintenance_mode' => false,
            
            // Payment
            'grace_period' => 7,
            'due_date' => 10,
            'late_fee' => 10000,
            'payment_methods' => json_encode(['Tunai', 'Transfer']),
            'auto_calculate_late_fee' => true,
            'allow_partial_payment' => false,
            'bank_name' => 'Bank Negara Indonesia',
            'bank_account' => '1234567890',
            'bank_account_name' => 'SMA NEGERI 1',
            'bank_code' => '009',
            'qris_code' => '',
            'receipt_header' => 'KWITANSI PEMBAYARAN SPP',
            'receipt_footer' => 'Terima kasih atas pembayaran Anda',
            'default_officer' => 'Admin Sekolah',
            'receipt_format' => 'SPP/{Y}/{m}/{n}',
            
            // Email
            'smtp_host' => 'smtp.gmail.com',
            'smtp_port' => 587,
            'smtp_username' => '',
            'smtp_password' => '',
            'sender_email' => 'noreply@sekolah.sch.id',
            'sender_name' => 'Sistem SPP Sekolah',
            'smtp_secure' => true,
            
            // Notification
            'notify_payment' => true,
            'notify_late' => true,
            'notify_backup' => true,
            'notify_system' => false,
            'notification_emails' => 'admin@sekolah.com',
            'reminder_time' => 7,
            'reminder_frequency' => 'weekly',
            'reminder_template' => 'Yth. Orang Tua/Wali {nama_siswa}, mohon segera melakukan pembayaran SPP bulan {bulan} sebesar Rp {jumlah}.',
            
            // Appearance
            'theme_color' => 'blue',
            'primary_color' => '#0d6efd',
            'secondary_color' => '#6c757d',
            'app_logo' => '',
            'favicon' => '',
            'dark_mode' => false,
            'compact_mode' => false,
            'dashboard_widgets' => json_encode(['stats', 'recent_payments', 'tunggakan_chart', 'quick_actions']),
            'items_per_page' => 25,
            'default_sort' => 'created_at',
            'default_sort_order' => 'desc',
            'show_help_tips' => true,
            'show_tour' => false,
            
            // Security
            'max_login_attempts' => 5,
            'lockout_duration' => 30,
            'session_timeout' => 60,
            'force_password_change' => 90,
            'require_strong_password' => true,
            'two_factor_auth' => false,
            'login_notification' => true,
            'default_access_level' => 'operator',
            'ip_whitelist' => '',
            'access_time_start' => '07:00',
            'access_time_end' => '17:00',
            'log_retention' => 90,
            'enable_audit_log' => true,
            'block_tor' => false,
            
            // Backup
            'auto_backup_frequency' => 'weekly',
            'backup_time' => '02:00',
            'max_backup_files' => 30,
            'backup_compression' => 'gzip',
            'backup_location' => WRITEPATH . 'backups/',
            'backup_database_only' => true,
            'backup_include_files' => false,
            'backup_email_notification' => true,
            'cloud_storage' => '',
            'cloud_folder' => 'spp-backups',
            'cloud_api_key' => '',
            'cloud_secret_key' => '',
            'cloud_encryption' => false
        ];
    }

    private function parseValue($value, $type)
    {
        switch ($type) {
            case 'integer':
                return (int)$value;
            case 'float':
                return (float)$value;
            case 'boolean':
                return (bool)$value;
            case 'array':
                return json_decode($value, true) ?? [];
            case 'json':
                return json_decode($value, true);
            default:
                return $value;
        }
    }

    private function getSettingGroup($key)
    {
        $groups = [
            'school_' => 'general',
            'academic_' => 'general',
            'timezone' => 'general',
            'date_format' => 'general',
            'time_format' => 'general',
            'language' => 'general',
            'maintenance_mode' => 'general',
            
            'grace_period' => 'payment',
            'due_date' => 'payment',
            'late_fee' => 'payment',
            'payment_methods' => 'payment',
            'auto_calculate_late_fee' => 'payment',
            'allow_partial_payment' => 'payment',
            'bank_' => 'payment',
            'qris_code' => 'payment',
            'receipt_' => 'payment',
            'default_officer' => 'payment',
            
            'smtp_' => 'email',
            'sender_' => 'email',
            
            'notify_' => 'notification',
            'reminder_' => 'notification',
            
            'theme_' => 'appearance',
            'primary_color' => 'appearance',
            'secondary_color' => 'appearance',
            'app_logo' => 'appearance',
            'favicon' => 'appearance',
            'dark_mode' => 'appearance',
            'compact_mode' => 'appearance',
            'dashboard_widgets' => 'appearance',
            'items_per_page' => 'appearance',
            'default_sort' => 'appearance',
            'default_sort_order' => 'appearance',
            'show_help_tips' => 'appearance',
            'show_tour' => 'appearance',
            
            'max_login_attempts' => 'security',
            'lockout_duration' => 'security',
            'session_timeout' => 'security',
            'force_password_change' => 'security',
            'require_strong_password' => 'security',
            'two_factor_auth' => 'security',
            'login_notification' => 'security',
            'default_access_level' => 'security',
            'ip_whitelist' => 'security',
            'access_time_' => 'security',
            'log_retention' => 'security',
            'enable_audit_log' => 'security',
            'block_tor' => 'security',
            
            'auto_backup_' => 'backup',
            'backup_' => 'backup',
            'cloud_' => 'backup'
        ];
        
        foreach ($groups as $prefix => $group) {
            if (strpos($key, $prefix) === 0) {
                return $group;
            }
        }
        
        return 'general';
    }
}