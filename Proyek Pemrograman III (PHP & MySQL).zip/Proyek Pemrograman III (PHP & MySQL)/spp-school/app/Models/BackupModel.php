<?php

namespace App\Models;

use CodeIgniter\Model;

class BackupModel extends Model
{
    protected $table = 'backups';
    protected $primaryKey = 'id';
    protected $allowedFields = ['filename', 'size', 'type', 'description', 'created_by', 'created_at'];
    
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    public function getDatabaseInfo()
    {
        $db = db_connect();
        
        // Get database size
        $sizeQuery = $db->query("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size FROM information_schema.tables WHERE table_schema = DATABASE()");
        $size = $sizeQuery->getRow()->size ?? 0;
        
        // Get table count
        $tablesQuery = $db->query("SELECT COUNT(*) as tables FROM information_schema.tables WHERE table_schema = DATABASE()");
        $tables = $tablesQuery->getRow()->tables ?? 0;
        
        // Get backup count
        $backups = $this->countAll();
        
        return [
            'size' => $size,
            'tables' => $tables,
            'backups' => $backups
        ];
    }

    public function getTables()
    {
        $db = db_connect();
        $query = $db->query("SHOW TABLES");
        $tables = [];
        
        foreach ($query->getResultArray() as $row) {
            $tables[] = array_values($row)[0];
        }
        
        return $tables;
    }

    public function getTableSizes()
    {
        $db = db_connect();
        $query = $db->query("
            SELECT table_name, 
                   ROUND((data_length + index_length) / 1024, 2) as size_kb
            FROM information_schema.tables 
            WHERE table_schema = DATABASE()
            ORDER BY table_name
        ");
        
        $sizes = [];
        foreach ($query->getResultArray() as $row) {
            $sizes[$row['table_name']] = $row['size_kb'];
        }
        
        return $sizes;
    }

    public function getBackupFiles()
    {
        $files = [];
        $backupPath = WRITEPATH . 'backups/';
        
        if (!is_dir($backupPath)) {
            mkdir($backupPath, 0755, true);
        }
        
        $fileList = scandir($backupPath);
        
        foreach ($fileList as $file) {
            if ($file != '.' && $file != '..' && !is_dir($backupPath . $file)) {
                $filePath = $backupPath . $file;
                $files[] = [
                    'name' => $file,
                    'size' => $this->formatBytes(filesize($filePath)),
                    'date' => date('d/m/Y H:i', filemtime($filePath)),
                    'type' => pathinfo($file, PATHINFO_EXTENSION)
                ];
            }
        }
        
        // Sort by date (newest first)
        usort($files, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });
        
        return $files;
    }

    public function createBackup($data)
    {
        $backupPath = WRITEPATH . 'backups/';
        if (!is_dir($backupPath)) {
            mkdir($backupPath, 0755, true);
        }
        
        $filename = $data['backup_name'] ?? 'backup_' . date('Y-m-d_H-i-s');
        $filepath = $backupPath . $filename . '.sql';
        
        // Get selected tables
        $tables = $data['tables'] ?? [];
        if (empty($tables)) {
            $tables = $this->getTables();
        }
        
        // Create SQL dump
        $sql = "-- Database Backup\n";
        $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $sql .= "-- Tables: " . implode(', ', $tables) . "\n\n";
        
        $db = db_connect();
        
        foreach ($tables as $table) {
            // Get table structure
            $createTable = $db->query("SHOW CREATE TABLE `$table`")->getRowArray();
            $sql .= "\n-- Table structure for table `$table`\n";
            $sql .= "DROP TABLE IF EXISTS `$table`;\n";
            $sql .= $createTable["Create Table"] . ";\n\n";
            
            // Get table data
            $rows = $db->table($table)->get()->getResultArray();
            if (!empty($rows)) {
                $sql .= "-- Dumping data for table `$table`\n";
                foreach ($rows as $row) {
                    $values = array_map(function($value) use ($db) {
                        return $db->escape($value);
                    }, array_values($row));
                    
                    $sql .= "INSERT INTO `$table` VALUES (" . implode(', ', $values) . ");\n";
                }
                $sql .= "\n";
            }
        }
        
        // Save to file
        file_put_contents($filepath, $sql);
        
        // Compress if needed
        if (($data['compression'] ?? 'gzip') == 'gzip') {
            $compressedPath = $filepath . '.gz';
            $gz = gzopen($compressedPath, 'w9');
            gzwrite($gz, file_get_contents($filepath));
            gzclose($gz);
            unlink($filepath);
            $filepath = $compressedPath;
        }
        
        // Save to database
        $this->insert([
            'filename' => basename($filepath),
            'size' => filesize($filepath),
            'type' => $data['backup_type'] ?? 'full',
            'description' => $data['description'] ?? '',
            'created_by' => session()->get('id')
        ]);
        
        return [
            'filename' => basename($filepath),
            'size' => $this->formatBytes(filesize($filepath)),
            'path' => $filepath
        ];
    }

    public function restoreBackup($data)
    {
        $backupPath = WRITEPATH . 'backups/';
        $filename = $data['backup_file'] ?? '';
        $filepath = $backupPath . $filename;
        
        if (!file_exists($filepath)) {
            throw new \Exception('Backup file not found');
        }
        
        // Decompress if needed
        if (pathinfo($filename, PATHINFO_EXTENSION) == 'gz') {
            $content = gzdecode(file_get_contents($filepath));
        } else {
            $content = file_get_contents($filepath);
        }
        
        // Execute SQL
        $db = db_connect();
        $queries = array_filter(array_map('trim', explode(';', $content)));
        
        foreach ($queries as $query) {
            if (!empty($query)) {
                $db->query($query);
            }
        }
        
        return true;
    }

    public function downloadBackup($filename)
    {
        $backupPath = WRITEPATH . 'backups/';
        $filepath = $backupPath . $filename;
        
        if (!file_exists($filepath)) {
            throw new \Exception('File not found');
        }
        
        return service('response')->download($filepath, null);
    }

    public function previewBackup($filename)
    {
        $backupPath = WRITEPATH . 'backups/';
        $filepath = $backupPath . $filename;
        
        if (!file_exists($filepath)) {
            return '<div class="alert alert-danger">File not found</div>';
        }
        
        // Decompress if needed
        if (pathinfo($filename, PATHINFO_EXTENSION) == 'gz') {
            $content = gzdecode(file_get_contents($filepath));
        } else {
            $content = file_get_contents($filepath);
        }
        
        // Limit preview to first 1000 lines
        $lines = explode("\n", $content);
        $previewLines = array_slice($lines, 0, 1000);
        $preview = implode("\n", $previewLines);
        
        if (count($lines) > 1000) {
            $preview .= "\n\n... (showing first 1000 of " . count($lines) . " lines)";
        }
        
        return '<pre class="bg-light p-3" style="max-height: 400px; overflow: auto;">' . 
               htmlspecialchars($preview) . '</pre>';
    }

    public function deleteBackup($filename)
    {
        $backupPath = WRITEPATH . 'backups/';
        $filepath = $backupPath . $filename;
        
        if (file_exists($filepath)) {
            unlink($filepath);
        }
        
        // Remove from database
        $this->where('filename', $filename)->delete();
        
        return true;
    }

    public function getChartData()
    {
        $db = db_connect();
        $query = $db->query("
            SELECT DATE_FORMAT(created_at, '%Y-%m') as month,
                   COUNT(*) as count
            FROM backups
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
            GROUP BY DATE_FORMAT(created_at, '%Y-%m')
            ORDER BY month
        ");
        
        $labels = [];
        $data = [];
        
        foreach ($query->getResultArray() as $row) {
            $labels[] = date('M Y', strtotime($row['month'] . '-01'));
            $data[] = (int)$row['count'];
        }
        
        return [
            'labels' => $labels,
            'data' => $data,
            'currentYear' => date('Y')
        ];
    }

    public function getLastBackupDays()
    {
        $db = db_connect();
        $query = $db->query("
            SELECT DATEDIFF(NOW(), MAX(created_at)) as days
            FROM backups
        ");
        
        $result = $query->getRow();
        return $result ? $result->days : 999;
    }

    public function getSchedule()
    {
        return [
            ['day' => 'Senin', 'time' => '02:00', 'status' => true, 'last_run' => '2024-01-15'],
            ['day' => 'Selasa', 'time' => '02:00', 'status' => true, 'last_run' => '2024-01-16'],
            ['day' => 'Rabu', 'time' => '02:00', 'status' => true, 'last_run' => '2024-01-17'],
            ['day' => 'Kamis', 'time' => '02:00', 'status' => true, 'last_run' => '2024-01-18'],
            ['day' => 'Jumat', 'time' => '02:00', 'status' => true, 'last_run' => '2024-01-19'],
            ['day' => 'Sabtu', 'time' => '02:00', 'status' => false, 'last_run' => '2024-01-13'],
            ['day' => 'Minggu', 'time' => '02:00', 'status' => false, 'last_run' => '2024-01-14']
        ];
    }

    public function saveSchedule($data)
    {
        // Save schedule to database or config file
        // This is a placeholder implementation
        return true;
    }

    private function formatBytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= pow(1024, $pow);
        
        return round($bytes, $precision) . ' ' . $units[$pow];
    }
}