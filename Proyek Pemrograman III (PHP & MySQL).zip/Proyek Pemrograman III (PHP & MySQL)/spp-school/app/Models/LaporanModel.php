<?php

namespace App\Models;

use CodeIgniter\Model;

class LaporanModel extends Model
{
    protected $table = 'laporan';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'object';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'judul', 'bulan', 'tahun', 'total_transaksi', 'total_pembayaran',
        'metode_pembayaran', 'data_detail', 'created_by'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation
    protected $validationRules = [
        'judul' => 'required|string|max_length[255]',
        'bulan' => 'permit_empty|string|max_length[20]',
        'tahun' => 'permit_empty|numeric|exact_length[4]',
        'total_transaksi' => 'permit_empty|integer',
        'total_pembayaran' => 'permit_empty|decimal',
        'metode_pembayaran' => 'permit_empty|string|max_length[50]',
        'data_detail' => 'permit_empty|string',
        'created_by' => 'required|integer',
    ];

    protected $validationMessages = [];
    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    /**
     * Generate and save a report
     */
    public function generateReport($judul, $bulan = null, $tahun = null, $createdBy)
    {
        // Get pembayaran data
        $pembayaranModel = new PembayaranModel();
        $pembayaranData = $pembayaranModel->getLaporan($bulan, $tahun);

        // Calculate totals
        $totalTransaksi = count($pembayaranData);
        $totalPembayaran = array_sum(array_column($pembayaranData, 'jumlah_bayar'));

        // Group by payment method
        $metodeStats = [];
        foreach ($pembayaranData as $p) {
            $metode = $p->metode_pembayaran ?? 'Tidak Diketahui';
            if (!isset($metodeStats[$metode])) {
                $metodeStats[$metode] = 0;
            }
            $metodeStats[$metode]++;
        }

        // Find most used payment method
        $metodePembayaran = '';
        if (!empty($metodeStats)) {
            $metodePembayaran = array_keys($metodeStats, max($metodeStats))[0];
        }

        // Prepare detailed data
        $dataDetail = [
            'pembayaran' => $pembayaranData,
            'metode_stats' => $metodeStats,
            'periode' => [
                'bulan' => $bulan,
                'tahun' => $tahun
            ]
        ];

        // Save report
        $data = [
            'judul' => $judul,
            'bulan' => $bulan,
            'tahun' => $tahun,
            'total_transaksi' => $totalTransaksi,
            'total_pembayaran' => $totalPembayaran,
            'metode_pembayaran' => $metodePembayaran,
            'data_detail' => json_encode($dataDetail),
            'created_by' => $createdBy
        ];

        return $this->insert($data);
    }

    /**
     * Get reports with creator information
     */
    public function getReportsWithCreator()
    {
        $builder = $this->db->table('laporan l');
        $builder->select('l.*, u.nama_lengkap as creator_name');
        $builder->join('users u', 'u.id = l.created_by');
        $builder->orderBy('l.created_at', 'DESC');

        return $builder->get()->getResult();
    }

    /**
     * Get report by ID with decoded data
     */
    public function getReportWithDetails($id)
    {
        $report = $this->find($id);

        if ($report) {
            $report->data_detail = json_decode($report->data_detail, true);
        }

        return $report;
    }

    /**
     * Get reports by period
     */
    public function getReportsByPeriod($bulan = null, $tahun = null)
    {
        $builder = $this->db->table('laporan');

        if ($bulan) {
            $builder->where('bulan', $bulan);
        }

        if ($tahun) {
            $builder->where('tahun', $tahun);
        }

        $builder->orderBy('created_at', 'DESC');

        return $builder->get()->getResult();
    }

    /**
     * Delete old reports (cleanup method)
     */
    public function deleteOldReports($days = 90)
    {
        $date = date('Y-m-d H:i:s', strtotime("-{$days} days"));

        return $this->where('created_at <', $date)->delete();
    }

    /**
     * Get report statistics
     */
    public function getReportStats()
    {
        $builder = $this->db->table('laporan');

        $totalReports = $builder->countAllResults();

        $builder->select('SUM(total_pembayaran) as total_pembayaran_all, AVG(total_transaksi) as avg_transaksi');
        $stats = $builder->get()->getRow();

        return [
            'total_reports' => $totalReports,
            'total_pembayaran_all' => $stats->total_pembayaran_all ?? 0,
            'avg_transaksi' => $stats->avg_transaksi ?? 0
        ];
    }

    /**
     * Export report to array format
     */
    public function exportReport($id)
    {
        $report = $this->getReportWithDetails($id);

        if (!$report) {
            return null;
        }

        $exportData = [
            'judul' => $report->judul,
            'periode' => $report->bulan ? $report->bulan . ' ' . $report->tahun : 'Semua Periode',
            'total_transaksi' => $report->total_transaksi,
            'total_pembayaran' => $report->total_pembayaran,
            'metode_pembayaran' => $report->metode_pembayaran,
            'created_at' => $report->created_at,
            'created_by' => $report->creator_name ?? 'Unknown'
        ];

        if (isset($report->data_detail['pembayaran'])) {
            $exportData['detail_pembayaran'] = $report->data_detail['pembayaran'];
        }

        return $exportData;
    }
}
