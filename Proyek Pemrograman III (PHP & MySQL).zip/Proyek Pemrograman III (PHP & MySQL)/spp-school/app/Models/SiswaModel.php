<?php

namespace App\Models;

use CodeIgniter\Model;

class SiswaModel extends Model
{
    protected $table = 'siswa';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'nisn', 'nama_siswa', 'jenis_kelamin', 'tempat_lahir', 'tanggal_lahir',
        'alamat', 'no_hp', 'id_kelas', 'tahun_masuk', 'password',
        'remember_token', 'last_login', 'created_at', 'updated_at'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation
    protected $validationRules = [
        'nisn' => 'required|exact_length[10]|numeric|is_unique[siswa.nisn,id,{id}]',
        'nama_siswa' => 'required|max_length[150]',
        'jenis_kelamin' => 'required|in_list[L,P]',
        'tempat_lahir' => 'required|max_length[100]',
        'tanggal_lahir' => 'required|valid_date',
        'alamat' => 'required',
        'no_hp' => 'required|max_length[20]',
        'id_kelas' => 'required|numeric',
        'tahun_masuk' => 'required|numeric|exact_length[4]',
        'password' => 'permit_empty',
    ];

    protected $validationMessages = [
        'nisn' => [
            'required' => 'NISN harus diisi',
            'exact_length' => 'NISN harus 10 digit',
            'numeric' => 'NISN harus angka',
            'is_unique' => 'NISN sudah terdaftar'
        ],
        'nama_siswa' => [
            'required' => 'Nama siswa harus diisi',
            'max_length' => 'Nama siswa maksimal 150 karakter'
        ],
        'jenis_kelamin' => [
            'required' => 'Jenis kelamin harus dipilih',
            'in_list' => 'Jenis kelamin tidak valid'
        ],
        'tempat_lahir' => [
            'required' => 'Tempat lahir harus diisi',
            'max_length' => 'Tempat lahir maksimal 100 karakter'
        ],
        'tanggal_lahir' => [
            'required' => 'Tanggal lahir harus diisi',
            'valid_date' => 'Tanggal lahir tidak valid'
        ],
        'alamat' => [
            'required' => 'Alamat harus diisi'
        ],
        'no_hp' => [
            'required' => 'No. HP harus diisi',
            'max_length' => 'No. HP maksimal 20 karakter'
        ],
        'id_kelas' => [
            'required' => 'Kelas harus dipilih',
            'numeric' => 'Kelas tidak valid'
        ],
        'tahun_masuk' => [
            'required' => 'Tahun masuk harus diisi',
            'numeric' => 'Tahun masuk harus angka',
            'exact_length' => 'Tahun masuk harus 4 digit'
        ]
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert = ['hashPassword'];
    protected $beforeUpdate = ['hashPassword'];

    protected function hashPassword(array $data)
    {
        if (isset($data['data']['password']) && !empty($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }
        return $data;
    }

    /**
     * Update last login timestamp
     */
    public function updateLastLogin($siswaId)
    {
        return $this->update($siswaId, [
            'last_login' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Update remember token
     */
    public function updateRememberToken($siswaId, $token)
    {
        return $this->update($siswaId, [
            'remember_token' => $token,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Find siswa by remember token
     */
    public function findByRememberToken($token)
    {
        return $this->where('remember_token', $token)->first();
    }

    /**
     * Find siswa by NISN
     */
    public function findByNISN($nisn)
    {
        return $this->where('nisn', $nisn)->first();
    }

    /**
     * Get siswa with kelas info
     */
    public function getSiswaWithKelas($siswaId = null)
    {
        $db = \Config\Database::connect();
        
        $builder = $db->table('siswa s');
        $builder->select('s.*, k.nama_kelas, k.tingkat');
        $builder->join('kelas k', 's.id_kelas = k.id', 'left');
        
        if ($siswaId) {
            $builder->where('s.id', $siswaId);
            return $builder->get()->getRowArray();
        }
        
        $builder->orderBy('s.nama_siswa', 'ASC');
        return $builder->get()->getResultArray();
    }

    /**
     * Get siswa statistics
     */
    public function getSiswaStats()
    {
        $totalSiswa = $this->countAllResults();
        
        // Group by jenis kelamin
        $lakiLaki = $this->where('jenis_kelamin', 'L')->countAllResults();
        $perempuan = $this->where('jenis_kelamin', 'P')->countAllResults();
        
        // Last 7 days registration
        $sevenDaysAgo = date('Y-m-d', strtotime('-7 days'));
        $newSiswa = $this->where('created_at >=', $sevenDaysAgo)
                         ->countAllResults();
        
        return [
            'total_siswa' => $totalSiswa,
            'laki_laki' => $lakiLaki,
            'perempuan' => $perempuan,
            'new_siswa_7_days' => $newSiswa
        ];
    }
}