<?php

namespace App\Models;

use CodeIgniter\Model;

class KelasModel extends Model
{
    protected $table = 'kelas';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'nama_kelas', 'tingkat', 'jurusan', 'wali_kelas', 'kapasitas'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation
    protected $validationRules = [ 
        'nama_kelas' => 'required|max_length[50]|is_unique[kelas.nama_kelas,id,{id}]',
        'tingkat' => 'required|in_list[X,XI,XII]',
        'jurusan' => 'required|max_length[50]',
        'wali_kelas' => 'required|max_length[100]',
        'kapasitas' => 'required|numeric|greater_than[0]|less_than_equal_to[50]',
    ];

    protected $validationMessages = [
        'nama_kelas' => [
            'required' => 'Nama kelas wajib diisi',
            'max_length' => 'Nama kelas maksimal 50 karakter',
            'is_unique' => 'Nama kelas sudah digunakan'
        ],
        'tingkat' => [
            'required' => 'Tingkat wajib dipilih',
            'in_list' => 'Tingkat harus X, XI, atau XII'
        ],
        'jurusan' => [
            'required' => 'Jurusan wajib diisi',
            'max_length' => 'Jurusan maksimal 50 karakter'
        ],
        'wali_kelas' => [
            'required' => 'Wali kelas wajib diisi',
            'max_length' => 'Nama wali kelas maksimal 100 karakter'
        ],
        'kapasitas' => [
            'required' => 'Kapasitas wajib diisi',
            'numeric' => 'Kapasitas harus angka',
            'greater_than' => 'Kapasitas harus lebih dari 0',
            'less_than_equal_to' => 'Kapasitas maksimal 50 siswa'
        ]
    ];
    
    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    /**
     * Get kelas data with siswa count
     */
    public function getKelasWithSiswaCount()
    {
        $builder = $this->db->table('kelas k');
        $builder->select('k.*, COUNT(s.id) as jumlah_siswa');
        $builder->join('siswa s', 's.id_kelas = k.id', 'left');
        $builder->groupBy('k.id');
        $builder->orderBy('k.tingkat, k.nama_kelas');
        return $builder->get()->getResultArray();
    }

    /**
     * Get kelas by tingkat
     */
    public function getKelasByTingkat($tingkat)
    {
        return $this->where('tingkat', $tingkat)
                   ->orderBy('nama_kelas', 'ASC')
                   ->findAll();
    }

    /**
     * Get available tingkat
     */
    public function getTingkatTersedia()
    {
        $builder = $this->db->table('kelas');
        $builder->select('tingkat')->distinct()->orderBy('tingkat', 'ASC');
        $result = $builder->get()->getResultArray();
        
        $tingkatList = [];
        foreach ($result as $row) {
            $tingkatList[] = $row['tingkat'];
        }
        
        return $tingkatList;
    }

    /**
     * Check if nama_kelas is unique
     */
    public function isNamaKelasUnique($nama_kelas, $exclude_id = null)
    {
        $builder = $this->where('nama_kelas', $nama_kelas);
        
        if ($exclude_id) {
            $builder->where('id !=', $exclude_id);
        }
        
        return $builder->countAllResults() === 0;
    }
}