<?php

namespace App\Models;

use CodeIgniter\Model;

class SPPModel extends Model
{
    protected $table = 'spp';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'object';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = ['tahun_ajaran', 'tingkat', 'nominal', 'created_at', 'updated_at'];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $deletedField = 'deleted_at';

    // Validation
    protected $validationRules = [
        'tahun_ajaran' => [
            'rules' => 'required|regex_match[/^\d{4}\/\d{4}$/]|max_length[9]',
            'errors' => [
                'required' => 'Tahun ajaran harus diisi',
                'regex_match' => 'Format tahun ajaran harus YYYY/YYYY',
                'max_length' => 'Tahun ajaran maksimal 9 karakter'
            ]
        ],
        'tingkat' => [
            'rules' => 'required|in_list[X,XI,XII]',
            'errors' => [
                'required' => 'Tingkat harus dipilih',
                'in_list' => 'Pilih tingkat yang valid (X, XI, atau XII)'
            ]
        ],
        'nominal' => [
            'rules' => 'required|numeric|greater_than[0]',
            'errors' => [
                'required' => 'Nominal SPP harus diisi',
                'numeric' => 'Nominal harus berupa angka',
                'greater_than' => 'Nominal harus lebih dari 0'
            ]
        ]
    ];

    protected $validationMessages = [];
    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    /**
     * Initialize the model
     */
    public function __construct()
    {
        parent::__construct();
        $this->checkTableExists();
    }

    /**
     * Check if table exists, create if not
     */
    private function checkTableExists()
    {
        try {
            if (!$this->db->tableExists($this->table)) {
                $this->createTable();
            }
        } catch (\Exception $e) {
            log_message('error', 'Error checking table: ' . $e->getMessage());
        }
    }

    /**
     * Create SPP table if not exists
     */
    private function createTable()
    {
        $forge = \Config\Database::forge();
        
        $fields = [
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'tahun_ajaran' => [
                'type' => 'VARCHAR',
                'constraint' => '9',
                'null' => false,
            ],
            'tingkat' => [
                'type' => 'ENUM',
                'constraint' => ['X', 'XI', 'XII'],
                'null' => false,
            ],
            'nominal' => [
                'type' => 'DECIMAL',
                'constraint' => '15,2',
                'null' => false,
                'default' => 0,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ]
        ];
        
        $forge->addField($fields);
        $forge->addPrimaryKey('id');
        $forge->addUniqueKey(['tahun_ajaran', 'tingkat']);
        $forge->addKey('tahun_ajaran');
        $forge->addKey('tingkat');
        $forge->addKey('created_at');
        $forge->createTable($this->table, true);
        
        // Insert sample data
        $this->insertSampleData();
    }

    /**
     * Insert sample data for testing
     */
    private function insertSampleData()
    {
        $sampleData = [
            [
                'tahun_ajaran' => '2023/2024',
                'tingkat' => 'X',
                'nominal' => 500000,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2023/2024',
                'tingkat' => 'XI',
                'nominal' => 550000,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'tahun_ajaran' => '2023/2024',
                'tingkat' => 'XII',
                'nominal' => 600000,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]
        ];
        
        foreach ($sampleData as $data) {
            $this->insert($data);
        }
    }

    /**
     * Get SPP by tahun ajaran and tingkat
     */
    public function getSPPByTahunTingkat($tahun_ajaran, $tingkat)
    {
        return $this->where([
            'tahun_ajaran' => $tahun_ajaran,
            'tingkat' => $tingkat
        ])->first();
    }

    /**
     * Get latest SPP by tingkat
     */
    public function getSPPByTingkat($tingkat)
    {
        return $this->where('tingkat', $tingkat)
                   ->orderBy('tahun_ajaran', 'DESC')
                   ->first();
    }

    /**
     * Get all available tahun ajaran
     */
    public function getTahunAjaranTersedia()
    {
        try {
            $builder = $this->db->table($this->table);
            $builder->select('tahun_ajaran')->distinct()->orderBy('tahun_ajaran', 'DESC');
            $result = $builder->get()->getResult();
            
            $tahunList = [];
            foreach ($result as $row) {
                $tahunList[] = $row->tahun_ajaran;
            }
            
            return $tahunList;
        } catch (\Exception $e) {
            log_message('error', 'Error getting tahun ajaran: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get statistics for admin dashboard
     */
    public function getTotalSPPPerTingkat()
    {
        try {
            $builder = $this->db->table($this->table);
            $builder->select('tingkat, COUNT(*) as total, SUM(nominal) as total_nominal, AVG(nominal) as rata_rata');
            $builder->groupBy('tingkat');
            $builder->orderBy('tingkat');
            return $builder->get()->getResult();
        } catch (\Exception $e) {
            log_message('error', 'Error getting SPP stats: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get SPP for specific tahun ajaran
     */
    public function getByTahunAjaran($tahun_ajaran)
    {
        return $this->where('tahun_ajaran', $tahun_ajaran)
                   ->orderBy('tingkat', 'ASC')
                   ->findAll();
    }

    /**
     * Get SPP for specific tingkat
     */
    public function getByTingkat($tingkat)
    {
        return $this->where('tingkat', $tingkat)
                   ->orderBy('tahun_ajaran', 'DESC')
                   ->findAll();
    }

    /**
     * Get current active SPP (latest tahun ajaran)
     */
    public function getCurrentSPP()
    {
        try {
            $latestYear = $this->db->table($this->table)
                                  ->select('tahun_ajaran')
                                  ->orderBy('tahun_ajaran', 'DESC')
                                  ->limit(1)
                                  ->get()
                                  ->getRow();
            
            if ($latestYear) {
                return $this->where('tahun_ajaran', $latestYear->tahun_ajaran)
                            ->orderBy('tingkat', 'ASC')
                            ->findAll();
            }
            
            return [];
        } catch (\Exception $e) {
            log_message('error', 'Error getting current SPP: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Check if SPP exists for tahun ajaran and tingkat
     */
    public function exists($tahun_ajaran, $tingkat, $exclude_id = null)
    {
        $builder = $this->where('tahun_ajaran', $tahun_ajaran)
                       ->where('tingkat', $tingkat);
        
        if ($exclude_id) {
            $builder->where('id !=', $exclude_id);
        }
        
        return $builder->countAllResults() > 0;
    }

    /**
     * Get nominal for specific tahun ajaran and tingkat
     */
    public function getNominal($tahun_ajaran, $tingkat)
    {
        $spp = $this->where('tahun_ajaran', $tahun_ajaran)
                   ->where('tingkat', $tingkat)
                   ->first();
        
        return $spp ? $spp->nominal : 0;
    }

    /**
     * Get SPP summary statistics
     */
    public function getSummaryStats()
    {
        try {
            $builder = $this->db->table($this->table);
            
            // Get total count
            $total = $builder->countAllResults();
            
            // Reset builder
            $builder->resetQuery();
            
            // Get average nominal
            $avgResult = $builder->selectAvg('nominal', 'average')
                                ->get()
                                ->getRow();
            
            // Get min and max
            $builder->resetQuery();
            $minMaxResult = $builder->selectMin('nominal', 'min_nominal')
                                   ->selectMax('nominal', 'max_nominal')
                                   ->get()
                                   ->getRow();
            
            // Get yearly totals
            $builder->resetQuery();
            $yearlyResult = $builder->select('tahun_ajaran, COUNT(*) as count, SUM(nominal) as total')
                                   ->groupBy('tahun_ajaran')
                                   ->orderBy('tahun_ajaran', 'DESC')
                                   ->get()
                                   ->getResult();
            
            return [
                'total_data' => $total,
                'average_nominal' => $avgResult->average ?? 0,
                'min_nominal' => $minMaxResult->min_nominal ?? 0,
                'max_nominal' => $minMaxResult->max_nominal ?? 0,
                'yearly_summary' => $yearlyResult
            ];
        } catch (\Exception $e) {
            log_message('error', 'Error getting summary stats: ' . $e->getMessage());
            return [
                'total_data' => 0,
                'average_nominal' => 0,
                'min_nominal' => 0,
                'max_nominal' => 0,
                'yearly_summary' => []
            ];
        }
    }

    /**
     * Get paginated data for datatable
     */
    public function getPaginatedData($limit, $offset, $search = null, $orderColumn = 'id', $orderDir = 'DESC')
    {
        try {
            $builder = $this->db->table($this->table);
            
            // Apply search if provided
            if (!empty($search)) {
                $builder->groupStart()
                       ->like('tahun_ajaran', $search)
                       ->orLike('tingkat', $search)
                       ->orLike('nominal', $search)
                       ->groupEnd();
            }
            
            // Get total count
            $total = $builder->countAllResults(false);
            
            // Apply ordering and pagination
            $builder->orderBy($orderColumn, $orderDir);
            $builder->limit($limit, $offset);
            
            $data = $builder->get()->getResult();
            
            return [
                'total' => $total,
                'data' => $data
            ];
        } catch (\Exception $e) {
            log_message('error', 'Error getting paginated data: ' . $e->getMessage());
            return [
                'total' => 0,
                'data' => []
            ];
        }
    }

    /**
     * Get all SPP with formatted nominal
     */
    public function getAllFormatted()
    {
        $sppData = $this->orderBy('tahun_ajaran', 'DESC')
                       ->orderBy('tingkat', 'ASC')
                       ->findAll();
        
        foreach ($sppData as &$spp) {
            $spp->nominal_formatted = 'Rp ' . number_format($spp->nominal, 0, ',', '.');
            $spp->created_formatted = date('d/m/Y H:i', strtotime($spp->created_at));
            $spp->updated_formatted = date('d/m/Y H:i', strtotime($spp->updated_at));
        }
        
        return $sppData;
    }

    /**
     * Get yearly totals
     */
    public function getYearlyTotals()
    {
        try {
            $builder = $this->db->table($this->table);
            $builder->select('tahun_ajaran, SUM(nominal) as total_nominal, COUNT(*) as total_data');
            $builder->groupBy('tahun_ajaran');
            $builder->orderBy('tahun_ajaran', 'DESC');
            
            $result = $builder->get()->getResult();
            
            foreach ($result as &$row) {
                $row->total_nominal_formatted = 'Rp ' . number_format($row->total_nominal, 0, ',', '.');
            }
            
            return $result;
        } catch (\Exception $e) {
            log_message('error', 'Error getting yearly totals: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Bulk insert SPP data
     */
    public function bulkInsert($data)
    {
        try {
            return $this->insertBatch($data);
        } catch (\Exception $e) {
            log_message('error', 'Error bulk inserting SPP: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Validate tahun ajaran format
     */
    public function validateTahunAjaran($tahun_ajaran)
    {
        return preg_match('/^\d{4}\/\d{4}$/', $tahun_ajaran);
    }

    /**
     * Get tingkat options
     */
    public function getTingkatOptions()
    {
        return [
            'X' => 'Kelas X',
            'XI' => 'Kelas XI',
            'XII' => 'Kelas XII'
        ];
    }
    public function getSPPAktifByTingkat($tingkat)
{
    // Mendapatkan tahun ajaran aktif
    $bulan = date('n');
    $tahun = date('Y');
    
    if ($bulan >= 7) {
        $tahun_ajaran = $tahun . '/' . ($tahun + 1);
    } else {
        $tahun_ajaran = ($tahun - 1) . '/' . $tahun;
    }
    
    return $this->where('tingkat', $tingkat)
                ->where('tahun_ajaran', $tahun_ajaran)
                ->first();
}

public function getTahunAjaranAktif()
{
    $bulan = date('n');
    $tahun = date('Y');
    
    if ($bulan >= 7) {
        return $tahun . '/' . ($tahun + 1);
    } else {
        return ($tahun - 1) . '/' . $tahun;
    }
}
}