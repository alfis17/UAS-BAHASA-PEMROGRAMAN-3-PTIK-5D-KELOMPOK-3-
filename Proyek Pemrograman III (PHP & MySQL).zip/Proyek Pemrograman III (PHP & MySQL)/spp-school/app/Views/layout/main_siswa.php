<?php
// Cek apakah user adalah siswa
if (session()->get('role') !== 'siswa') {
    // Redirect ke halaman sesuai role
    $role = session()->get('role');
    if ($role === 'admin' || $role === 'petugas') {
        return redirect()->to(base_url('/dashboard'));
    }
}
?>

<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= csrf_hash() ?>">
    <title><?= $title ?? 'Portal Siswa - SPP SYSTEM' ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css">
    
    <!-- Custom CSS untuk Siswa -->
    <style>
        :root {
            --siswa-primary: #4e73df;
            --siswa-secondary: #858796;
            --siswa-success: #1cc88a;
            --siswa-warning: #f6c23e;
            --siswa-danger: #e74a3b;
            --siswa-info: #36b9cc;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fc;
            overflow-x: hidden;
            padding-right: 0 !important;
        }
        
        /* SIDEBAR SISWA - SAMA SEPERTI MAIN.PHP */
        .sidebar-siswa {
            min-height: 100vh;
            background: linear-gradient(180deg, var(--siswa-primary) 0%, #2e59d9 100%);
            color: white;
            position: fixed;
            width: 250px;
            padding-top: 20px;
            z-index: 100;
            overflow-y: auto;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-content {
            flex: 1;
            overflow-y: auto;
            padding-bottom: 10px;
        }
        
        .sidebar-siswa .nav-link {
            color: rgba(255, 255, 255, 0.9);
            padding: 12px 20px;
            margin: 2px 10px;
            border-radius: 8px;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        .sidebar-siswa .nav-link:hover,
        .sidebar-siswa .nav-link.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            border-left-color: white;
        }
        
        .sidebar-siswa .nav-link i {
            width: 20px;
            margin-right: 10px;
        }
        
        .main-content-siswa {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
            position: relative;
            z-index: 1;
            overflow-x: auto;
            width: calc(100% - 250px);
        }
        
        /* Styling untuk scrollbar di sidebar */
        .sidebar-siswa::-webkit-scrollbar {
            width: 6px;
        }
        
        .sidebar-siswa::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 3px;
        }
        
        .sidebar-siswa::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }
        
        .sidebar-siswa::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.4);
        }
        
        /* Card styling */
        .card-siswa {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .card-siswa:hover {
            transform: translateY(-5px);
        }
        
        .stat-card-siswa {
            border-left: 4px solid var(--siswa-secondary);
        }
        
        .stat-card-siswa .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--siswa-primary);
        }
        
        .btn-primary-siswa {
            background-color: var(--siswa-primary);
            border-color: var(--siswa-primary);
        }
        
        .btn-primary-siswa:hover {
            background-color: #2e59d9;
            border-color: #2e59d9;
        }
        
        .table-siswa th {
            background-color: var(--siswa-primary);
            color: white;
            border: none;
        }
        
        .badge-paid-siswa {
            background-color: var(--siswa-success);
        }
        
        .badge-unpaid-siswa {
            background-color: var(--siswa-danger);
        }
        
        /* MODAL FIX */
        .modal {
            z-index: 1060 !important;
        }
        
        .modal-backdrop {
            z-index: 1050 !important;
            background-color: rgba(0, 0, 0, 0.5) !important;
        }
        
        /* Payment Progress */
        .progress-siswa {
            height: 8px;
            border-radius: 4px;
            background-color: #e3e6f0;
        }
        
        .progress-bar-siswa {
            border-radius: 4px;
        }
        
        /* Table container untuk scroll horizontal */
        .table-container {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            margin-bottom: 1rem;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background: white;
        }
        
        .table-container table {
            margin-bottom: 0;
            min-width: 800px;
        }
        
        .table-container::-webkit-scrollbar {
            height: 8px;
        }
        
        .table-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        
        .table-container::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        
        .table-container::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        
        /* RESPONSIVE */
        @media (max-width: 768px) {
            .sidebar-siswa {
                width: 100%;
                position: fixed;
                left: -100%;
                transition: left 0.3s ease;
                z-index: 1000;
            }
            
            .sidebar-siswa.show {
                left: 0;
            }
            
            .main-content-siswa {
                margin-left: 0;
                width: 100%;
                overflow-x: visible;
            }
            
            .overlay-siswa {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 999;
                display: none;
            }
            
            .overlay-siswa.show {
                display: block;
            }
            
            .table-container {
                min-width: 100%;
            }
            
            .modal-dialog {
                margin: 10px;
                max-width: calc(100% - 20px);
            }
        }
        
        /* User info styling */
        .user-profile-siswa {
            padding: 15px;
            margin: 10px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
        }
        
        .user-avatar-siswa {
            width: 60px;
            height: 60px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        /* Footer sidebar */
        .sidebar-footer-siswa {
            padding: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <!-- Container utama -->
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Siswa -->
            <nav class="sidebar-siswa d-none d-md-block">
                <!-- Logo & System Name -->
                <div class="text-center mb-4 pt-3">
                    <div class="mb-3">
                        <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center" 
                             style="width: 50px; height: 50px;">
                            <i class="bi bi-mortarboard-fill text-primary fs-4"></i>
                        </div>
                    </div>
                    <h5 class="mb-1 fw-bold">Portal Siswa</h5>
                    <small class="opacity-75">SPP Payment System</small>
                </div>
                
                <div class="sidebar-content">
                    <!-- User Profile -->
                    <div class="user-profile-siswa">
                        <div class="d-flex align-items-center">
                            <div class="user-avatar-siswa me-3">
                                <i class="bi bi-person-fill"></i>
                            </div>
                            <div>
                                <h6 class="mb-1 fw-bold"><?= session()->get('nama_lengkap') ?></h6>
                                <small class="opacity-75 d-block">
                                    <i class="bi bi-mortarboard me-1"></i>
                                    <?= session()->get('nama_kelas') ?>
                                </small>
                                <small class="opacity-75 d-block">
                                    <i class="bi bi-tag me-1"></i>
                                    NISN: <?= session()->get('nisn') ?>
                                </small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Navigation Menu -->
                    <ul class="nav flex-column mt-2">
                        <li class="nav-item">
                            <a class="nav-link <?= (current_url() == base_url('siswa/dashboard_siswa')) ? 'active' : '' ?>" 
                               href="<?= base_url('siswa/dashboard_siswa') ?>">
                                <i class="bi bi-house-door"></i> Dashboard
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?= strpos(current_url(), 'siswa/history_siswa') !== false ? 'active' : '' ?>" 
                               href="<?= base_url('siswa/history_siswa') ?>">
                                <i class="bi bi-clock-history"></i> Riwayat Pembayaran
                                <?php if(isset($total_payments) && $total_payments > 0): ?>
                                <span class="badge bg-success float-end"><?= $total_payments ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?= strpos(current_url(), 'siswa/profile') !== false ? 'active' : '' ?>" 
                               href="<?= base_url('siswa/profile_siswa') ?>">
                                <i class="bi bi-person"></i> Profile Saya
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?= strpos(current_url(), 'siswa/pembayaran_siswa') !== false ? 'active' : '' ?>" 
                               href="<?= base_url('siswa/pembayaran_siswa') ?>">
                                <i class="bi bi-cash-stack"></i> Bayar SPP
                                <?php 
                                $unpaid_months = 12 - ($bulan_bayar ?? 0);
                                if($unpaid_months > 0): 
                                ?>
                                <span class="badge bg-danger float-end"><?= $unpaid_months ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?= strpos(current_url(), 'siswa/change-password') !== false ? 'active' : '' ?>" 
                               href="<?= base_url('siswa/change-password') ?>">
                                <i class="bi bi-key"></i> Ganti Password
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?= strpos(current_url(), 'siswa/print-history') !== false ? 'active' : '' ?>" 
                               href="<?= base_url('siswa/print-history') ?>">
                                <i class="bi bi-printer"></i> Cetak Pembayaran
                            </a>
                        </li>
                        
                        <li class="nav-divider my-3 border-top opacity-25"></li>
                        
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="<?= base_url('logout') ?>"
                               onclick="return confirm('Yakin ingin logout?')">
                                <i class="bi bi-box-arrow-right"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
                
              
            </nav>
            
            <!-- Main Content -->
            <main class="main-content-siswa">
                <!-- Navbar Mobile -->
                <nav class="navbar navbar-siswa d-md-none mb-3" style="background: linear-gradient(180deg, var(--siswa-primary) 0%, #2e59d9 100%);">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" id="sidebarToggleMobile" style="border-color: white;">
                            <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
                        </button>
                        <a class="navbar-brand text-white fw-bold" href="#">Portal Siswa</a>
                        <div class="dropdown">
                            <a href="#" class="text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                                <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center" 
                                     style="width: 40px; height: 40px;">
                                    <i class="bi bi-person text-primary"></i>
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a class="dropdown-item" href="<?= base_url('siswa/profile_siswa') ?>">
                                        <i class="bi bi-person me-2"></i>Profile
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?= base_url('siswa/change-password') ?>">
                                        <i class="bi bi-key me-2"></i>Ganti Password
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="<?= base_url('/logout') ?>"
                                       onclick="return confirm('Yakin ingin logout dari sistem?')">
                                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                
                <!-- Overlay for mobile sidebar -->
                <div class="overlay-siswa" id="sidebarOverlay"></div>
                
                <!-- Page Content -->
                <div class="container-fluid">
                    <?php if(session()->getFlashdata('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle me-2"></i>
                            <?= session()->getFlashdata('success') ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <?= session()->getFlashdata('error') ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?= $this->renderSection('content') ?>
                </div>
                
                <!-- Footer -->
                <footer class="mt-5 pt-3 border-top">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="text-muted">
                                &copy; <?= date('Y') ?> Portal Siswa - Sistem Pembayaran SPP
                            </p>
                        </div>
                        <div class="col-md-6 text-end">
                            <p class="text-muted">
                                NISN: <?= session()->get('nisn') ?> | 
                                Kelas: <?= session()->get('nama_kelas') ?>
                            </p>
                        </div>
                    </div>
                </footer>
            </main>
        </div>
    </div>
    
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        // Initialize DataTables
        $(document).ready(function() {
            $('.table-siswa').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json'
                },
                scrollX: true,
                responsive: true,
                pageLength: 10,
                lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "Semua"]]
            });
            
            // Mobile sidebar toggle
            const sidebarToggle = document.getElementById('sidebarToggleMobile');
            const sidebar = document.querySelector('.sidebar-siswa');
            const overlay = document.getElementById('sidebarOverlay');
            
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', function() {
                    sidebar.classList.toggle('show');
                    overlay.classList.toggle('show');
                });
            }
            
            if (overlay) {
                overlay.addEventListener('click', function() {
                    sidebar.classList.remove('show');
                    overlay.classList.remove('show');
                });
            }
            
            // Close sidebar on link click (mobile)
            const sidebarLinks = document.querySelectorAll('.sidebar-siswa .nav-link');
            sidebarLinks.forEach(link => {
                link.addEventListener('click', function() {
                    if (window.innerWidth < 768) {
                        sidebar.classList.remove('show');
                        overlay.classList.remove('show');
                    }
                });
            });
            
            // MODAL FIX - SAMA SEPERTI DI MAIN.PHP
            $(document).on('show.bs.modal', '.modal', function() {
                $(this).css('z-index', 1060);
                $('.modal-backdrop').css('z-index', 1050);
                $('body').addClass('modal-open');
                $('body').css('padding-right', '0');
            });
            
            $(document).on('hidden.bs.modal', '.modal', function() {
                $('body').removeClass('modal-open');
                $('body').css('padding-right', '');
                $('.modal-backdrop').remove();
            });
            
            // Force remove any existing backdrop
            $('button[data-bs-toggle="modal"]').click(function() {
                $('.modal-backdrop').remove();
                $('body').removeClass('modal-open');
            });
            
            // Emergency fix: Click handler untuk modal
            $(document).on('click', '[data-bs-toggle="modal"]', function(e) {
                e.preventDefault();
                
                $('.modal-backdrop').remove();
                
                var target = $(this).data('bs-target');
                
                $(target).modal({
                    backdrop: true,
                    keyboard: true
                });
                
                $(target).modal('show');
                
                setTimeout(function() {
                    $(target).css('z-index', 1060);
                    $('.modal-backdrop').css('z-index', 1050);
                }, 10);
            });
            
            // Auto-dismiss alerts
            setTimeout(function() {
                $('.alert').alert('close');
            }, 5000);
            
            // Payment reminder based on date
            const today = new Date();
            const day = today.getDate();
            const unpaidMonths = <?= 12 - ($bulan_bayar ?? 0) ?>;
            
            if (day >= 25 && unpaidMonths > 0) {
                showNotification(`Anda memiliki ${unpaidMonths} bulan yang belum dibayar. Segera lakukan pembayaran sebelum akhir bulan!`, 'warning');
            }
            
            function showNotification(message, type) {
                const notification = document.createElement('div');
                notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
                notification.style.cssText = 'z-index: 9999; max-width: 400px;';
                notification.innerHTML = `
                    <i class="bi bi-${type === 'danger' ? 'exclamation-triangle' : 'exclamation-circle'} me-2"></i>
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 8000);
            }
            
            // Handle window resize
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 768) {
                    sidebar.classList.remove('show');
                    overlay.classList.remove('show');
                }
            });
        });
        
        // Theme Toggle (opsional)
        const themeToggle = document.createElement('button');
        themeToggle.className = 'btn btn-sm btn-outline-secondary position-fixed bottom-0 end-0 m-3';
        themeToggle.innerHTML = '<i class="bi bi-moon"></i>';
        themeToggle.onclick = function() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-bs-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-bs-theme', newTheme);
            this.innerHTML = newTheme === 'dark' ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon"></i>';
        };
        document.body.appendChild(themeToggle);
    </script>
    
    <?= $this->renderSection('scripts') ?>
</body>
</html>