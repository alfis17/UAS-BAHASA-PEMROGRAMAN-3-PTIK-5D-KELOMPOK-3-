<?= $this->extend('layout/main'); ?>

<?= $this->section('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h2 class="fw-bold"><i class="bi bi-file-earmark-text"></i> Index Laporan Pembayaran</h2>
        <p class="text-muted">Lihat data pembayaran SPP secara keseluruhan.</p>
    </div>
    <div class="col-auto">
        <button class="btn btn-success" onclick="window.print()">
            <i class="bi bi-printer"></i> Cetak Laporan
        </button>
    </div>
</div>

<!-- Summary Cards -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title">Total Pembayaran</h6>
                        <h3 class="mb-0"><?= $total_pembayaran ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-receipt fs-1 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title">Total Nominal</h6>
                        <h3 class="mb-0">Rp <?= number_format($total_nominal, 0, ',', '.') ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-cash fs-1 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title">Rata-rata</h6>
                        <h3 class="mb-0">Rp <?= $total_pembayaran > 0 ? number_format($total_nominal / $total_pembayaran, 0, ',', '.') : '0' ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-graph-up fs-1 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Data Table -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Data Pembayaran Terbaru</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Tanggal Bayar</th>
                        <th>Nama Siswa</th>
                        <th>NISN</th>
                        <th>Kelas</th>
                        <th>Tahun</th>
                        <th>Nominal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($pembayaran as $p): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= date('d/m/Y', strtotime($p['tanggal_bayar'])) ?></td>
                        <td><?= $p['nama_siswa'] ?></td>
                        <td><?= $p['nisn'] ?></td>
                        <td><?= $p['nama_kelas'] ?></td>
                        <td><?= $p['tahun'] ?></td>
                        <td class="text-success fw-bold">Rp <?= number_format($p['nominal'], 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Print Styles -->
<style>
@media print {
    .sidebar, .btn, .card-header {
        display: none !important;
    }
    .main-content {
        margin-left: 0 !important;
    }
    table {
        border-collapse: collapse;
        width: 100%;
    }
    th, td {
        border: 1px solid #000;
        padding: 8px;
        text-align: left;
    }
    .text-success {
        color: #000 !important;
    }
}
</style>

<?= $this->endSection(); ?>
