<?= $this->extend('layout/main'); ?>

<?= $this->section('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">
                        <i class="bi bi-pencil-square"></i> Edit Pembayaran SPP
                    </h4>
                </div>
                <div class="card-body">
                    <?php if (session()->getFlashdata('errors')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <strong>Terjadi Kesalahan:</strong>
                            <ul class="mb-0">
                                <?php foreach (session()->getFlashdata('errors') as $error): ?>
                                    <li><?= $error ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i> <?= session()->getFlashdata('error') ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?= base_url('/pembayaran/edit/' . (is_array($pembayaran) ? $pembayaran['id'] : $pembayaran->id)) ?>" method="post">
                        <?= csrf_field() ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Siswa</label>
                                    <?php
                                    // Handle both array and object formats
                                    $nama_siswa = is_array($pembayaran) ? $pembayaran['nama_siswa'] : $pembayaran->nama_siswa;
                                    $nisn = is_array($pembayaran) ? $pembayaran['nisn'] : $pembayaran->nisn;
                                    ?>
                                    <input type="text" class="form-control" value="<?= $nama_siswa ?> (NISN: <?= $nisn ?>)" readonly>
                                    <small class="text-muted">Data siswa tidak dapat diubah</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Kelas</label>
                                    <?php
                                    // Handle both array and object formats
                                    $nama_kelas = is_array($pembayaran) ? ($pembayaran['nama_kelas'] ?? 'Belum ada kelas') : ($pembayaran->nama_kelas ?? 'Belum ada kelas');
                                    ?>
                                    <input type="text" class="form-control" value="<?= $nama_kelas ?>" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="bulan" class="form-label">Bulan <span class="text-danger">*</span></label>
                                    <select class="form-select" id="bulan" name="bulan" required>
                                        <?php
                                        $bulan_list = [
                                            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                                            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                                        ];
                                        $bulan_value = is_array($pembayaran) ? $pembayaran['bulan'] : $pembayaran->bulan;
                                        foreach ($bulan_list as $bulan_option): ?>
                                            <option value="<?= $bulan_option ?>" <?= $bulan_option == $bulan_value ? 'selected' : '' ?>>
                                                <?= $bulan_option ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="tahun" class="form-label">Tahun <span class="text-danger">*</span></label>
                                    <select class="form-select" id="tahun" name="tahun" required>
                                        <?php
                                        $current_year = date('Y');
                                        $tahun_value = is_array($pembayaran) ? $pembayaran['tahun'] : $pembayaran->tahun;
                                        for ($year = $current_year - 2; $year <= $current_year + 1; $year++): ?>
                                            <option value="<?= $year ?>" <?= $year == $tahun_value ? 'selected' : '' ?>>
                                                <?= $year ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="status_pembayaran" class="form-label">Status Pembayaran <span class="text-danger">*</span></label>
                                    <select class="form-select" id="status_pembayaran" name="status_pembayaran" required>
                                        <?php $status_value = is_array($pembayaran) ? $pembayaran['status_pembayaran'] : $pembayaran->status_pembayaran; ?>
                                        <option value="Lunas" <?= $status_value == 'Lunas' ? 'selected' : '' ?>>Lunas</option>
                                        <option value="Belum Lunas" <?= $status_value == 'Belum Lunas' ? 'selected' : '' ?>>Belum Lunas</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="jumlah_bayar" class="form-label">Jumlah Bayar <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">Rp</span>
                                        <input type="number"
                                               class="form-control"
                                               id="jumlah_bayar"
                                               name="jumlah_bayar"
                                               value="<?= is_array($pembayaran) ? $pembayaran['jumlah_bayar'] : $pembayaran->jumlah_bayar ?>"
                                               min="1000"
                                               step="1000"
                                               required>
                                    </div>
                                    <small class="text-muted">Isi tanpa titik/koma (contoh: 500000)</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="metode_pembayaran" class="form-label">Metode Pembayaran <span class="text-danger">*</span></label>
                                    <select class="form-select" id="metode_pembayaran" name="metode_pembayaran" required>
                                        <?php $metode_value = is_array($pembayaran) ? $pembayaran['metode_pembayaran'] : $pembayaran->metode_pembayaran; ?>
                                        <option value="Tunai" <?= $metode_value == 'Tunai' ? 'selected' : '' ?>>Tunai</option>
                                        <option value="Transfer" <?= $metode_value == 'Transfer' ? 'selected' : '' ?>>Transfer</option>
                                        <option value="QRIS" <?= $metode_value == 'QRIS' ? 'selected' : '' ?>>QRIS</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="keterangan" class="form-label">Keterangan</label>
                            <textarea class="form-control" id="keterangan" name="keterangan" rows="3"
                                      placeholder="Catatan tambahan pembayaran..."><?= is_array($pembayaran) ? ($pembayaran['keterangan'] ?? '') : ($pembayaran->keterangan ?? '') ?></textarea>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <hr>
                                <div class="d-flex justify-content-between">
                                    <a href="<?= base_url('/pembayaran') ?>" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Kembali
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Update Pembayaran
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>
<script>
$(document).ready(function() {
    // Format number input
    $('#jumlah_bayar').on('input', function() {
        let value = $(this).val();
        // Remove any non-numeric characters except decimal point
        value = value.replace(/[^\d]/g, '');
        $(this).val(value);
    });

    // Auto-format display (optional)
    $('#jumlah_bayar').on('blur', function() {
        let value = $(this).val();
        if (value) {
            // You can add number formatting here if needed
        }
    });
});
</script>
<?= $this->endSection(); ?>
