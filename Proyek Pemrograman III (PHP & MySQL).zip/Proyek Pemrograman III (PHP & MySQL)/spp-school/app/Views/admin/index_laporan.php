<?= $this->extend('layout/main'); ?>

<?= $this->section('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h2 class="fw-bold"><i class="bi bi-file-earmark-text"></i> Laporan Pembayaran</h2>
        <p class="text-muted">Lihat dan cetak laporan pembayaran SPP.</p>
    </div>
    <div class="col-auto">
        <button class="btn btn-success" onclick="window.print()">
            <i class="bi bi-printer"></i> Cetak Laporan
        </button>
    </div>
</div>

<!-- Filter Form -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Bulan</label>
                <select class="form-select" name="bulan">
                    <option value="">Semua Bulan</option>
                    <?php
                    $months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
                              'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                    foreach($months as $m):
                    ?>
                    <option value="<?= $m ?>" <?= (isset($bulan) && $bulan == $m) ? 'selected' : '' ?>><?= $m ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-4">
                <label class="form-label">Tahun</label>
                <select class="form-select" name="tahun">
                    <option value="">Semua Tahun</option>
                    <?php for($i = date('Y') - 2; $i <= date('Y') + 1; $i++): ?>
                    <option value="<?= $i ?>" <?= (isset($tahun) && $tahun == $i) ? 'selected' : '' ?>><?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div class="col-md-4 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-filter"></i> Filter Laporan
                </button>
            </div>
        </form>
    </div>
</div>

<?php if(!empty($rekap)): ?>
<!-- Summary Report -->
<div class="row mb-4">
    <div class="col">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Rekap Pembayaran 
                    <?php if(isset($bulan) && isset($tahun) && $bulan && $tahun): ?>
                        - <?= $bulan ?> <?= $tahun ?>
                    <?php elseif(!isset($bulan) || !$bulan): ?>
                        - Semua Bulan
                    <?php endif; ?>
                </h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead class="table-light">
                            <tr>
                                <th width="25%">Periode</th>
                                <th width="15%" class="text-center">Total Transaksi</th>
                                <th width="25%">Total Pembayaran</th>
                                <th width="20%">Metode Pembayaran</th>
                                <th width="15%">Rata-rata</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $grandTotalTransaksi = 0;
                            $grandTotalPembayaran = 0;
                            ?>
                            <?php foreach($rekap as $r): ?>
                                <?php
                                // Handle both array and object formats
                                $total_transaksi = is_array($r) ? $r['total_transaksi'] : $r->total_transaksi;
                                $total_pembayaran = is_array($r) ? $r['total_pembayaran'] : $r->total_pembayaran;
                                $periode = is_array($r) ? $r['periode'] : $r->periode;
                                $metode_pembayaran = is_array($r) ? $r['metode_pembayaran'] : $r->metode_pembayaran;

                                $grandTotalTransaksi += $total_transaksi;
                                $grandTotalPembayaran += $total_pembayaran;
                                $rataTransaksi = $total_transaksi > 0 ? $total_pembayaran / $total_transaksi : 0;
                                ?>
                                <tr>
                                    <td><?= $periode ?></td>
                                    <td class="text-center"><?= number_format($total_transaksi, 0, ',', '.') ?></td>
                                    <td class="text-success fw-bold">Rp <?= number_format($total_pembayaran, 0, ',', '.') ?></td>
                                    <td>
                                        <span class="badge
                                            <?= $metode_pembayaran == 'Tunai' ? 'bg-primary' : '' ?>
                                            <?= $metode_pembayaran == 'Transfer' ? 'bg-success' : '' ?>
                                            <?= $metode_pembayaran == 'QRIS' ? 'bg-warning text-dark' : '' ?>
                                        ">
                                            <?= $metode_pembayaran ?>
                                        </span>
                                    </td>
                                    <td class="text-info">Rp <?= number_format($rataTransaksi, 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot class="table-active fw-bold">
                            <tr>
                                <td>GRAND TOTAL</td>
                                <td class="text-center"><?= number_format($grandTotalTransaksi, 0, ',', '.') ?></td>
                                <td class="text-success">Rp <?= number_format($grandTotalPembayaran, 0, ',', '.') ?></td>
                                <td colspan="2" class="text-center">-</td>
                            </tr>
                            <?php if($grandTotalTransaksi > 0): ?>
                            <tr>
                                <td colspan="4" class="text-end">Rata-rata per Transaksi:</td>
                                <td class="text-info fw-bold">Rp <?= number_format($grandTotalPembayaran / $grandTotalTransaksi, 0, ',', '.') ?></td>
                            </tr>
                            <?php endif; ?>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Detail Report -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Detail Pembayaran
            <?php if(isset($bulan) && isset($tahun) && $bulan && $tahun): ?>
                - <?= $bulan ?> <?= $tahun ?>
            <?php elseif(!isset($bulan) || !$bulan): ?>
                - Semua Data
            <?php endif; ?>
        </h5>
        <div class="badge bg-info">
            <i class="bi bi-receipt"></i> Total Data: <?= count($pembayaran) ?>
        </div>
    </div>
    <div class="card-body">
        <?php if(empty($pembayaran)): ?>
            <div class="text-center py-5">
                <i class="bi bi-file-earmark-x fs-1 text-muted"></i>
                <h5 class="mt-3">Tidak ada data pembayaran</h5>
                <p class="text-muted">Tidak ada data pembayaran untuk periode yang dipilih.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover table-striped" id="dataTable">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">No</th>
                            <th width="15%">Tanggal</th>
                            <th width="25%">Siswa</th>
                            <th width="12%">Kelas</th>
                            <th width="13%">Bulan/Tahun</th>
                            <th width="15%">Jumlah</th>
                            <th width="15%">Metode</th>
                            <th width="15%">Petugas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        $totalSemua = 0;
                        ?>
                        <?php foreach($pembayaran as $d): ?>
                        <?php 
                        $totalSemua += isset($d['jumlah_bayar']) ? $d['jumlah_bayar'] : 0;
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <small><?= isset($d['tanggal_bayar']) ? date('d/m/Y', strtotime($d['tanggal_bayar'])) : '-' ?></small>
                                <br>
                                <small class="text-muted"><?= isset($d['tanggal_bayar']) ? date('H:i', strtotime($d['tanggal_bayar'])) : '' ?></small>
                            </td>
                            <td>
                                <strong><?= !empty($d['nama_siswa']) ? $d['nama_siswa'] : 'ID: ' . ($d['siswa_id'] ?? 'N/A') ?></strong><br>
                                <small class="text-muted">NISN: <?= $d['nisn'] ?? 'N/A' ?></small>
                            </td>
                            <td>
                                <span class="badge bg-info"><?= $d['nama_kelas'] ?? '-' ?></span>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?= $d['bulan'] ?? '-' ?> <?= $d['tahun'] ?? '' ?></span>
                            </td>
                            <td class="fw-bold text-success">
                                Rp <?= isset($d['jumlah_bayar']) ? number_format($d['jumlah_bayar'], 0, ',', '.') : '0' ?>
                            </td>
                            <td>
                                <span class="badge 
                                    <?= ($d['metode_pembayaran'] ?? '') == 'Tunai' ? 'bg-primary' : '' ?>
                                    <?= ($d['metode_pembayaran'] ?? '') == 'Transfer' ? 'bg-success' : '' ?>
                                    <?= ($d['metode_pembayaran'] ?? '') == 'QRIS' ? 'bg-warning text-dark' : '' ?>
                                ">
                                    <?= $d['metode_pembayaran'] ?? '-' ?>
                                </span>
                            </td>
                            <td>
                                <small><?= $d['petugas'] ?? '-' ?></small>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="table-active">
                        <tr>
                            <td colspan="5" class="text-end fw-bold">TOTAL SEMUA:</td>
                            <td class="fw-bold text-success">Rp <?= number_format($totalSemua, 0, ',', '.') ?></td>
                            <td colspan="2" class="text-center">-</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Print Styles -->
<style>
    @media print {
        .sidebar, .main-content nav, .btn, .no-print, #dataTable_length, #dataTable_filter, 
        #dataTable_info, #dataTable_paginate, #dataTable_wrapper .dt-buttons,
        .dataTables_wrapper .dataTables_filter,
        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_paginate,
        .badge.bg-info {
            display: none !important;
        }
        
        .main-content {
            margin-left: 0 !important;
            padding: 0 !important;
        }
        
        .card {
            border: 1px solid #000 !important;
            box-shadow: none !important;
            margin-bottom: 20px !important;
        }
        
        .card-header {
            background-color: #f8f9fa !important;
            border-bottom: 1px solid #000 !important;
        }
        
        table {
            border: 1px solid #000 !important;
            width: 100% !important;
        }
        
        th, td {
            border: 1px solid #000 !important;
            padding: 8px !important;
        }
        
        .badge {
            border: 1px solid #000 !important;
            background-color: #fff !important;
            color: #000 !important;
            padding: 2px 6px !important;
        }
        
        .text-success {
            color: #000 !important;
            font-weight: bold !important;
        }
        
        .table-active {
            background-color: #f8f9fa !important;
        }
        
        tfoot {
            font-weight: bold !important;
        }
        
        h5.card-title {
            font-size: 18px !important;
            margin-bottom: 10px !important;
        }
        
        /* Show only essential content */
        .card-body {
            padding: 15px !important;
        }
    }
    
    /* Improve table appearance */
    #dataTable {
        font-size: 14px;
    }
    
    #dataTable th {
        white-space: nowrap;
    }
    
    #dataTable td {
        vertical-align: middle;
    }
    
    .badge.bg-secondary {
        background-color: #6c757d !important;
    }
    
    .badge.bg-info {
        background-color: #0dcaf0 !important;
    }
    
    .badge.bg-primary {
        background-color: #0d6efd !important;
    }
    
    .badge.bg-success {
        background-color: #198754 !important;
    }
    
    .badge.bg-warning {
        background-color: #ffc107 !important;
    }
</style>

<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>
<!-- DataTables CSS & JS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>

<script>
$(document).ready(function() {
    // Initialize DataTables if not already initialized
    if (!$.fn.DataTable.isDataTable('#dataTable')) {
        $('#dataTable').DataTable({
            "dom": '<"row"<"col-md-6"B><"col-md-6"f>>rt<"row"<"col-md-6"l><"col-md-6"p>>',
            "buttons": [
                {
                    extend: 'excel',
                    text: '<i class="bi bi-file-excel"></i> Excel',
                    className: 'btn btn-success btn-sm',
                    title: 'Laporan Pembayaran SPP',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7]
                    }
                },
                {
                    extend: 'pdf',
                    text: '<i class="bi bi-file-pdf"></i> PDF',
                    className: 'btn btn-danger btn-sm',
                    title: 'Laporan Pembayaran SPP',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7]
                    }
                },
                {
                    extend: 'print',
                    text: '<i class="bi bi-printer"></i> Print',
                    className: 'btn btn-primary btn-sm',
                    title: 'Laporan Pembayaran SPP',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7]
                    },
                    customize: function (win) {
                        $(win.document.body).find('h1').css('text-align', 'center');
                        $(win.document.body).find('table').addClass('print-table');
                    }
                }
            ],
            "pageLength": 25,
            "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Semua"]],
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json"
            },
            "order": [[1, 'desc']], // Urutkan berdasarkan tanggal (kolom 1) descending
            "responsive": true,
            "autoWidth": false,
            "destroy": true
        });
    }
    
    // Add custom CSS for print
    $('head').append('<style>' +
        '@media print {' +
        '  .print-table th, .print-table td { border: 1px solid #000 !important; }' +
        '  .print-table { border-collapse: collapse !important; }' +
        '}' +
        '</style>');
});
</script>
<?= $this->endSection(); ?>