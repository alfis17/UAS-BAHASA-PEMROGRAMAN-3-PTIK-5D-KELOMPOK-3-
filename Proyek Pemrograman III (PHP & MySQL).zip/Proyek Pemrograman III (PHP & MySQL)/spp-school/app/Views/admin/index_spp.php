<?= $this->extend('layout/main'); ?>

<?= $this->section('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h2 class="fw-bold"><i class="bi bi-cash-coin"></i> <?= $page_title ?? 'Data SPP' ?></h2>
        <p class="text-muted">Kelola tarif SPP per tingkat dan tahun ajaran.</p>
    </div>
    <div class="col-auto">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
            <i class="bi bi-plus-circle"></i> Tambah Data SPP
        </button>
    </div>
</div>

<!-- Flash Messages -->
<?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i> <?= session()->getFlashdata('success') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i> <?= session()->getFlashdata('error') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- Filter Section -->
<div class="card mb-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" id="searchInput" class="form-control" placeholder="Cari tahun ajaran atau tingkat...">
                </div>
            </div>
            <div class="col-md-4">
                <select id="filterTahun" class="form-select">
                    <option value="">Semua Tahun Ajaran</option>
                    <?php foreach($tahun_list ?? [] as $tahun): ?>
                        <option value="<?= $tahun ?>"><?= $tahun ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <select id="filterTingkat" class="form-select">
                    <option value="">Semua Tingkat</option>
                    <option value="X">Kelas X</option>
                    <option value="XI">Kelas XI</option>
                    <option value="XII">Kelas XII</option>
                </select>
            </div>
        </div>
    </div>
</div>

<!-- SPP Table -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Daftar Tarif SPP</h5>
    </div>
    <div class="card-body">
        <?php if(empty($spp)): ?>
            <div class="text-center py-5">
                <i class="bi bi-database-x" style="font-size: 3rem; color: #6c757d;"></i>
                <h5 class="mt-3">Belum ada data SPP</h5>
                <p class="text-muted">Klik tombol "Tambah Data SPP" untuk menambahkan data baru.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover" id="sppTable">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th>Tahun Ajaran</th>
                            <th>Tingkat</th>
                            <th>Nominal SPP</th>
                            <th>Dibuat</th>
                            <th width="15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach($spp as $s): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="fw-bold"><?= $s->tahun_ajaran ?></span>
                            </td>
                            <td>
                                <span class="badge bg-info fs-6">Kelas <?= $s->tingkat ?></span>
                            </td>
                            <td class="fw-bold text-success">
                                Rp <?= number_format($s->nominal, 0, ',', '.') ?>
                                <small class="text-muted d-block">/bulan</small>
                            </td>
                            <td>
                                <small><?= date('d/m/Y', strtotime($s->created_at)) ?></small>
                                <br>
                                <small class="text-muted"><?= date('H:i', strtotime($s->created_at)) ?></small>
                            </td>
                            <!-- Ganti bagian ini di table body: -->
                    <td>
                        <div class="btn-group" role="group">
                            <button class="btn btn-sm btn-outline-warning edit-spp" 
                                    data-id="<?= $s->id ?>" 
                                    data-tahun="<?= $s->tahun_ajaran ?>"
                                    data-tingkat="<?= $s->tingkat ?>"
                                    data-nominal="<?= $s->nominal ?>"
                                    data-bs-toggle="modal" 
                                    data-bs-target="#editModal"
                                    title="Edit">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-spp" 
                                    data-id="<?= $s->id ?>" 
                                    data-info="<?= $s->tahun_ajaran ?> - Kelas <?= $s->tingkat ?>"
                                    data-csrf="<?= csrf_hash() ?>"
                                    title="Hapus">
                                <i class="bi bi-trash"></i>
                            </button>
                            <!-- Ganti link dengan button untuk modal detail -->
                            <button class="btn btn-sm btn-outline-info detail-spp" 
                                    data-id="<?= $s->id ?>"
                                    data-bs-toggle="modal" 
                                    data-bs-target="#detailModal"
                                    title="Detail">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                    </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Summary Cards -->
<div class="row mt-4">
    <div class="col-md-3">
        <div class="card border-primary">
            <div class="card-body text-center">
                <i class="bi bi-calendar-week text-primary" style="font-size: 2rem;"></i>
                <h6 class="mt-2">Total Data SPP</h6>
                <h3 class="text-primary"><?= count($spp) ?></h3>
                <small class="text-muted">Jumlah entri</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-success">
            <div class="card-body text-center">
                <i class="bi bi-calculator text-success" style="font-size: 2rem;"></i>
                <h6 class="mt-2">Rata-rata SPP/bulan</h6>
                <?php
                $total = 0;
                $count = count($spp);
                foreach($spp as $s) {
                    $total += $s->nominal;
                }
                $average = $count > 0 ? $total / $count : 0;
                ?>
                <h3 class="text-success">Rp <?= number_format($average, 0, ',', '.') ?></h3>
                <small class="text-muted">Rata-rata semua tingkat</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-warning">
            <div class="card-body text-center">
                <i class="bi bi-person text-warning" style="font-size: 2rem;"></i>
                <h6 class="mt-2">SPP per Tahun/Siswa</h6>
                <?php $yearlyTotal = $average * 12; ?>
                <h3 class="text-warning">Rp <?= number_format($yearlyTotal, 0, ',', '.') ?></h3>
                <small class="text-muted">Untuk satu tahun penuh</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-info">
            <div class="card-body text-center">
                <i class="bi bi-people text-info" style="font-size: 2rem;"></i>
                <h6 class="mt-2">Estimasi Penerimaan</h6>
                <?php $estimated = $yearlyTotal * 100; ?>
                <h3 class="text-info">Rp <?= number_format($estimated, 0, ',', '.') ?></h3>
                <small class="text-muted">Untuk 100 siswa per tahun</small>
            </div>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addModalLabel">
                    <i class="bi bi-plus-circle me-2"></i>Tambah Data SPP
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= base_url('/spp/create') ?>" method="POST" id="addSppForm">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Tahun Ajaran <span class="text-danger">*</span></label>
                        <input type="text" class="form-control <?= session('errors.tahun_ajaran') ? 'is-invalid' : '' ?>" 
                               name="tahun_ajaran" 
                               placeholder="Contoh: 2023/2024" 
                               required
                               pattern="\d{4}\/\d{4}"
                               title="Format: YYYY/YYYY">
                        <?php if(session('errors.tahun_ajaran')): ?>
                            <div class="invalid-feedback">
                                <?= session('errors.tahun_ajaran') ?>
                            </div>
                        <?php endif; ?>
                        <small class="text-muted">Format: YYYY/YYYY</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Tingkat <span class="text-danger">*</span></label>
                        <select class="form-select <?= session('errors.tingkat') ? 'is-invalid' : '' ?>" 
                                name="tingkat" required>
                            <option value="">Pilih Tingkat</option>
                            <option value="X">Kelas X</option>
                            <option value="XI">Kelas XI</option>
                            <option value="XII">Kelas XII</option>
                        </select>
                        <?php if(session('errors.tingkat')): ?>
                            <div class="invalid-feedback">
                                <?= session('errors.tingkat') ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Nominal SPP <span class="text-danger">*</span></label>
                        <div class="input-group <?= session('errors.nominal') ? 'is-invalid' : '' ?>">
                            <span class="input-group-text">Rp</span>
                            <input type="text" class="form-control nominal-input" 
                                   name="nominal" 
                                   id="add_nominal"
                                   placeholder="500.000"
                                   required
                                   data-min="100000">
                            <input type="hidden" name="nominal_raw" id="add_nominal_raw">
                        </div>
                        <div id="add_min_error" class="text-danger small mt-1 d-none">
                            Minimal Rp 100.000
                        </div>
                        <?php if(session('errors.nominal')): ?>
                            <div class="invalid-feedback d-block">
                                <?= session('errors.nominal') ?>
                            </div>
                        <?php endif; ?>
                        <small class="text-muted">Gunakan titik sebagai pemisah ribuan. Minimal Rp 100.000</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i>Batal
                    </button>
                    <button type="submit" class="btn btn-primary" id="btnSave">
                        <i class="bi bi-save me-1"></i>Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">
                    <i class="bi bi-pencil-square me-2"></i>Edit Data SPP
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= base_url('/spp/update') ?>" method="POST" id="editSppForm">
                <?= csrf_field() ?>
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Tahun Ajaran <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" 
                               name="tahun_ajaran" 
                               id="edit_tahun_ajaran" 
                               required
                               pattern="\d{4}\/\d{4}">
                        <small class="text-muted">Format: YYYY/YYYY</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Tingkat <span class="text-danger">*</span></label>
                        <select class="form-select" name="tingkat" id="edit_tingkat" required>
                            <option value="">Pilih Tingkat</option>
                            <option value="X">Kelas X</option>
                            <option value="XI">Kelas XI</option>
                            <option value="XII">Kelas XII</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Nominal SPP <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="text" class="form-control nominal-input" 
                                   name="nominal" 
                                   id="edit_nominal"
                                   required
                                   data-min="100000">
                            <input type="hidden" name="nominal_raw" id="edit_nominal_raw">
                        </div>
                        <div id="edit_min_error" class="text-danger small mt-1 d-none">
                            Minimal Rp 100.000
                        </div>
                        <small class="text-muted">Gunakan titik sebagai pemisah ribuan</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i>Batal
                    </button>
                    <button type="submit" class="btn btn-primary" id="btnUpdate">
                        <i class="bi bi-check-circle me-1"></i>Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update header modal detail -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header bg-light text-dark">
                <h5 class="modal-title fw-bold" id="detailModalLabel">
                    <i class="bi bi-file-text me-2"></i>Detail Data SPP
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="detailContent">
                <div class="text-center py-4">
                    <div class="spinner-border text-secondary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2 text-muted">Memuat data...</p>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-lg me-1"></i>Tutup
                </button>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// Fungsi untuk format rupiah - tanpa titik untuk kemudahan
function formatRupiah(angka, prefix = 'Rp ') {
    if (!angka) return '';
    let number_string = angka.toString().replace(/[^,\d]/g, ''),
        split = number_string.split(','),
        rupiah = split[0];

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == '' ? rupiah : (rupiah ? prefix + rupiah : '');
}

// Fungsi untuk menghapus format rupiah
function unformatRupiah(rupiah) {
    if (!rupiah) return '';
    return rupiah.toString().replace(/\D/g, '');
}

$(document).ready(function() {
    
    // Format input nominal saat mengetik
    $(document).on('input', '.nominal-input', function() {
        let value = $(this).val();
        let rawValue = unformatRupiah(value);
        
        // Simpan nilai raw di hidden input
        $(this).next('input[name="nominal_raw"]').val(rawValue);
        
        // Format tampilan
        if (rawValue) {
            $(this).val(formatRupiah(rawValue, ''));
        }
        
        // Validasi minimum
        const minValue = parseInt($(this).data('min')) || 100000;
        const errorDivId = $(this).attr('id').includes('add') ? '#add_min_error' : '#edit_min_error';
        
        if (rawValue && parseInt(rawValue) < minValue) {
            $(errorDivId).removeClass('d-none');
            $(this).addClass('is-invalid');
        } else {
            $(errorDivId).addClass('d-none');
            $(this).removeClass('is-invalid');
        }
    });
    
    // Filter functionality
    $('#searchInput').on('keyup', function() {
        filterTable();
    });
    
    $('#filterTahun, #filterTingkat').on('change', function() {
        filterTable();
    });
    
    function filterTable() {
        const search = $('#searchInput').val().toLowerCase();
        const tahun = $('#filterTahun').val();
        const tingkat = $('#filterTingkat').val();
        
        $('#sppTable tbody tr').each(function() {
            const row = $(this);
            const tahunText = row.find('td:eq(1)').text().toLowerCase();
            const tingkatText = row.find('td:eq(2)').text().toLowerCase();
            const tingkatValue = row.find('.edit-spp').data('tingkat');
            
            const matchesSearch = search === '' || 
                tahunText.includes(search) || 
                tingkatText.includes(search);
            const matchesTahun = tahun === '' || tahunText.includes(tahun);
            const matchesTingkat = tingkat === '' || tingkatValue === tingkat;
            
            if (matchesSearch && matchesTahun && matchesTingkat) {
                row.show();
            } else {
                row.hide();
            }
        });
    }
    
    // Delete SPP - FIXED VERSION
$(document).on('click', '.delete-spp', function() {
    const id = $(this).data('id');
    const info = $(this).data('info');
    const csrfToken = $(this).data('csrf');
    
    Swal.fire({
        title: 'Hapus Data SPP?',
        html: `Apakah Anda yakin ingin menghapus data SPP <strong>${info}</strong>?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal',
        showLoaderOnConfirm: true,
        allowOutsideClick: () => !Swal.isLoading(),
        preConfirm: async () => {
            try {
                const response = await fetch('<?= base_url("/spp/delete/") ?>' + id, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: 'csrf_test_name=' + encodeURIComponent(csrfToken)
                });
                
                // Cek jika response adalah HTML bukan JSON
                const contentType = response.headers.get("content-type");
                if (contentType && contentType.indexOf("application/json") === -1) {
                    const text = await response.text();
                    throw new Error(`Server mengembalikan HTML bukan JSON. Status: ${response.status}`);
                }
                
                const data = await response.json();
                
                if (!response.ok) {
                    throw new Error(data.message || `HTTP ${response.status}`);
                }
                
                return data;
                
            } catch (error) {
                Swal.showValidationMessage(
                    `Request gagal: ${error.message}`
                );
                return null;
            }
        }
    }).then((result) => {
        if (result.isConfirmed && result.value) {
            if (result.value.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: result.value.message,
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => {
                    location.reload();
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: result.value.message || 'Terjadi kesalahan'
                });
            }
        }
    });
});
    
    // Form submission with AJAX
    $('#addSppForm').on('submit', function(e) {
        e.preventDefault();
        submitForm($(this), false);
    });
    
    $('#editSppForm').on('submit', function(e) {
        e.preventDefault();
        submitForm($(this), true);
    });
    
    function submitForm(form, isEdit) {
        const nominalInput = form.find('.nominal-input');
        const rawValue = nominalInput.next('input[name="nominal_raw"]').val();
        
        // Validasi minimal nominal
        const minValue = parseInt(nominalInput.data('min')) || 100000;
        if (!rawValue || parseInt(rawValue) < minValue) {
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: 'Nominal SPP minimal Rp 100.000'
            });
            return;
        }
        
        // Ganti nilai nominal dengan raw value sebelum submit
        nominalInput.val(rawValue);
        
        const formData = form.serialize();
        const url = form.attr('action');
        const submitBtn = form.find('button[type="submit"]');
        const originalBtnText = submitBtn.html();
        
        // Disable button and show loading
        submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...');
        
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false,
                        timerProgressBar: true,
                        didClose: () => {
                            // Close modal and reload page
                            if (isEdit) {
                                $('#editModal').modal('hide');
                            } else {
                                $('#addModal').modal('hide');
                                form[0].reset();
                            }
                            location.reload();
                        }
                    });
                } else {
                    let errorMessage = response.message || 'Terjadi kesalahan';
                    
                    if (response.errors) {
                        errorMessage = '<ul>';
                        $.each(response.errors, function(key, value) {
                            errorMessage += '<li>' + value + '</li>';
                        });
                        errorMessage += '</ul>';
                    }
                    
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        html: errorMessage
                    });
                }
            },
            error: function(xhr, status, error) {
                let errorMessage = 'Terjadi kesalahan pada server';
                
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.message) {
                        errorMessage = response.message;
                    }
                } catch (e) {
                    console.error('Error parsing response:', e);
                }
                
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: errorMessage
                });
            },
            complete: function() {
                // Re-enable button
                submitBtn.prop('disabled', false).html(originalBtnText);
            }
        });
    }
    
    // Reset form when modal is closed
    $('#addModal').on('hidden.bs.modal', function() {
        $(this).find('form')[0].reset();
        $(this).find('.is-invalid').removeClass('is-invalid');
        $(this).find('.invalid-feedback').remove();
        $('#add_min_error').addClass('d-none');
        $('#add_nominal_raw').val('');
    });
    
    $('#editModal').on('hidden.bs.modal', function() {
        $(this).find('form')[0].reset();
        $('#edit_min_error').addClass('d-none');
        $('#edit_nominal_raw').val('');
    });
    
    // Format tahun ajaran input
    $('input[name="tahun_ajaran"]').on('input', function() {
        let value = $(this).val().replace(/[^0-9\/]/g, '');
        
        if (value.length === 4 && !value.includes('/')) {
            value = value + '/';
        }
        
        if (value.length > 9) {
            value = value.substring(0, 9);
        }
        
        $(this).val(value);
    });
    
    // Edit SPP - Populate modal
    $(document).on('click', '.edit-spp', function() {
        const id = $(this).data('id');
        const tahun = $(this).data('tahun');
        const tingkat = $(this).data('tingkat');
        const nominal = $(this).data('nominal');

        // Populate form fields
        $('#edit_id').val(id);
        $('#edit_tahun_ajaran').val(tahun);
        $('#edit_tingkat').val(tingkat);
        $('#edit_nominal').val(formatRupiah(nominal, ''));
        $('#edit_nominal_raw').val(nominal);

        // Reset validation
        $('#edit_min_error').addClass('d-none');
        $('#edit_nominal').removeClass('is-invalid');
    });

    // Duplicate check for tahun ajaran and tingkat
    $('input[name="tahun_ajaran"], select[name="tingkat"]').on('change', function() {
        const tahun = $('input[name="tahun_ajaran"]').val();
        const tingkat = $('select[name="tingkat"]').val();
        const id = $('#edit_id').val();

        if (tahun && tingkat) {
            $.ajax({
                url: '<?= base_url("/spp/checkDuplicate") ?>',
                type: 'GET',
                data: {
                    tahun_ajaran: tahun,
                    tingkat: tingkat,
                    exclude_id: id || null
                },
                dataType: 'json',
                success: function(response) {
                    if (response.exists) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Peringatan',
                            text: 'Data SPP untuk tahun ajaran dan tingkat ini sudah ada',
                            timer: 3000,
                            showConfirmButton: false
                        });
                    }
                }
            });
        }
    });
});
    // ========== DETAIL SPP (AJAX) ==========
    $(document).on('click', '.detail-spp', function() {
    const id = $(this).data('id');
    
    // Show loading
    $('#detailContent').html(`
        <div class="text-center py-4">
            <div class="spinner-border text-info" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Memuat data...</p>
        </div>
    `);
    
    $.ajax({
        url: '<?= base_url("/spp/get/") ?>' + id + '?format=json',
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                const s = response.data;
                
                // Format tanggal Indonesia
                const createdDate = new Date(s.created_at);
                const updatedDate = new Date(s.updated_at);
                
                // Fungsi format tanggal Indonesia
                function formatDateIndonesian(date) {
                    const bulan = [
                        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                    ];
                    
                    const hari = date.getDate();
                    const bulanIndex = date.getMonth();
                    const tahun = date.getFullYear();
                    const jam = date.getHours().toString().padStart(2, '0');
                    const menit = date.getMinutes().toString().padStart(2, '0');
                    
                    return `${hari} ${bulan[bulanIndex]} ${tahun} pukul ${jam}.${menit}`;
                }
                
                const formattedCreated = formatDateIndonesian(createdDate);
                const formattedUpdated = formatDateIndonesian(updatedDate);
                
                // Hitung total per tahun
                const totalPerTahun = s.nominal * 12;
                
                // Format rupiah tanpa prefix
                const formatRupiahSimple = (angka) => {
                    return angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                };
                
                let html = `
                    <h4 class="text-center mb-4 fw-bold text-dark">Data SPP ${s.tahun_ajaran}</h4>
                    
                    <div class="text-center mb-4">
                        <span class="badge bg-secondary fs-6 px-3 py-2">
                            Kelas ${s.tingkat}
                        </span>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-borderless">
                            <tr>
                                <td width="35%" class="text-muted">Tahun Ajaran</td>
                                <td class="fw-bold">${s.tahun_ajaran}</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Tingkat</td>
                                <td class="fw-bold">Kelas ${s.tingkat}</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Nominal SPP (per Bulan)</td>
                                <td class="fw-bold text-success">
                                    <h5 class="mb-0">Rp ${formatRupiahSimple(s.nominal)}</h5>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-muted">Total SPP (per Tahun)</td>
                                <td class="fw-bold text-primary">
                                    <h5 class="mb-0">Rp ${formatRupiahSimple(totalPerTahun)}</h5>
                                    <small class="text-muted">(12 bulan)</small>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-muted">Status</td>
                                <td>
                                    <span class="badge ${s.status == 'active' ? 'bg-success' : 'bg-warning'} fs-6 px-3 py-1">
                                        ${s.status == 'active' ? 'Aktif' : 'Nonaktif'}
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-muted">Dibuat Pada</td>
                                <td>${formattedCreated}</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Diperbarui Pada</td>
                                <td>${formattedUpdated}</td>
                            </tr>
                        </table>
                    </div>
                    
                    <hr class="my-4">
                    
                    <div class="alert alert-light border">
                        <div class="d-flex align-items-start">
                            <div class="me-2">
                                <i class="bi bi-info-circle text-info fs-5"></i>
                            </div>
                            <div>
                                <strong>Informasi:</strong> Data SPP ini digunakan untuk menghitung pembayaran siswa kelas ${s.tingkat} pada tahun ajaran ${s.tahun_ajaran}.
                            </div>
                        </div>
                    </div>
                `;
                
                $('#detailContent').html(html);
            } else {
                $('#detailContent').html(`
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> 
                        ${response.message || 'Gagal memuat data SPP'}
                    </div>
                `);
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', error);
            $('#detailContent').html(`
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle"></i> 
                    Terjadi kesalahan saat memuat data SPP
                </div>
            `);
        }
    });
});


// Update fungsi formatRupiah jika belum ada
function formatRupiah(angka, prefix = 'Rp ') {
    if (!angka) return '';
    let number_string = angka.toString().replace(/[^,\d]/g, ''),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);
        
    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }
    
    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == '' ? rupiah : (rupiah ? prefix + rupiah : '');
}
</script>
<?= $this->endSection(); ?>