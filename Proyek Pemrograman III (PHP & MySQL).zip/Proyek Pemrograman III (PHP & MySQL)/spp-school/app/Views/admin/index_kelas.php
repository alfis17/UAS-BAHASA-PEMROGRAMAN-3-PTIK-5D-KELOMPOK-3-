<?= $this->extend('layout/main'); ?>

<?= $this->section('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h2 class="fw-bold"><i class="bi bi-building"></i> Data Kelas</h2>
        <p class="text-muted">Kelola data kelas dan wali kelas.</p>
    </div>
    <div class="col-auto">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
            <i class="bi bi-plus-circle"></i> Tambah Kelas
        </button>
    </div>
</div>

<!-- Flash Messages -->
<?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="bi bi-exclamation-triangle"></i> <?= session()->getFlashdata('error') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Classes Statistics -->
<div class="row mb-4">
    <?php foreach($kelas as $k):
        // Handle both array and object formats
        $isArray = is_array($k);
        $id = $isArray ? $k['id'] : $k->id;
        $nama_kelas = $isArray ? $k['nama_kelas'] : $k->nama_kelas;
        $tingkat = $isArray ? $k['tingkat'] : $k->tingkat;
        $jurusan = $isArray ? $k['jurusan'] : $k->jurusan;
        $wali_kelas = $isArray ? $k['wali_kelas'] : $k->wali_kelas;
        $jumlah_siswa = $isArray ? $k['jumlah_siswa'] : $k->jumlah_siswa;
        $kapasitas = $isArray ? $k['kapasitas'] : $k->kapasitas;
    ?>
    <div class="col-md-3 mb-3">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?= esc($nama_kelas) ?></h5>
                <p class="card-text">
                    <small class="text-muted">Tingkat: <?= esc($tingkat) ?> | <?= esc($jurusan) ?></small><br>
                    <small>Wali: <?= esc($wali_kelas) ?></small><br>
                    <small>Siswa: <?= $jumlah_siswa ?> / <?= $kapasitas ?></small>
                </p>
                <div class="d-flex justify-content-between">
                    <button class="btn btn-sm btn-outline-primary edit-kelas-btn"
                            data-id="<?= $id ?>"
                            data-nama="<?= esc($nama_kelas) ?>"
                            data-tingkat="<?= esc($tingkat) ?>"
                            data-jurusan="<?= esc($jurusan) ?>"
                            data-wali="<?= esc($wali_kelas) ?>"
                            data-kapasitas="<?= $kapasitas ?>"
                            data-bs-toggle="modal"
                            data-bs-target="#editModal">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger delete-kelas-btn"
                            data-id="<?= $id ?>"
                            data-name="<?= esc($nama_kelas) ?>">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Classes Table -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Daftar Kelas Lengkap</h5>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class="table table-hover" id="tableKelas">
                <thead>
                    <tr>
                        <th>Nama Kelas</th>
                        <th>Tingkat</th>
                        <th>Jurusan</th>
                        <th>Wali Kelas</th>
                        <th>Jumlah Siswa</th>
                        <th>Kapasitas</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($kelas as $k):
                        // Handle both array and object formats
                        $isArray = is_array($k);
                        $id = $isArray ? $k['id'] : $k->id;
                        $nama_kelas = $isArray ? $k['nama_kelas'] : $k->nama_kelas;
                        $tingkat = $isArray ? $k['tingkat'] : $k->tingkat;
                        $jurusan = $isArray ? $k['jurusan'] : $k->jurusan;
                        $wali_kelas = $isArray ? $k['wali_kelas'] : $k->wali_kelas;
                        $jumlah_siswa = $isArray ? $k['jumlah_siswa'] : $k->jumlah_siswa;
                        $kapasitas = $isArray ? $k['kapasitas'] : $k->kapasitas;
                    ?>
                    <tr>
                        <td><?= esc($nama_kelas) ?></td>
                        <td><span class="badge bg-info"><?= esc($tingkat) ?></span></td>
                        <td><?= esc($jurusan) ?></td>
                        <td><?= esc($wali_kelas) ?></td>
                        <td>
                            <span class="badge <?= $jumlah_siswa >= $kapasitas ? 'bg-danger' : 'bg-success' ?>">
                                <?= $jumlah_siswa ?>
                            </span>
                        </td>
                        <td><?= $kapasitas ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning edit-kelas-btn"
                                    data-id="<?= $id ?>"
                                    data-nama="<?= esc($nama_kelas) ?>"
                                    data-tingkat="<?= esc($tingkat) ?>"
                                    data-jurusan="<?= esc($jurusan) ?>"
                                    data-wali="<?= esc($wali_kelas) ?>"
                                    data-kapasitas="<?= $kapasitas ?>"
                                    data-bs-toggle="modal"
                                    data-bs-target="#editModal">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-sm btn-danger delete-kelas-btn"
                                    data-id="<?= $id ?>"
                                    data-name="<?= esc($nama_kelas) ?>">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal (AJAX) -->
<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addModalLabel">
                    <i class="bi bi-plus-circle"></i> Tambah Data Kelas
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="formTambahKelas" method="POST">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Kelas <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" 
                               name="nama_kelas" 
                               id="nama_kelas"
                               placeholder="Contoh: X IPA 1" 
                               required>
                        <div class="invalid-feedback" id="nama_kelas_error"></div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tingkat <span class="text-danger">*</span></label>
                            <select class="form-select" name="tingkat" id="tingkat" required>
                                <option value="">Pilih Tingkat</option>
                                <option value="X">Kelas X</option>
                                <option value="XI">Kelas XI</option>
                                <option value="XII">Kelas XII</option>
                            </select>
                            <div class="invalid-feedback" id="tingkat_error"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jurusan <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" 
                                   name="jurusan" 
                                   id="jurusan"
                                   placeholder="Contoh: IPA, IPS, Bahasa" 
                                   required>
                            <div class="invalid-feedback" id="jurusan_error"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Wali Kelas <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" 
                               name="wali_kelas" 
                               id="wali_kelas"
                               required>
                        <div class="invalid-feedback" id="wali_kelas_error"></div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Kapasitas <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" 
                               name="kapasitas" 
                               id="kapasitas"
                               value="40" 
                               min="1" max="50" required>
                        <small class="text-muted">Jumlah maksimal siswa dalam kelas (maksimal 50)</small>
                        <div class="invalid-feedback" id="kapasitas_error"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-primary" id="btnSimpan">
                        <i class="bi bi-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title" id="editModalLabel">
                    <i class="bi bi-pencil"></i> Edit Data Kelas
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="formEditKelas" method="POST">
                <div class="modal-body" id="editContent">
                    <!-- Content akan diisi via JavaScript -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-warning" id="btnUpdate">
                        <i class="bi bi-check-circle"></i> Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {
    // Show success popup for delete actions
    <?php if(session()->getFlashdata('show_popup_success')): ?>
        Swal.fire({
            icon: 'success',
            title: '<?= session()->getFlashdata("popup_title") ?>',
            text: '<?= session()->getFlashdata("popup_message") ?>',
            timer: 2000,
            showConfirmButton: false,
            timerProgressBar: true
        }).then(() => {
            // Hapus flashdata setelah ditampilkan
            <?php 
            session()->remove('show_popup_success');
            session()->remove('popup_message');
            session()->remove('popup_title');
            ?>
        });
    <?php endif; ?>
    
    // Get CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '<?= csrf_hash() ?>';
    const csrfName = '<?= csrf_token() ?>';
    
    // ========== TAMBAH KELAS (AJAX) ==========
    $('#formTambahKelas').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const formData = form.serialize();
        
        // Show loading
        const submitBtn = form.find('#btnSimpan');
        const originalText = submitBtn.html();
        submitBtn.html('<i class="bi bi-hourglass-split"></i> Processing...');
        submitBtn.prop('disabled', true);
        
        // Clear previous errors
        form.find('.is-invalid').removeClass('is-invalid');
        form.find('.invalid-feedback').text('');
        form.find('.is-valid').removeClass('is-valid');
        
        $.ajax({
            url: '<?= base_url("/kelas/create") ?>',
            type: 'POST',
            data: formData,
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            success: function(response) {
                if (response.success) {
                    // Show success message
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false,
                        timerProgressBar: true
                    }).then(() => {
                        // Close modal and reload page
                        $('#addModal').modal('hide');
                        location.reload();
                    });
                } else {
                    // Show validation errors
                    if (response.errors) {
                        // Tampilkan error di masing-masing field
                        $.each(response.errors, function(key, value) {
                            const field = form.find('[name="' + key + '"]');
                            const errorDiv = form.find('#' + key + '_error');
                            
                            if (field.length && errorDiv.length) {
                                field.addClass('is-invalid');
                                errorDiv.text(value);
                            }
                        });
                        
                        // Tampilkan pesan umum jika ada
                        if (response.message && response.message !== 'Validasi gagal') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Gagal',
                                text: response.message
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal!',
                            text: response.message || 'Terjadi kesalahan saat menambahkan data'
                        });
                    }
                    
                    // Aktifkan kembali tombol submit
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                
                Swal.fire({
                    icon: 'error',
                    title: 'Error Server!',
                    text: 'Terjadi kesalahan pada server. Silakan coba lagi.'
                });
                
                // Aktifkan kembali tombol submit
                submitBtn.html(originalText);
                submitBtn.prop('disabled', false);
            }
        });
    });

    // Real-time validation untuk nama kelas
    $('#nama_kelas').on('blur', function() {
        const namaKelas = $(this).val().trim();
        
        if (namaKelas.length > 0) {
            const csrfField = $('input[name="<?= csrf_token() ?>"]').val() || csrfToken;
            
            $.ajax({
                url: '<?= base_url("/kelas/checkNamaKelas") ?>',
                type: 'POST',
                data: {
                    '<?= csrf_token() ?>': csrfField,
                    'nama_kelas': namaKelas
                },
                dataType: 'json',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                success: function(response) {
                    const field = $('#nama_kelas');
                    const errorDiv = $('#nama_kelas_error');
                    
                    if (response.is_unique) {
                        field.removeClass('is-invalid');
                        field.addClass('is-valid');
                        errorDiv.text('');
                    } else {
                        field.removeClass('is-valid');
                        field.addClass('is-invalid');
                        errorDiv.text(response.message);
                    }
                },
                error: function() {
                    console.log('Error checking nama kelas');
                }
            });
        }
    });

    // ========== EDIT KELAS ==========
    // Edit Kelas - Fill form with data
    $(document).on('click', '.edit-kelas-btn', function() {
        const id = $(this).data('id');
        const nama = $(this).data('nama');
        const tingkat = $(this).data('tingkat');
        const jurusan = $(this).data('jurusan');
        const wali = $(this).data('wali');
        const kapasitas = $(this).data('kapasitas');
        
        // Fill form with data
        const html = `
            <input type="hidden" name="id" value="${id}">
            <input type="hidden" name="${csrfName}" value="${csrfToken}">
            
            <div class="mb-3">
                <label class="form-label">Nama Kelas <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="nama_kelas" id="edit_nama_kelas" value="${nama}" required>
                <div class="invalid-feedback" id="edit_nama_kelas_error"></div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Tingkat <span class="text-danger">*</span></label>
                    <select class="form-select" name="tingkat" id="edit_tingkat" required>
                        <option value="">Pilih Tingkat</option>
                        <option value="X" ${tingkat == 'X' ? 'selected' : ''}>Kelas X</option>
                        <option value="XI" ${tingkat == 'XI' ? 'selected' : ''}>Kelas XI</option>
                        <option value="XII" ${tingkat == 'XII' ? 'selected' : ''}>Kelas XII</option>
                    </select>
                    <div class="invalid-feedback" id="edit_tingkat_error"></div>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Jurusan <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="jurusan" id="edit_jurusan" value="${jurusan}" required>
                    <div class="invalid-feedback" id="edit_jurusan_error"></div>
                </div>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Wali Kelas <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="wali_kelas" id="edit_wali_kelas" value="${wali}" required>
                <div class="invalid-feedback" id="edit_wali_kelas_error"></div>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Kapasitas <span class="text-danger">*</span></label>
                <input type="number" class="form-control" name="kapasitas" id="edit_kapasitas" value="${kapasitas}" min="1" max="50" required>
                <small class="text-muted">Jumlah maksimal siswa dalam kelas (maksimal 50)</small>
                <div class="invalid-feedback" id="edit_kapasitas_error"></div>
            </div>
        `;
        
        $('#editContent').html(html);
    });

    // Handle Edit Form Submit with AJAX
    $('#formEditKelas').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const id = form.find('input[name="id"]').val();
        const url = '<?= base_url("/kelas/update/") ?>' + id;
        const formData = form.serialize();
        
        // Show loading
        const submitBtn = form.find('#btnUpdate');
        const originalText = submitBtn.html();
        submitBtn.html('<i class="bi bi-hourglass-split"></i> Processing...');
        submitBtn.prop('disabled', true);
        
        // Clear errors
        form.find('.is-invalid').removeClass('is-invalid');
        form.find('.invalid-feedback').text('');
        
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            success: function(response) {
                if (response.success) {
                    // Show success message
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false,
                        timerProgressBar: true
                    }).then(() => {
                        // Close modal and reload page
                        $('#editModal').modal('hide');
                        location.reload();
                    });
                } else {
                    // Show validation errors
                    if (response.errors) {
                        // Tampilkan error per field
                        $.each(response.errors, function(key, value) {
                            const field = form.find('[name="' + key + '"]');
                            const errorDiv = form.find('#edit_' + key + '_error');
                            
                            if (field.length && errorDiv.length) {
                                field.addClass('is-invalid');
                                errorDiv.text(value);
                            }
                        });
                        
                        // Tampilkan pesan umum jika ada
                        if (response.message && response.message !== 'Validasi gagal') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Gagal',
                                text: response.message
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal!',
                            text: response.message || 'Terjadi kesalahan saat update'
                        });
                    }
                    
                    // Aktifkan kembali tombol submit
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                
                Swal.fire({
                    icon: 'error',
                    title: 'Error Server!',
                    text: 'Terjadi kesalahan pada server.'
                });
                
                // Aktifkan kembali tombol submit
                submitBtn.html(originalText);
                submitBtn.prop('disabled', false);
            }
        });
    });

    // ========== DELETE KELAS ==========
    $(document).on('click', '.delete-kelas-btn', function(e) {
        e.preventDefault();
        
        const id = $(this).data('id');
        const name = $(this).data('name');
        
        Swal.fire({
            title: 'Hapus Data Kelas?',
            html: `Apakah Anda yakin ingin menghapus kelas <strong>${name}</strong>?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal',
            allowOutsideClick: false
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '<?= base_url("/kelas/delete/") ?>' + id;
            }
        });
    });

    // ========== MODAL HANDLING ==========
    // Reset form when modal is closed
    $('#addModal').on('hidden.bs.modal', function() {
        const form = $('#formTambahKelas');
        form[0].reset();
        form.find('.is-invalid').removeClass('is-invalid');
        form.find('.invalid-feedback').text('');
        form.find('.is-valid').removeClass('is-valid');
        $('#btnSimpan').prop('disabled', false).html('<i class="bi bi-save"></i> Simpan');
    });
    
    $('#editModal').on('hidden.bs.modal', function() {
        $('#editContent').empty();
        $('#btnUpdate').prop('disabled', false).html('<i class="bi bi-check-circle"></i> Update');
    });
});
</script>
<?= $this->endSection(); ?>