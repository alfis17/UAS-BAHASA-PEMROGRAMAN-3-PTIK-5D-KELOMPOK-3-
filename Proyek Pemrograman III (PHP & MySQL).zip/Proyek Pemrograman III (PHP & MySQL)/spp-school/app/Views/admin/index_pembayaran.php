<?= $this->extend('layout/main'); ?>

<?= $this->section('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h2 class="fw-bold"><i class="bi bi-credit-card"></i> <?= $page_title ?? 'Data Pembayaran SPP' ?></h2>
        <p class="text-muted">Input dan kelola pembayaran SPP siswa.</p>
    </div>
    <div class="col-auto">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal" id="btnTambahPembayaran">
            <i class="bi bi-plus-circle"></i> Input Pembayaran
        </button>
    </div>
</div>

<!-- Flash Messages -->
<?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i> <?= session()->getFlashdata('success') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i> <?= session()->getFlashdata('error') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- Payment Statistics -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card border-primary">
            <div class="card-body text-center">
                <i class="bi bi-calendar-day text-primary" style="font-size: 2rem;"></i>
                <h6 class="mt-2">Hari Ini</h6>
                <h3 class="text-primary">Rp <?= number_format($stats['today_total'] ?? 0, 0, ',', '.') ?></h3>
                <small class="text-muted">Total pembayaran</small>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card border-success">
            <div class="card-body text-center">
                <i class="bi bi-calendar-month text-success" style="font-size: 2rem;"></i>
                <h6 class="mt-2">Bulan Ini</h6>
                <h3 class="text-success">Rp <?= number_format($stats['month_total'] ?? 0, 0, ',', '.') ?></h3>
                <small class="text-muted">Total <?= date('F') ?> <?= date('Y') ?></small>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card border-info">
            <div class="card-body text-center">
                <i class="bi bi-receipt text-info" style="font-size: 2rem;"></i>
                <h6 class="mt-2">Transaksi</h6>
                <h3 class="text-info"><?= number_format($stats['month_count'] ?? 0, 0, ',', '.') ?></h3>
                <small class="text-muted">Transaksi bulan ini</small>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card border-warning">
            <div class="card-body text-center">
                <i class="bi bi-people text-warning" style="font-size: 2rem;"></i>
                <h6 class="mt-2">Status</h6>
                <h5 class="text-success mb-1"><?= $stats['lunas_count'] ?? 0 ?> Lunas</h5>
                <h5 class="text-danger mb-0"><?= $stats['belum_lunas_count'] ?? 0 ?> Belum</h5>
                <small class="text-muted">Status bulan ini</small>
            </div>
        </div>
    </div>
</div>

<!-- Search Bar -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="input-group">
            <input type="text" class="form-control" id="searchInput" placeholder="Cari siswa/NISN/bulan...">
            <button class="btn btn-outline-secondary" type="button" id="searchBtn">
                <i class="bi bi-search"></i>
            </button>
            <button class="btn btn-outline-primary" type="button" id="resetBtn">
                <i class="bi bi-arrow-clockwise"></i>
            </button>
        </div>
    </div>
    <div class="col-md-6">
        <div id="searchResults" class="alert alert-info d-none"></div>
    </div>
</div>

<!-- Filter Section -->
<div class="card mb-4">
    <div class="card-body">
        <h6 class="card-title mb-3">Filter Data</h6>
        <div class="row">
            <div class="col-md-3 mb-3">
                <select id="filterBulan" class="form-select">
                    <option value="">Semua Bulan</option>
                    <?php foreach($bulan_list as $bulan): ?>
                        <option value="<?= $bulan ?>"><?= $bulan ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 mb-3">
                <select id="filterTahun" class="form-select">
                    <option value="">Semua Tahun</option>
                    <?php foreach($tahun_list as $tahun): ?>
                        <option value="<?= $tahun ?>" <?= $tahun == date('Y') ? 'selected' : '' ?>>
                            <?= $tahun ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 mb-3">
                <select id="filterStatus" class="form-select">
                    <option value="">Semua Status</option>
                    <option value="Lunas">Lunas</option>
                    <option value="Belum Lunas">Belum Lunas</option>
                </select>
            </div>
            <div class="col-md-3 mb-3">
                <select id="filterMetode" class="form-select">
                    <option value="">Semua Metode</option>
                    <option value="Tunai">Tunai</option>
                    <option value="Transfer">Transfer</option>
                    <option value="QRIS">QRIS</option>
                </select>
            </div>
        </div>
    </div>
</div>

<!-- Payments Table -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Daftar Pembayaran</h5>
    </div>
    <div class="card-body">
        <?php if(empty($pembayaran)): ?>
            <div class="text-center py-5">
                <i class="bi bi-credit-card-2-front" style="font-size: 3rem; color: #6c757d;"></i>
                <h5 class="mt-3">Belum ada data pembayaran</h5>
                <p class="text-muted">Klik tombol "Input Pembayaran" untuk menambahkan data baru.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover" id="paymentsTable">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th>Tanggal</th>
                            <th>Siswa</th>
                            <th>Kelas</th>
                            <th>Bulan/Tahun</th>
                            <th>Jumlah Bayar</th>
                            <th>Metode</th>
                            <th>Status</th>
                            <th>Petugas</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="paymentsTableBody">
                        <?php $no = 1; ?>
                        <?php foreach($pembayaran as $p): ?>
                        <?php 
                            // Handle both array and object formats
                            $isArray = is_array($p);
                            $id = $isArray ? $p['id'] : $p->id;
                            $tanggal_bayar = $isArray ? $p['tanggal_bayar'] : $p->tanggal_bayar;
                            $nama_siswa = $isArray ? $p['nama_siswa'] : $p->nama_siswa;
                            $nisn = $isArray ? $p['nisn'] : $p->nisn;
                            $nama_kelas = $isArray ? ($p['nama_kelas'] ?? 'Belum ada kelas') : ($p->nama_kelas ?? 'Belum ada kelas');
                            $bulan = $isArray ? $p['bulan'] : $p->bulan;
                            $tahun = $isArray ? $p['tahun'] : $p->tahun;
                            $jumlah_bayar = $isArray ? $p['jumlah_bayar'] : $p->jumlah_bayar;
                            $spp_nominal = $isArray ? ($p['spp_nominal'] ?? 0) : ($p->spp_nominal ?? 0);
                            $metode_pembayaran = $isArray ? $p['metode_pembayaran'] : $p->metode_pembayaran;
                            $status_pembayaran = $isArray ? ($p['status_pembayaran'] ?? 'Belum Lunas') : ($p->status_pembayaran ?? 'Belum Lunas');
                            $petugas = $isArray ? ($p['petugas'] ?? 'System') : ($p->petugas ?? 'System');
                            $keterangan = $isArray ? ($p['keterangan'] ?? '-') : ($p->keterangan ?? '-');
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <small><?= date('d/m/Y', strtotime($tanggal_bayar)) ?></small>
                                <br>
                                <small class="text-muted"><?= date('H:i', strtotime($tanggal_bayar)) ?></small>
                            </td>
                            <td>
                                <strong><?= $nama_siswa ?></strong>
                                <br>
                                <small class="text-muted">NISN: <?= $nisn ?></small>
                            </td>
                            <td>
                                <span class="badge bg-info"><?= $nama_kelas ?></span>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?= $bulan ?> <?= $tahun ?></span>
                            </td>
                            <td class="fw-bold text-success">
                                Rp <?= number_format($jumlah_bayar, 0, ',', '.') ?>
                                <?php if($spp_nominal && $spp_nominal > 0): ?>
                                    <br>
                                    <small class="text-muted">
                                        Tarif: Rp <?= number_format($spp_nominal, 0, ',', '.') ?>
                                    </small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php 
                                $badge_class = 'bg-secondary';
                                if($metode_pembayaran == 'Tunai') $badge_class = 'bg-primary';
                                if($metode_pembayaran == 'Transfer') $badge_class = 'bg-success';
                                if($metode_pembayaran == 'QRIS') $badge_class = 'bg-warning';
                                ?>
                                <span class="badge <?= $badge_class ?>">
                                    <?= $metode_pembayaran ?>
                                </span>
                            </td>
                            <td>
                                <?php 
                                $status_badge = $status_pembayaran == 'Lunas' ? 'bg-success' : 'bg-danger';
                                ?>
                                <span class="badge <?= $status_badge ?>">
                                    <?= $status_pembayaran ?>
                                </span>
                            </td>
                            <td>
                                <small><?= $petugas ?></small>
                            </td>
                            <td>
                                <small><?= $keterangan ?></small>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button class="btn btn-sm btn-outline-info detail-pembayaran"
                                            data-id="<?= $id ?>"
                                            data-bs-toggle="modal"
                                            data-bs-target="#detailModal"
                                            title="Detail">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-warning edit-pembayaran"
                                            data-id="<?= $id ?>"
                                            data-nama="<?= $nama_siswa ?>"
                                            data-nisn="<?= $nisn ?>"
                                            data-bulan="<?= $bulan ?>"
                                            data-tahun="<?= $tahun ?>"
                                            data-jumlah="<?= $jumlah_bayar ?>"
                                            data-metode="<?= $metode_pembayaran ?>"
                                            data-status="<?= $status_pembayaran ?>"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editModal"
                                            title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger delete-pembayaran"
                                            data-id="<?= $id ?>"
                                            data-info="<?= $nama_siswa ?> - <?= $bulan ?> <?= $tahun ?>"
                                            data-csrf="<?= csrf_hash() ?>"
                                            title="Hapus">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Modal (AJAX) -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">
                    <i class="bi bi-plus-circle"></i> Input Pembayaran SPP
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formTambahPembayaran" method="POST">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Pilih Siswa <span class="text-danger">*</span></label>
                            <select class="form-select" id="selectSiswa" name="id_siswa" required>
                                <option value="">Pilih siswa...</option>
                                <?php foreach($siswa_list as $siswa): ?>
                                    <?php 
                                    $isSiswaArray = is_array($siswa);
                                    $siswaId = $isSiswaArray ? $siswa['id'] : $siswa->id;
                                    $siswaNisn = $isSiswaArray ? $siswa['nisn'] : $siswa->nisn;
                                    $siswaNama = $isSiswaArray ? $siswa['nama_siswa'] : $siswa->nama_siswa;
                                    $siswaKelas = $isSiswaArray ? ($siswa['nama_kelas'] ?? 'Belum ada kelas') : ($siswa->nama_kelas ?? 'Belum ada kelas');
                                    $siswaTingkat = $isSiswaArray ? ($siswa['tingkat'] ?? 'X') : ($siswa->tingkat ?? 'X');
                                    ?>
                                    <option value="<?= $siswaId ?>" 
                                            data-tingkat="<?= $siswaTingkat ?>">
                                        <?= $siswaNisn ?> - <?= $siswaNama ?> (<?= $siswaKelas ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback" id="id_siswa_error"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tarif SPP <span class="text-danger">*</span></label>
                            <select class="form-select" id="selectSPP" name="id_spp" required>
                                <option value="">Pilih tarif SPP...</option>
                                <?php foreach($spp_list as $spp): ?>
                                    <?php 
                                    $isSppArray = is_array($spp);
                                    $sppId = $isSppArray ? $spp['id'] : $spp->id;
                                    $sppTahunAjaran = $isSppArray ? $spp['tahun_ajaran'] : $spp->tahun_ajaran;
                                    $sppTingkat = $isSppArray ? $spp['tingkat'] : $spp->tingkat;
                                    $sppNominal = $isSppArray ? $spp['nominal'] : $spp->nominal;
                                    ?>
                                    <option value="<?= $sppId ?>"
                                            data-tingkat="<?= $sppTingkat ?>">
                                        <?= $sppTahunAjaran ?> - Kelas <?= $sppTingkat ?> 
                                        (Rp <?= number_format($sppNominal, 0, ',', '.') ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback" id="id_spp_error"></div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Bulan <span class="text-danger">*</span></label>
                            <select class="form-select" name="bulan" id="selectBulan" required>
                                <?php foreach($bulan_list as $bulan): ?>
                                    <option value="<?= $bulan ?>" <?= $bulan == date('F') ? 'selected' : '' ?>>
                                        <?= $bulan ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback" id="bulan_error"></div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Tahun <span class="text-danger">*</span></label>
                            <select class="form-select" name="tahun" id="selectTahun" required>
                                <?php foreach($tahun_list as $tahun): ?>
                                    <option value="<?= $tahun ?>" <?= $tahun == date('Y') ? 'selected' : '' ?>>
                                        <?= $tahun ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback" id="tahun_error"></div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Status <span class="text-danger">*</span></label>
                            <select class="form-select" name="status_pembayaran" id="selectStatus" required>
                                <option value="Belum Lunas">Belum Lunas</option>
                                <option value="Lunas">Lunas</option>
                            </select>
                            <div class="invalid-feedback" id="status_pembayaran_error"></div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Jumlah Bayar <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number" 
                                       class="form-control" 
                                       name="jumlah_bayar" 
                                       id="jumlahBayar"
                                       placeholder="500000"
                                       min="100000"
                                       step="50000"
                                       required>
                            </div>
                            <small class="text-muted">Isi tanpa titik/koma (contoh: 500000)</small>
                            <div class="invalid-feedback" id="jumlah_bayar_error"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Metode Pembayaran <span class="text-danger">*</span></label>
                            <select class="form-select" name="metode_pembayaran" id="selectMetode" required>
                                <option value="Tunai">Tunai</option>
                                <option value="Transfer">Transfer</option>
                                <option value="QRIS">QRIS</option>
                            </select>
                            <div class="invalid-feedback" id="metode_pembayaran_error"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Keterangan (Opsional)</label>
                        <textarea class="form-control" name="keterangan" id="keterangan" rows="2" 
                                  placeholder="Catatan tambahan pembayaran..."></textarea>
                        <div class="invalid-feedback" id="keterangan_error"></div>
                    </div>
                    
                    <!-- Student Info & Payment History -->
                    <div class="card mt-3">
                        <div class="card-header bg-light">
                            <h6 class="mb-0">
                                <i class="bi bi-info-circle"></i> Informasi Siswa & Riwayat Pembayaran
                            </h6>
                        </div>
                        <div class="card-body">
                            <div id="studentInfo" class="d-none">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <strong>Nama:</strong> <span id="infoNama"></span><br>
                                        <strong>Kelas:</strong> <span id="infoKelas"></span>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>NISN:</strong> <span id="infoNISN"></span><br>
                                        <strong>Tingkat:</strong> <span id="infoTingkat"></span>
                                    </div>
                                </div>
                                
                                <div class="alert alert-info">
                                    <i class="bi bi-cash-coin"></i> 
                                    <strong>Tarif SPP:</strong> <span id="infoSPP">Rp 0</span>/bulan
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <h6>Bulan Sudah Bayar</h6>
                                        <div id="paidMonths" class="d-flex flex-wrap gap-1 mt-2"></div>
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Bulan Belum Bayar</h6>
                                        <div id="unpaidMonths" class="d-flex flex-wrap gap-1 mt-2"></div>
                                    </div>
                                </div>
                                
                                <hr>
                                <h6>Riwayat Pembayaran Tahun <?= date('Y') ?></h6>
                                <div id="paymentHistory" class="table-responsive">
                                    <!-- History will be loaded here -->
                                </div>
                            </div>
                            <div id="noStudentInfo" class="text-center py-3">
                                <i class="bi bi-person text-muted" style="font-size: 2rem;"></i>
                                <p class="text-muted mt-2">Pilih siswa untuk melihat informasi dan riwayat pembayaran</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-primary" id="btnSimpanPembayaran">
                        <i class="bi bi-save"></i> Simpan Pembayaran
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Detail Modal -->
<div class="modal fade" id="detailModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title">
                    <i class="bi bi-eye"></i> Detail Pembayaran
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="detailModalBody">
                <!-- Detail content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle"></i> Tutup
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title">
                    <i class="bi bi-pencil"></i> Edit Pembayaran
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formEditPembayaran" method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="id" id="editId">
                <div class="modal-body" id="editModalBody">
                    <!-- Edit form will be loaded here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-warning" id="btnUpdatePembayaran">
                        <i class="bi bi-save"></i> Update Pembayaran
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {
    // Show success popup for delete actions
    <?php if(session()->getFlashdata('show_popup_success')): ?>
        Swal.fire({
            icon: 'success',
            title: '<?= session()->getFlashdata("popup_title") ?>',
            text: '<?= session()->getFlashdata("popup_message") ?>',
            timer: 2000,
            showConfirmButton: false,
            timerProgressBar: true
        });
        // Clear the flashdata after showing
        <?php session()->remove('show_popup_success'); ?>
        <?php session()->remove('popup_message'); ?>
        <?php session()->remove('popup_title'); ?>
    <?php endif; ?>
    
    // Get current CSRF token
    const csrfToken = $('meta[name="csrf-token"]').attr('content') || '<?= csrf_hash() ?>';
    const csrfName = '<?= csrf_token() ?>';
    
    // ========== TAMBAH PEMBAYARAN (AJAX) ==========
    $('#formTambahPembayaran').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const formData = form.serialize();
        
        // Show loading
        const submitBtn = form.find('#btnSimpanPembayaran');
        const originalText = submitBtn.html();
        submitBtn.html('<i class="bi bi-hourglass-split"></i> Processing...');
        submitBtn.prop('disabled', true);
        
        // Clear previous errors
        form.find('.is-invalid').removeClass('is-invalid');
        form.find('.invalid-feedback').text('');
        
        // Validation: Check duplicate payment
        const idSiswa = $('#selectSiswa').val();
        const bulan = $('#selectBulan').val();
        const tahun = $('#selectTahun').val();
        
        if (idSiswa && bulan && tahun) {
        // Check via AJAX for duplicate
        $.ajax({
            url: '/pembayaran/check-duplicate',
            type: 'POST',
            data: {
                id_siswa: idSiswa,
                bulan: bulan,
                tahun: tahun,
                [csrfName]: csrfToken
            },
            dataType: 'json',
            async: false,
            success: function(response) {
                if (response.exists) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Pembayaran Duplikat',
                        html: `Siswa sudah melakukan pembayaran untuk <strong>${bulan} ${tahun}</strong><br>
                                  Silakan pilih bulan/tahun lain.`
                    });
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                    return false;
                }
            }
        });
        }
        
        $.ajax({
            url: '<?= base_url("/pembayaran/create") ?>',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Show success message
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false,
                        timerProgressBar: true
                    }).then(() => {
                        // Close modal and reload page
                        $('#addModal').modal('hide');
                        location.reload();
                    });
                } else {
                    // Show validation errors
                    if (response.errors) {
                        // Tampilkan error di masing-masing field
                        $.each(response.errors, function(key, value) {
                            const field = $('[name="' + key + '"]');
                            const errorDiv = $('#' + key + '_error');
                            
                            if (field.length && errorDiv.length) {
                                field.addClass('is-invalid');
                                errorDiv.text(value);
                            }
                        });
                        
                        // Show general alert for specific errors
                        if (response.errors.id_siswa) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Gagal',
                                text: 'Siswa wajib dipilih'
                            });
                        } else if (response.errors.id_spp) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Gagal',
                                text: 'Tarif SPP wajib dipilih'
                            });
                        } else if (response.errors.jumlah_bayar) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Jumlah Bayar Tidak Valid',
                                text: 'Jumlah bayar tidak valid atau kurang dari tarif SPP'
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal!',
                            text: response.message || 'Terjadi kesalahan saat menambahkan data'
                        });
                    }
                    
                    // Enable submit button
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Terjadi kesalahan pada server.'
                });
                
                // Enable submit button
                submitBtn.html(originalText);
                submitBtn.prop('disabled', false);
            }
        });
    });

    // Load student info when selected
    $('#selectSiswa').change(function() {
        const studentId = $(this).val();
        
        if (!studentId) {
            $('#studentInfo').addClass('d-none');
            $('#noStudentInfo').removeClass('d-none');
            return;
        }
        
        // Get selected student's tingkat
        const selectedOption = $(this).find('option:selected');
        const tingkat = selectedOption.data('tingkat');
        
        // Filter SPP options by tingkat
        filterSPPByTingkat(tingkat);
        
        // Load student info via AJAX
        $.ajax({
            url: '<?= base_url("/pembayaran/get-siswa-info/") ?>' + studentId,
            type: 'GET',
            dataType: 'json',
            beforeSend: function() {
                $('#studentInfo').addClass('d-none');
                $('#noStudentInfo').html(`
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="text-muted mt-2">Memuat data...</p>
                `);
            },
            success: function(response) {
                if (response.success) {
                    updateStudentInfo(response);
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message || 'Gagal memuat data siswa'
                    });
                    resetStudentInfo();
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Gagal memuat data siswa'
                });
                resetStudentInfo();
            }
        });
    });
    
    function filterSPPByTingkat(tingkat) {
        $('#selectSPP option').each(function() {
            const optionTingkat = $(this).data('tingkat');
            if (optionTingkat === tingkat) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
        
        // Select first visible option
        const firstVisible = $('#selectSPP option:visible').first();
        if (firstVisible.length) {
            $('#selectSPP').val(firstVisible.val());
            
            // Update jumlah bayar based on selected SPP
            updateJumlahBayar(firstVisible.text());
        }
    }
    
    function updateJumlahBayar(sppText) {
        // Extract nominal from SPP text (e.g., "2023/2024 - Kelas X (Rp 500.000)")
        const match = sppText.match(/Rp\s*([\d.,]+)/);
        if (match) {
            const nominal = match[1].replace(/\./g, '');
            $('#jumlahBayar').val(nominal);
        }
    }
    
    $('#selectSPP').change(function() {
        const selectedText = $(this).find('option:selected').text();
        updateJumlahBayar(selectedText);
    });
    
    // Update status when jumlah bayar changes
    $('#jumlahBayar').on('input', function() {
        const jumlahBayar = $(this).val();
        const selectedSppText = $('#selectSPP option:selected').text();
        
        if (selectedSppText) {
            const match = selectedSppText.match(/Rp\s*([\d.,]+)/);
            if (match) {
                const sppNominal = parseInt(match[1].replace(/\./g, ''));
                
                // Jika jumlah bayar >= nominal SPP, otomatis set ke Lunas
                if (parseInt(jumlahBayar) >= sppNominal) {
                    $('#selectStatus').val('Lunas');
                } else {
                    $('#selectStatus').val('Belum Lunas');
                }
            }
        }
    });
    
    function updateStudentInfo(response) {
        const siswa = response.siswa;
        const spp = response.spp;
        const history = response.payment_history || [];
        const paidMonths = response.paid_months || [];
        const unpaidMonths = response.unpaid_months || [];
        
        // Fill student info
        $('#infoNama').text(siswa.nama_siswa);
        $('#infoNISN').text(siswa.nisn);
        $('#infoKelas').text(siswa.nama_kelas);
        $('#infoTingkat').text(siswa.tingkat);
        $('#infoSPP').text(spp ? spp.nominal_formatted : 'Rp 0');
        
        // Update paid/unpaid months
        updateMonthsDisplay('paidMonths', paidMonths, 'success');
        updateMonthsDisplay('unpaidMonths', unpaidMonths, 'danger');
        
        // Update payment history
        let historyHtml = '';
        if (history.length > 0) {
            historyHtml = `
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Bulan</th>
                            <th>Tahun</th>
                            <th>Jumlah</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th>Metode</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            history.forEach(function(payment) {
                const statusBadge = payment.status_pembayaran === 'Lunas' ? 
                    'bg-success' : 'bg-danger';
                    
                historyHtml += `
                    <tr>
                        <td>${payment.bulan}</td>
                        <td>${payment.tahun}</td>
                        <td class="text-success">${payment.jumlah_bayar_formatted}</td>
                        <td><span class="badge ${statusBadge}">${payment.status_pembayaran}</span></td>
                        <td>${payment.tanggal_bayar_formatted}</td>
                        <td><span class="badge bg-secondary">${payment.metode_pembayaran}</span></td>
                    </tr>
                `;
            });
            
            historyHtml += `
                    </tbody>
                </table>
                <p class="text-success mb-0">
                    <i class="bi bi-check-circle"></i> Total sudah dibayar: ${response.total_paid_formatted}
                </p>
            `;
        } else {
            historyHtml = `
                <div class="alert alert-warning mb-0">
                    <i class="bi bi-exclamation-triangle"></i> Belum ada riwayat pembayaran tahun ini
                </div>
            `;
        }
        
        $('#paymentHistory').html(historyHtml);
        
        // Show student info
        $('#studentInfo').removeClass('d-none');
        $('#noStudentInfo').addClass('d-none');
    }
    
    function updateMonthsDisplay(elementId, months, badgeType) {
        const container = $('#' + elementId);
        container.empty();
        
        if (months.length > 0) {
            months.forEach(function(month) {
                container.append(`
                    <span class="badge bg-${badgeType}">${month}</span>
                `);
            });
        } else {
            container.append(`
                <span class="text-muted">Tidak ada</span>
            `);
        }
    }
    
    function resetStudentInfo() {
        $('#studentInfo').addClass('d-none');
        $('#noStudentInfo').removeClass('d-none').html(`
            <i class="bi bi-person text-muted" style="font-size: 2rem;"></i>
            <p class="text-muted mt-2">Pilih siswa untuk melihat informasi dan riwayat pembayaran</p>
        `);
    }

    // ========== SEARCH PEMBAYARAN ==========
    $('#searchBtn').click(function() {
        const keyword = $('#searchInput').val().trim();
        
        if (keyword.length < 2) {
            Swal.fire({
                icon: 'warning',
                title: 'Peringatan',
                text: 'Masukkan minimal 2 karakter untuk pencarian',
                timer: 2000,
                showConfirmButton: false,
                timerProgressBar: true
            });
            return;
        }
        
        // Get filter values
        const bulan = $('#filterBulan').val();
        const tahun = $('#filterTahun').val();
        const status = $('#filterStatus').val();
        const metode = $('#filterMetode').val();
        
        // Show loading
        $('#paymentsTableBody').html(`
            <tr>
                <td colspan="10" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Mencari data...</p>
                </td>
            </tr>
        `);
        
        $.ajax({
            url: '<?= base_url("/pembayaran/search") ?>',
            type: 'GET',
            data: { 
                keyword: keyword,
                bulan: bulan,
                tahun: tahun,
                status: status,
                metode: metode
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    if (response.data.length > 0) {
                        let html = '';
                        let no = 1;
                        response.data.forEach(function(payment) {
                            let metodeBadgeClass = 'bg-secondary';
                            if (payment.metode_pembayaran == 'Tunai') metodeBadgeClass = 'bg-primary';
                            if (payment.metode_pembayaran == 'Transfer') metodeBadgeClass = 'bg-success';
                            if (payment.metode_pembayaran == 'QRIS') metodeBadgeClass = 'bg-warning';
                            
                            let statusBadgeClass = payment.status_pembayaran === 'Lunas' ? 'bg-success' : 'bg-danger';
                            
                            html += `
                                <tr>
                                    <td>${no++}</td>
                                    <td>
                                        <small>${payment.tanggal_bayar_formatted}</small>
                                        <br>
                                        <small class="text-muted">${payment.jam_bayar}</small>
                                    </td>
                                    <td>
                                        <strong>${payment.nama_siswa}</strong>
                                        <br>
                                        <small class="text-muted">NISN: ${payment.nisn}</small>
                                    </td>
                                    <td>
                                        <span class="badge bg-info">${payment.nama_kelas}</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary">${payment.bulan} ${payment.tahun}</span>
                                    </td>
                                    <td class="fw-bold text-success">
                                        ${payment.jumlah_bayar_formatted}
                                        ${payment.spp_nominal_formatted ? `<br><small class="text-muted">Tarif: ${payment.spp_nominal_formatted}</small>` : ''}
                                    </td>
                                    <td>
                                        <span class="badge ${metodeBadgeClass}">
                                            ${payment.metode_pembayaran}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge ${statusBadgeClass}">
                                            ${payment.status_pembayaran}
                                        </span>
                                    </td>
                                    <td>
                                        <small>${payment.petugas}</small>
                                    </td>
                                    <td>
                                        <small>${payment.keterangan || '-'}</small>
                                    </td>
                                </tr>
                            `;
                        });
                        $('#paymentsTableBody').html(html);
                        
                        Swal.fire({
                            icon: 'success',
                            title: 'Ditemukan!',
                            text: `Ditemukan ${response.data.length} hasil untuk "${keyword}"`,
                            timer: 2000,
                            showConfirmButton: false,
                            timerProgressBar: true
                        });
                    } else {
                        $('#paymentsTableBody').html(`
                            <tr>
                                <td colspan="10" class="text-center py-4">
                                    <i class="bi bi-search fs-1 text-muted"></i>
                                    <h5 class="mt-2">Tidak ditemukan</h5>
                                    <p class="text-muted">Tidak ada data pembayaran yang sesuai dengan kata kunci "${keyword}"</p>
                                    <button class="btn btn-sm btn-outline-primary" onclick="location.reload()">
                                        <i class="bi bi-arrow-clockwise"></i> Tampilkan Semua
                                    </button>
                                </td>
                            </tr>
                        `);
                    }
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: response.message || 'Terjadi kesalahan saat pencarian'
                    });
                    location.reload();
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Terjadi kesalahan pada server saat pencarian'
                });
                location.reload();
            }
        });
    });

    // ========== FILTER PEMBAYARAN ==========
    $('#filterBulan, #filterTahun, #filterStatus, #filterMetode').on('change', function() {
        const bulan = $('#filterBulan').val();
        const tahun = $('#filterTahun').val();
        const status = $('#filterStatus').val();
        const metode = $('#filterMetode').val();
        const keyword = $('#searchInput').val().trim();
        
        // If search input has value, use search function
        if (keyword.length >= 2) {
            $('#searchBtn').click();
            return;
        }
        
        // Filter locally if no search keyword
        filterTableLocally(bulan, tahun, status, metode);
    });
    
    function filterTableLocally(bulan, tahun, status, metode) {
        let visibleRows = 0;
        
        $('#paymentsTableBody tr').each(function() {
            const row = $(this);
            const bulanTahun = row.find('td:eq(4)').text().toLowerCase();
            const statusText = row.find('td:eq(7)').text().trim();
            const metodeText = row.find('td:eq(6)').text().trim();
            
            const matchesBulan = !bulan || bulanTahun.includes(bulan.toLowerCase());
            const matchesTahun = !tahun || bulanTahun.includes(tahun);
            const matchesStatus = !status || statusText === status;
            const matchesMetode = !metode || metodeText === metode;
            
            if (matchesBulan && matchesTahun && matchesStatus && matchesMetode) {
                row.show();
                visibleRows++;
            } else {
                row.hide();
            }
        });
        
        if (visibleRows === 0) {
            $('#paymentsTableBody').append(`
                <tr id="noResultsRow">
                    <td colspan="10" class="text-center py-4">
                        <i class="bi bi-filter fs-1 text-muted"></i>
                        <h5 class="mt-2">Tidak ada data</h5>
                        <p class="text-muted">Tidak ada data yang sesuai dengan filter yang dipilih</p>
                    </td>
                </tr>
            `);
        } else {
            $('#noResultsRow').remove();
        }
    }

    // Reset search and filters
    $('#resetBtn').click(function() {
        $('#searchInput').val('');
        $('#filterBulan').val('');
        $('#filterTahun').val('');
        $('#filterStatus').val('');
        $('#filterMetode').val('');
        location.reload();
    });

    // Clear search when input is empty
    $('#searchInput').on('input', function() {
        if ($(this).val().trim() === '') {
            location.reload();
        }
    });

    // ========== ACTION BUTTONS ==========
    // Detail Pembayaran
    $(document).on('click', '.detail-pembayaran', function() {
        const id = $(this).data('id');

        $.ajax({
            url: '<?= base_url("/pembayaran/view/") ?>' + id,
            type: 'GET',
            dataType: 'json',
            beforeSend: function() {
                $('#detailModalBody').html(`
                    <div class="text-center py-4">
                        <div class="spinner-border text-info" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Memuat detail pembayaran...</p>
                    </div>
                `);
            },
            success: function(response) {
                if (response.success) {
                    const payment = response.data;
                    let html = `
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="text-info"><i class="bi bi-person"></i> Informasi Siswa</h6>
                                <table class="table table-sm">
                                    <tr>
                                        <td width="30%"><strong>Nama:</strong></td>
                                        <td>${payment.nama_siswa}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>NISN:</strong></td>
                                        <td>${payment.nisn}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Kelas:</strong></td>
                                        <td><span class="badge bg-info">${payment.nama_kelas}</span></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h6 class="text-primary"><i class="bi bi-receipt"></i> Detail Pembayaran</h6>
                                <table class="table table-sm">
                                    <tr>
                                        <td width="30%"><strong>Bulan/Tahun:</strong></td>
                                        <td><span class="badge bg-secondary">${payment.bulan} ${payment.tahun}</span></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Jumlah Bayar:</strong></td>
                                        <td class="text-success fw-bold">${payment.jumlah_bayar_formatted}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Metode:</strong></td>
                                        <td><span class="badge bg-primary">${payment.metode_pembayaran}</span></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Status:</strong></td>
                                        <td><span class="badge ${payment.status_pembayaran === 'Lunas' ? 'bg-success' : 'bg-danger'}">${payment.status_pembayaran}</span></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <h6 class="text-secondary"><i class="bi bi-info-circle"></i> Informasi Tambahan</h6>
                                <table class="table table-sm">
                                    <tr>
                                        <td width="20%"><strong>Tanggal Bayar:</strong></td>
                                        <td>${payment.tanggal_bayar_formatted}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Petugas:</strong></td>
                                        <td>${payment.petugas || 'System'}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Keterangan:</strong></td>
                                        <td>${payment.keterangan || '-'}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    `;
                    $('#detailModalBody').html(html);
                } else {
                    $('#detailModalBody').html(`
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-triangle"></i> ${response.message || 'Gagal memuat detail pembayaran'}
                        </div>
                    `);
                }
            },
            error: function() {
                $('#detailModalBody').html(`
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> Gagal memuat detail pembayaran
                    </div>
                `);
            }
        });
    });

    // Edit Pembayaran
    $(document).on('click', '.edit-pembayaran', function() {
        const id = $(this).data('id');
        const nama = $(this).data('nama');
        const nisn = $(this).data('nisn');
        const bulan = $(this).data('bulan');
        const tahun = $(this).data('tahun');
        const jumlah = $(this).data('jumlah');
        const metode = $(this).data('metode');
        const status = $(this).data('status');

        // Load edit form via AJAX
        $.ajax({
            url: '<?= base_url("/pembayaran/edit-form/") ?>' + id,
            type: 'GET',
            dataType: 'json',
            beforeSend: function() {
                $('#editModalBody').html(`
                    <div class="text-center py-4">
                        <div class="spinner-border text-warning" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Memuat form edit...</p>
                    </div>
                `);
            },
            success: function(response) {
                if (response.success) {
                    $('#editModalBody').html(response.html);
                    $('#editId').val(id);
                } else {
                    $('#editModalBody').html(`
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-triangle"></i> ${response.message || 'Gagal memuat form edit'}
                        </div>
                    `);
                }
            },
            error: function() {
                $('#editModalBody').html(`
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> Gagal memuat form edit
                    </div>
                `);
            }
        });
    });

    // Handle Edit Form Submit
    $('#formEditPembayaran').on('submit', function(e) {
        e.preventDefault();

        const form = $(this);
        const formData = form.serialize();

        // Show loading
        const submitBtn = form.find('#btnUpdatePembayaran');
        const originalText = submitBtn.html();
        submitBtn.html('<i class="bi bi-hourglass-split"></i> Updating...');
        submitBtn.prop('disabled', true);

        // Clear previous errors
        form.find('.is-invalid').removeClass('is-invalid');
        form.find('.invalid-feedback').text('');

        $.ajax({
            url: '<?= base_url("/pembayaran/update") ?>',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Show success message
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false,
                        timerProgressBar: true
                    }).then(() => {
                        // Close modal and reload page
                        $('#editModal').modal('hide');
                        location.reload();
                    });
                } else {
                    // Show validation errors
                    if (response.errors) {
                        $.each(response.errors, function(key, value) {
                            const field = $('[name="' + key + '"]');
                            const errorDiv = $('#' + key + '_error');

                            if (field.length && errorDiv.length) {
                                field.addClass('is-invalid');
                                errorDiv.text(value);
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal!',
                            text: response.message || 'Terjadi kesalahan saat update data'
                        });
                    }

                    // Enable submit button
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);

                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Terjadi kesalahan pada server.'
                });

                // Enable submit button
                submitBtn.html(originalText);
                submitBtn.prop('disabled', false);
            }
        });
    });

    // Delete Pembayaran
    $(document).on('click', '.delete-pembayaran', function() {
        const id = $(this).data('id');
        const info = $(this).data('info');

        Swal.fire({
            title: 'Konfirmasi Hapus',
            html: `Apakah Anda yakin ingin menghapus pembayaran <strong>${info}</strong>?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '<?= base_url("/pembayaran/delete/") ?>' + id,
                    type: 'POST',
                    data: {
                        [csrfName]: csrfToken
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: response.message,
                                timer: 2000,
                                showConfirmButton: false,
                                timerProgressBar: true
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal!',
                                text: response.message || 'Terjadi kesalahan saat menghapus data'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Terjadi kesalahan pada server.'
                        });
                    }
                });
            }
        });
    });

    // ========== MODAL HANDLING ==========
    // Reset form when modal is closed
    $('#addModal').on('hidden.bs.modal', function() {
        $('#formTambahPembayaran')[0].reset();
        $('#formTambahPembayaran .is-invalid').removeClass('is-invalid');
        $('#formTambahPembayaran .invalid-feedback').text('');
        $('#btnSimpanPembayaran').prop('disabled', false).html('<i class="bi bi-save"></i> Simpan Pembayaran');
        resetStudentInfo();
        $('#selectSPP option').show();
        // Reset to default values
        $('#selectStatus').val('Belum Lunas');
        $('#selectMetode').val('Tunai');
        $('#selectBulan').val('<?= date("F") ?>');
        $('#selectTahun').val('<?= date("Y") ?>');
    });
});
</script>
<?= $this->endSection(); ?>