<?= $this->extend('layout/main'); ?>

<?= $this->section('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h2 class="fw-bold"><i class="bi bi-people"></i> Data Siswa</h2>
        <p class="text-muted">Kelola data siswa dan informasi pribadi.</p>
    </div>
    <div class="col-auto">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal" id="btnTambahSiswa">
            <i class="bi bi-plus-circle"></i> Tambah Siswa
        </button>
    </div>
</div>

<!-- Flash Messages -->
<?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="bi bi-exclamation-triangle"></i> <?= session()->getFlashdata('error') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Warning jika belum ada kelas -->
<?php if(empty($kelas)): ?>
    <div class="alert alert-warning alert-dismissible fade show">
        <i class="bi bi-exclamation-triangle"></i> 
        <strong>Perhatian:</strong> Belum ada data kelas. Silakan tambahkan data kelas terlebih dahulu sebelum menambah siswa.
        <a href="<?= base_url('/kelas') ?>" class="alert-link">Kelola Kelas</a>
    </div>
    
    <!-- Nonaktifkan tombol tambah siswa -->
    <script>
        $(document).ready(function() {
            $('#btnTambahSiswa').prop('disabled', true)
                .html('<i class="bi bi-plus-circle"></i> Tambah Siswa (Nonaktif - Belum ada kelas)')
                .removeClass('btn-primary').addClass('btn-secondary');
        });
    </script>
<?php endif; ?>

<!-- Validation Errors -->
<?php if(session()->getFlashdata('validation_errors') && !session()->getFlashdata('old_input')): ?>
    <div class="alert alert-warning alert-dismissible fade show">
        <h6><i class="bi bi-exclamation-octagon"></i> Error Validasi:</h6>
        <ul class="mb-0">
            <?php foreach(session()->getFlashdata('validation_errors') as $error): ?>
                <li><?= $error ?></li>
            <?php endforeach; ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Search Bar -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="input-group">
            <input type="text" class="form-control" id="searchInput" placeholder="Cari siswa...">
            <button class="btn btn-outline-secondary" type="button" id="searchBtn">
                <i class="bi bi-search"></i>
            </button>
        </div>
    </div>
    <div class="col-md-6">
        <div id="searchResults" class="alert alert-info d-none"></div>
    </div>
</div>

<!-- Students Table -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>NISN</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Jenis Kelamin</th>
                        <th>No. HP</th>
                        <th>Tahun Masuk</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody id="studentsTable">
                    <?php if(!empty($siswa)): ?>
                        <?php foreach($siswa as $s): ?>
                        <tr>
                            <td><?= is_array($s) ? $s['nisn'] : $s->nisn ?></td>
                            <td><?= is_array($s) ? $s['nama_siswa'] : $s->nama_siswa ?></td>
                            <td>
                                <?php 
                                $nama_kelas = is_array($s) ? $s['nama_kelas'] : $s->nama_kelas;
                                if($nama_kelas): ?>
                                    <span class="badge bg-primary"><?= $nama_kelas ?></span>
                                <?php else: ?>
                                    <span class="badge bg-warning">Belum ada kelas</span>
                                <?php endif; ?>
                            </td>
                            <td><?= (is_array($s) ? $s['jenis_kelamin'] : $s->jenis_kelamin) == 'L' ? 'Laki-laki' : 'Perempuan' ?></td>
                            <td><?= is_array($s) ? $s['no_hp'] : $s->no_hp ?></td>
                            <td><?= is_array($s) ? $s['tahun_masuk'] : $s->tahun_masuk ?></td>
                            <td>
                                <button class="btn btn-sm btn-info view-siswa-btn" 
                                        data-id="<?= is_array($s) ? $s['id'] : $s->id ?>"
                                        data-bs-toggle="modal" 
                                        data-bs-target="#viewModal">
                                    <i class="bi bi-eye"></i>
                                </button>
                                <button class="btn btn-sm btn-warning edit-siswa-btn" 
                                        data-id="<?= is_array($s) ? $s['id'] : $s->id ?>" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#editModal">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <button class="btn btn-sm btn-danger delete-siswa-btn" 
                                        data-id="<?= is_array($s) ? $s['id'] : $s->id ?>" 
                                        data-name="<?= is_array($s) ? $s['nama_siswa'] : $s->nama_siswa ?>">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <i class="bi bi-people fs-1 text-muted"></i>
                                <h5 class="mt-2">Tidak ada data siswa</h5>
                                <p class="text-muted">Belum ada data siswa yang ditambahkan</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal (AJAX) -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">
                    <i class="bi bi-plus-circle"></i> Tambah Data Siswa
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formTambahSiswa" method="POST">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">NISN <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" 
                               name="nisn" 
                               id="nisn"
                               placeholder="Nomor Induk Siswa Nasional" 
                               required>
                        <div class="invalid-feedback" id="nisn_error"></div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" 
                                   name="nama_siswa" 
                                   id="nama_siswa"
                                   placeholder="Nama lengkap siswa" 
                                   required>
                            <div class="invalid-feedback" id="nama_siswa_error"></div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                            <select class="form-select" name="jenis_kelamin" id="jenis_kelamin" required>
                                <option value="">Pilih Jenis Kelamin</option>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                            <div class="invalid-feedback" id="jenis_kelamin_error"></div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tempat Lahir <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" 
                                   name="tempat_lahir" 
                                   id="tempat_lahir"
                                   placeholder="Kota/kabupaten tempat lahir" 
                                   required>
                            <div class="invalid-feedback" id="tempat_lahir_error"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Lahir <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" 
                                   name="tanggal_lahir" 
                                   id="tanggal_lahir"
                                   max="<?= date('Y-m-d') ?>" 
                                   required>
                            <div class="invalid-feedback" id="tanggal_lahir_error"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Alamat <span class="text-danger">*</span></label>
                        <textarea class="form-control" 
                                  name="alamat" 
                                  id="alamat"
                                  rows="2" 
                                  placeholder="Alamat lengkap siswa" 
                                  required></textarea>
                        <div class="invalid-feedback" id="alamat_error"></div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No. HP <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" 
                                   name="no_hp" 
                                   id="no_hp"
                                   placeholder="Nomor telepon/HP" 
                                   required>
                            <div class="invalid-feedback" id="no_hp_error"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Kelas <span class="text-danger">*</span></label>
                            <select class="form-select" name="id_kelas" id="id_kelas" required>
                                <option value="">Pilih Kelas</option>
                                <?php foreach($kelas as $k): ?>
                                    <?php 
                                    $kelas_id = is_array($k) ? $k['id'] : $k->id;
                                    $kelas_nama = is_array($k) ? $k['nama_kelas'] : $k->nama_kelas;
                                    ?>
                                    <option value="<?= $kelas_id ?>"><?= $kelas_nama ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback" id="id_kelas_error"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Tahun Masuk <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" 
                               name="tahun_masuk" 
                               id="tahun_masuk"
                               min="2000" 
                               max="<?= date('Y') + 1 ?>" 
                               value="<?= date('Y') ?>"
                               required>
                        <div class="invalid-feedback" id="tahun_masuk_error"></div>
                    </div>
                    
                    <!-- Password Field -->
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" 
                                   name="password" 
                                   id="password"
                                   placeholder="Masukkan password" 
                                   minlength="6"
                                   required>
                            <div class="invalid-feedback" id="password_error"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Konfirmasi Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" 
                                   name="password_confirm" 
                                   id="password_confirm"
                                   placeholder="Masukkan ulang password" 
                                   minlength="6"
                                   required>
                            <div class="invalid-feedback" id="password_confirm_error"></div>
                        </div>
                    </div>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> Password minimal 6 karakter.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-primary" id="btnSimpanSiswa">
                        <i class="bi bi-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title">
                    <i class="bi bi-eye"></i> Detail Siswa
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="viewContent">
                <!-- Content will be loaded via AJAX -->
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title">
                    <i class="bi bi-pencil"></i> Edit Data Siswa
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formEditSiswa" method="POST">
                <div class="modal-body" id="editContent">
                    <!-- Content will be loaded via AJAX -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-warning" id="btnUpdateSiswa">
                        <i class="bi bi-check-circle"></i> Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {
    // Show success popup for delete actions
    <?php if(session()->getFlashdata('show_popup_success')): ?>
        Swal.fire({
            icon: 'success',
            title: '<?= session()->getFlashdata("popup_title") ?>',
            text: '<?= session()->getFlashdata("popup_message") ?>',
            timer: 2000,
            showConfirmButton: false,
            timerProgressBar: true
        });
        // Clear the flashdata after showing
        <?php session()->remove('show_popup_success'); ?>
        <?php session()->remove('popup_message'); ?>
        <?php session()->remove('popup_title'); ?>
    <?php endif; ?>
    
    // Get current CSRF token
    const csrfToken = $('meta[name="csrf-token"]').attr('content') || '<?= csrf_hash() ?>';
    const csrfName = '<?= csrf_token() ?>';
    
    // ========== TAMBAH SISWA (AJAX) ==========
    $('#formTambahSiswa').on('submit', function(e) {
        e.preventDefault();
        
        // Check if there are any classes available
        const kelasSelect = $('#id_kelas');
        if (kelasSelect.find('option').length <= 1) { // Only has "Pilih Kelas"
            Swal.fire({
                icon: 'error',
                title: 'Tidak Ada Kelas',
                text: 'Belum ada data kelas. Silakan tambahkan kelas terlebih dahulu.',
                confirmButtonText: 'OK'
            });
            return;
        }
        
        // Validate password confirmation
        const password = $('#password').val();
        const passwordConfirm = $('#password_confirm').val();
        
        if (password !== passwordConfirm) {
            Swal.fire({
                icon: 'error',
                title: 'Password Tidak Cocok',
                text: 'Password dan konfirmasi password harus sama'
            });
            return;
        }
        
        const form = $(this);
        const formData = form.serialize();
        
        // Show loading
        const submitBtn = form.find('#btnSimpanSiswa');
        const originalText = submitBtn.html();
        submitBtn.html('<i class="bi bi-hourglass-split"></i> Processing...');
        submitBtn.prop('disabled', true);
        
        // Clear previous errors
        form.find('.is-invalid').removeClass('is-invalid');
        form.find('.invalid-feedback').text('');
        
        $.ajax({
            url: '<?= base_url("/siswa/create") ?>',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Show success message
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false,
                        timerProgressBar: true
                    }).then(() => {
                        // Close modal and reload page
                        $('#addModal').modal('hide');
                        location.reload();
                    });
                } else {
                    // Show validation errors
                    if (response.errors) {
                        // Tampilkan error di masing-masing field
                        $.each(response.errors, function(key, value) {
                            const field = $('[name="' + key + '"]');
                            const errorDiv = $('#' + key + '_error');
                            
                            if (field.length && errorDiv.length) {
                                field.addClass('is-invalid');
                                errorDiv.text(value);
                            }
                        });
                        
                        // Tampilkan alert umum jika ada error unique
                        if (response.errors.nisn) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Gagal',
                                text: 'NISN sudah digunakan'
                            });
                        } else if (response.errors.id_kelas) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Gagal',
                                text: 'Kelas wajib dipilih'
                            });
                        } else if (response.errors.password) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Password',
                                text: 'Password minimal 6 karakter'
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal!',
                            text: response.message || 'Terjadi kesalahan saat menambahkan data'
                        });
                    }
                    
                    // Aktifkan kembali tombol submit
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Terjadi kesalahan pada server.'
                });
                
                // Aktifkan kembali tombol submit
                submitBtn.html(originalText);
                submitBtn.prop('disabled', false);
            }
        });
    });

    // ========== VIEW SISWA (AJAX) ==========
    $(document).on('click', '.view-siswa-btn', function() {
        const id = $(this).data('id');
        
        // Show loading
        $('#viewContent').html(`
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Memuat data...</p>
            </div>
        `);
        
        $.ajax({
            url: '<?= base_url("/siswa/get/") ?>' + id,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    const s = response.data;
                    let html = `
                        <div class="row">
                            <div class="col-md-4 text-center mb-3">
                                <div class="bg-light p-4 rounded">
                                    <i class="bi bi-person-circle fs-1 ${s.jenis_kelamin == 'L' ? 'text-primary' : 'text-danger'}"></i>
                                    <h5 class="mt-2">${s.nama_siswa}</h5>
                                    <span class="badge ${s.jenis_kelamin == 'L' ? 'bg-primary' : 'bg-danger'}">
                                        ${s.jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'}
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <table class="table table-bordered">
                                    <tr>
                                        <th width="40%">NISN</th>
                                        <td>${s.nisn}</td>
                                    </tr>
                                    <tr>
                                        <th>Tempat Lahir</th>
                                        <td>${s.tempat_lahir}</td>
                                    </tr>
                                    <tr>
                                        <th>Tanggal Lahir</th>
                                        <td>${s.tanggal_lahir}</td>
                                    </tr>
                                    <tr>
                                        <th>Alamat</th>
                                        <td>${s.alamat}</td>
                                    </tr>
                                    <tr>
                                        <th>No. HP</th>
                                        <td>${s.no_hp}</td>
                                    </tr>
                                    <tr>
                                        <th>Kelas</th>
                                        <td>${s.nama_kelas || '<span class="text-warning">Belum ada kelas</span>'}</td>
                                    </tr>
                                    <tr>
                                        <th>Tahun Masuk</th>
                                        <td>${s.tahun_masuk}</td>
                                    </tr>
                                    <tr>
                                        <th>Tanggal Daftar</th>
                                        <td>${s.created_at}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    `;
                    $('#viewContent').html(html);
                } else {
                    $('#viewContent').html(`
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-triangle"></i> ${response.message || 'Gagal memuat data'}
                        </div>
                    `);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                $('#viewContent').html(`
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> Terjadi kesalahan saat memuat data
                    </div>
                `);
            }
        });
    });

    // ========== EDIT SISWA ==========
    $(document).on('click', '.edit-siswa-btn', function() {
        const id = $(this).data('id');
        
        // Show loading
        $('#editContent').html(`
            <div class="text-center py-4">
                <div class="spinner-border text-warning" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Memuat data...</p>
            </div>
        `);
        
        $.ajax({
            url: '<?= base_url("/siswa/get/") ?>' + id,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    const s = response.data;
                    
                    // Build kelas options
                    let kelasOptions = '<option value="">Pilih Kelas</option>';
                    <?php foreach($kelas as $k): ?>
                        <?php 
                        $kelas_id = is_array($k) ? $k['id'] : $k->id;
                        $kelas_nama = is_array($k) ? $k['nama_kelas'] : $k->nama_kelas;
                        ?>
                        kelasOptions += `<option value="<?= $kelas_id ?>" ${s.id_kelas == <?= $kelas_id ?> ? 'selected' : ''}><?= $kelas_nama ?></option>`;
                    <?php endforeach; ?>
                    
                    const html = `
                        <input type="hidden" name="id" value="${s.id}">
                        <input type="hidden" name="${csrfName}" value="${csrfToken}">
                        
                        <div class="mb-3">
                            <label class="form-label">NISN <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" 
                                   name="nisn" 
                                   value="${s.nisn}" 
                                   required>
                            <div class="invalid-feedback" id="edit_nisn_error"></div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" 
                                       name="nama_siswa" 
                                       value="${s.nama_siswa}" 
                                       required>
                                <div class="invalid-feedback" id="edit_nama_siswa_error"></div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                                <select class="form-select" name="jenis_kelamin" required>
                                    <option value="L" ${s.jenis_kelamin == 'L' ? 'selected' : ''}>Laki-laki</option>
                                    <option value="P" ${s.jenis_kelamin == 'P' ? 'selected' : ''}>Perempuan</option>
                                </select>
                                <div class="invalid-feedback" id="edit_jenis_kelamin_error"></div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tempat Lahir <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" 
                                       name="tempat_lahir" 
                                       value="${s.tempat_lahir}" 
                                       required>
                                <div class="invalid-feedback" id="edit_tempat_lahir_error"></div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tanggal Lahir <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" 
                                       name="tanggal_lahir" 
                                       value="${s.tanggal_lahir}" 
                                       max="<?= date('Y-m-d') ?>" 
                                       required>
                                <div class="invalid-feedback" id="edit_tanggal_lahir_error"></div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Alamat <span class="text-danger">*</span></label>
                            <textarea class="form-control" 
                                      name="alamat" 
                                      rows="2" 
                                      required>${s.alamat}</textarea>
                            <div class="invalid-feedback" id="edit_alamat_error"></div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">No. HP <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" 
                                       name="no_hp" 
                                       value="${s.no_hp}" 
                                       required>
                                <div class="invalid-feedback" id="edit_no_hp_error"></div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Kelas <span class="text-danger">*</span></label>
                                <select class="form-select" name="id_kelas" required>
                                    ${kelasOptions}
                                </select>
                                <div class="invalid-feedback" id="edit_id_kelas_error"></div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Tahun Masuk <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" 
                                   name="tahun_masuk" 
                                   value="${s.tahun_masuk}" 
                                   min="2000" 
                                   max="<?= date('Y') + 1 ?>" 
                                   required>
                            <div class="invalid-feedback" id="edit_tahun_masuk_error"></div>
                        </div>
                        
                        <!-- Password Field untuk Edit -->
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Password Baru (Opsional)</label>
                                <input type="password" class="form-control" 
                                       name="password" 
                                       placeholder="Kosongkan jika tidak ingin mengubah"
                                       minlength="6">
                                <div class="invalid-feedback" id="edit_password_error"></div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Konfirmasi Password Baru</label>
                                <input type="password" class="form-control" 
                                       name="password_confirm" 
                                       placeholder="Konfirmasi password baru"
                                       minlength="6">
                                <div class="invalid-feedback" id="edit_password_confirm_error"></div>
                            </div>
                        </div>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle"></i> Isi password hanya jika ingin mengubah password. Minimal 6 karakter.
                        </div>
                    `;
                    
                    $('#editContent').html(html);
                    
                    // Set form action
                    const updateUrl = '<?= base_url("/siswa/update/") ?>' + id;
                    $('#formEditSiswa').attr('action', updateUrl);
                } else {
                    $('#editContent').html(`
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-triangle"></i> ${response.message || 'Gagal memuat data'}
                        </div>
                    `);
                    $('#btnUpdateSiswa').prop('disabled', true);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                $('#editContent').html(`
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> Terjadi kesalahan saat memuat data
                    </div>
                `);
                $('#btnUpdateSiswa').prop('disabled', true);
            }
        });
    });

    // Handle Edit Form Submit with AJAX
    $('#formEditSiswa').on('submit', function(e) {
        e.preventDefault();
        
        // Check if there are any classes available
        const kelasSelect = $('#editContent').find('[name="id_kelas"]');
        if (kelasSelect.length === 0 || kelasSelect.find('option').length <= 1) {
            Swal.fire({
                icon: 'error',
                title: 'Tidak Ada Kelas',
                text: 'Belum ada data kelas. Silakan tambahkan kelas terlebih dahulu.',
                confirmButtonText: 'OK'
            });
            return;
        }
        
        // Validate password confirmation
        const password = $('#editContent').find('[name="password"]').val();
        const passwordConfirm = $('#editContent').find('[name="password_confirm"]').val();
        
        if (password !== passwordConfirm) {
            Swal.fire({
                icon: 'error',
                title: 'Password Tidak Cocok',
                text: 'Password dan konfirmasi password harus sama'
            });
            return;
        }
        
        const form = $(this);
        const url = form.attr('action');
        const formData = form.serialize();
        
        // Show loading
        const submitBtn = form.find('#btnUpdateSiswa');
        const originalText = submitBtn.html();
        submitBtn.html('<i class="bi bi-hourglass-split"></i> Processing...');
        submitBtn.prop('disabled', true);
        
        // Clear previous errors
        form.find('.is-invalid').removeClass('is-invalid');
        form.find('.invalid-feedback').text('');
        
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Show success message
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false,
                        timerProgressBar: true
                    }).then(() => {
                        // Close modal and reload page
                        $('#editModal').modal('hide');
                        location.reload();
                    });
                } else {
                    // Show validation errors
                    if (response.errors) {
                        // Tampilkan error di masing-masing field
                        $.each(response.errors, function(key, value) {
                            const field = $('[name="' + key + '"]');
                            const errorDiv = $('#edit_' + key + '_error');
                            
                            if (field.length && errorDiv.length) {
                                field.addClass('is-invalid');
                                errorDiv.text(value);
                            }
                        });
                        
                        // Tampilkan alert umum jika ada error unique
                        if (response.errors.nisn) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Gagal',
                                text: 'NISN sudah digunakan'
                            });
                        } else if (response.errors.id_kelas) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Gagal',
                                text: 'Kelas wajib dipilih'
                            });
                        } else if (response.errors.password) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Validasi Password',
                                text: 'Password minimal 6 karakter'
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal!',
                            text: response.message || 'Terjadi kesalahan saat update'
                        });
                    }
                    
                    // Aktifkan kembali tombol submit
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Terjadi kesalahan pada server.'
                });
                
                // Aktifkan kembali tombol submit
                submitBtn.html(originalText);
                submitBtn.prop('disabled', false);
            }
        });
    });

    // ========== DELETE SISWA ==========
    $(document).on('click', '.delete-siswa-btn', function(e) {
        e.preventDefault();
        
        const id = $(this).data('id');
        const name = $(this).data('name');
        
        Swal.fire({
            title: 'Hapus Data Siswa?',
            html: `Apakah Anda yakin ingin menghapus siswa <strong>${name}</strong>?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '<?= base_url("/siswa/delete/") ?>' + id;
            }
        });
    });

    // ========== SEARCH SISWA ==========
    $('#searchBtn').click(function() {
        const keyword = $('#searchInput').val().trim();
        
        if (keyword.length < 2) {
            Swal.fire({
                icon: 'warning',
                title: 'Peringatan',
                text: 'Masukkan minimal 2 karakter untuk pencarian',
                timer: 2000,
                showConfirmButton: false,
                timerProgressBar: true
            });
            return;
        }
        
        // Show loading
        $('#studentsTable').html(`
            <tr>
                <td colspan="7" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Mencari data...</p>
                </td>
            </tr>
        `);
        
        $.ajax({
            url: '<?= base_url("/siswa/search") ?>',
            type: 'GET',
            data: { keyword: keyword },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    if (response.data.length > 0) {
                        let html = '';
                        response.data.forEach(function(siswa) {
                            html += `
                                <tr>
                                    <td>${siswa.nisn}</td>
                                    <td>${siswa.nama_siswa}</td>
                                    <td>
                                        ${siswa.nama_kelas ? 
                                            `<span class="badge bg-primary">${siswa.nama_kelas}</span>` : 
                                            `<span class="badge bg-warning">Belum ada kelas</span>`
                                        }
                                    </td>
                                    <td>${siswa.jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'}</td>
                                    <td>${siswa.no_hp}</td>
                                    <td>${siswa.tahun_masuk}</td>
                                    <td>
                                        <button class="btn btn-sm btn-info view-siswa-btn" 
                                                data-id="${siswa.id}"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#viewModal">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-warning edit-siswa-btn" 
                                                data-id="${siswa.id}" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editModal">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger delete-siswa-btn" 
                                                data-id="${siswa.id}" 
                                                data-name="${siswa.nama_siswa}">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            `;
                        });
                        $('#studentsTable').html(html);
                        
                        Swal.fire({
                            icon: 'success',
                            title: 'Ditemukan!',
                            text: `Ditemukan ${response.data.length} hasil untuk "${keyword}"`,
                            timer: 2000,
                            showConfirmButton: false,
                            timerProgressBar: true
                        });
                    } else {
                        $('#studentsTable').html(`
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <i class="bi bi-search fs-1 text-muted"></i>
                                    <h5 class="mt-2">Tidak ditemukan</h5>
                                    <p class="text-muted">Tidak ada data siswa yang sesuai dengan kata kunci "${keyword}"</p>
                                    <button class="btn btn-sm btn-outline-primary" onclick="location.reload()">
                                        <i class="bi bi-arrow-clockwise"></i> Tampilkan Semua
                                    </button>
                                </td>
                            </tr>
                        `);
                    }
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: response.message || 'Terjadi kesalahan saat pencarian'
                    });
                    location.reload();
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Terjadi kesalahan pada server saat pencarian'
                });
                location.reload();
            }
        });
    });

    // Clear search when input is empty
    $('#searchInput').on('input', function() {
        if ($(this).val().trim() === '') {
            location.reload();
        }
    });

    // ========== MODAL HANDLING ==========
    // Reset form when modal is closed
    $('#addModal').on('hidden.bs.modal', function() {
        $('#formTambahSiswa')[0].reset();
        $('#formTambahSiswa .is-invalid').removeClass('is-invalid');
        $('#formTambahSiswa .invalid-feedback').text('');
        $('#btnSimpanSiswa').prop('disabled', false).html('<i class="bi bi-save"></i> Simpan');
    });
    
    $('#editModal').on('hidden.bs.modal', function() {
        $('#editContent').empty();
        $('#formEditSiswa .is-invalid').removeClass('is-invalid');
        $('#formEditSiswa .invalid-feedback').text('');
        $('#btnUpdateSiswa').prop('disabled', false).html('<i class="bi bi-check-circle"></i> Update');
    });
    
    $('#viewModal').on('hidden.bs.modal', function() {
        $('#viewContent').empty();
    });
});
</script>
<?= $this->endSection(); ?>