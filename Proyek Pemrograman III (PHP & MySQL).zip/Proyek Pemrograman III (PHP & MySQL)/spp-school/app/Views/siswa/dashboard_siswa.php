<?= $this->extend('layout/main_siswa') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4 px-lg-5">
    <!-- Welcome Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="welcome-card p-4 p-lg-5 mb-4 rounded-4">
                <div class="row align-items-center">
                    <div class="col-lg-8 mb-4 mb-lg-0">
                        <div class="d-flex align-items-center mb-3">
                            <div class="icon-wrapper bg-white bg-opacity-20 rounded-3 p-3 me-3">
                                <i class="bi bi-house-door text-white fa-2x"></i>
                            </div>
                            <h2 class="mb-0 text-black fw-bold">Dashboard Siswa</h2>
                        </div>
                        <div class="ps-2">
                            <p class="mb-2 text-black opacity-85 fs-5">
                                Selamat datang, <strong class="text-warning"><?= session()->get('nama_lengkap') ?></strong>!
                            </p>
                            <p class="mb-0 text-black opacity-85 fs-5">
                                Anda login sebagai siswa <span class="badge bg-white text-primary px-3 py-2"><?= session()->get('nama_kelas') ?></span>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="d-flex justify-content-lg-end">
                            <div class="stats-summary-card bg-white text-primary rounded-4 p-4 p-lg-4 shadow-lg">
                                <div class="text-center">
                                    <h1 class="display-5 fw-bold mb-2"><?= $bulan_bayar ?? 0 ?>/12</h1>
                                    <p class="text-muted fw-medium mb-1">Bulan Terbayar</p>
                                    <div class="progress mt-3" style="height: 8px;">
                                        <div class="progress-bar bg-primary" role="progressbar" 
                                             style="width: <?= (($bulan_bayar ?? 0) / 12) * 100 ?>%"
                                             aria-valuenow="<?= (($bulan_bayar ?? 0) / 12) * 100 ?>" 
                                             aria-valuemin="0" 
                                             aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Stats Cards -->
    <div class="row g-4 mb-5">
        <div class="col-xl-3 col-lg-6">
            <div class="card-siswa h-100 border-0 rounded-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1 me-4">
                            <p class="text-muted fw-semibold mb-2">Nominal SPP</p>
                            <h3 class="fw-bold mb-2">Rp <?= number_format($spp->nominal ?? 0, 0, ',', '.') ?></h3>
                            <span class="badge bg-primary-subtle text-primary fw-medium px-3 py-2 rounded-pill">Per Bulan</span>
                        </div>
                        <div class="flex-shrink-0">
                            <div class="icon-circle bg-primary bg-opacity-10 rounded-3 p-3">
                                <i class="bi bi-cash-coin fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-6">
            <div class="card-siswa h-100 border-0 rounded-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1 me-4">
                            <p class="text-muted fw-semibold mb-2">Total Dibayar (<?= date('Y') ?>)</p>
                            <?php
                            $total_dibayar = 0;
                            if (!empty($pembayaran)) {
                                foreach($pembayaran as $payment) {
                                    $tahun = is_object($payment) ? $payment->tahun : $payment['tahun'];
                                    $jumlah = is_object($payment) ? $payment->jumlah_bayar : $payment['jumlah_bayar'];
                                    
                                    if ($tahun == date('Y')) {
                                        $total_dibayar += (float) $jumlah;
                                    }
                                }
                            }
                            ?>
                            <h3 class="fw-bold mb-2">Rp <?= number_format($total_dibayar, 0, ',', '.') ?></h3>
                            <span class="badge bg-success-subtle text-success fw-medium px-3 py-2 rounded-pill">Tahun Ini</span>
                        </div>
                        <div class="flex-shrink-0">
                            <div class="icon-circle bg-success bg-opacity-10 rounded-3 p-3">
                                <i class="bi bi-wallet2 fa-2x text-success"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-6">
            <div class="card-siswa h-100 border-0 rounded-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1 me-4">
                            <p class="text-muted fw-semibold mb-2">Bulan Tertunggak</p>
                            <h3 class="fw-bold mb-2 text-warning"><?= 12 - ($bulan_bayar ?? 0) ?></h3>
                            <span class="badge bg-warning-subtle text-warning fw-medium px-3 py-2 rounded-pill">Perlu Perhatian</span>
                        </div>
                        <div class="flex-shrink-0">
                            <div class="icon-circle bg-warning bg-opacity-10 rounded-3 p-3">
                                <i class="bi bi-clock-history fa-2x text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-6">
            <div class="card-siswa h-100 border-0 rounded-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1 me-4">
                            <p class="text-muted fw-semibold mb-2">Total Tunggakan</p>
                            <h3 class="fw-bold mb-2 text-danger">Rp <?= number_format((12 - ($bulan_bayar ?? 0)) * ($spp->nominal ?? 0), 0, ',', '.') ?></h3>
                            <span class="badge bg-danger-subtle text-danger fw-medium px-3 py-2 rounded-pill">Belum Dibayar</span>
                        </div>
                        <div class="flex-shrink-0">
                            <div class="icon-circle bg-danger bg-opacity-10 rounded-3 p-3">
                                <i class="bi bi-exclamation-triangle fa-2x text-danger"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="row g-4">
        <!-- Left Column - Payment Status -->
        <div class="col-lg-8">
            <div class="card-siswa border-0 rounded-4 h-100">
                <div class="card-header-siswa py-4 px-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="m-0 fw-bold text-primary">
                            <i class="bi bi-calendar2-check me-3"></i>
                            Status Pembayaran SPP Tahun <?= date('Y') ?>
                        </h5>
                        <p class="text-muted mb-0 mt-1 small">Monitor status pembayaran bulanan Anda</p>
                    </div>
                    <div>
                        <span class="badge bg-primary-subtle text-primary px-3 py-2">
                            <?= $bulan_bayar ?? 0 ?> dari 12 bulan lunas
                        </span>
                    </div>
                </div>
                <div class="card-body p-4">
                    <div class="table-responsive-lg">
                        <table class="table table-siswa table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="py-3 px-4 text-start">Bulan</th>
                                    <th class="py-3 px-4 text-center">Status</th>
                                    <th class="py-3 px-4 text-center">Tanggal Bayar</th>
                                    <th class="py-3 px-4 text-end">Jumlah</th>
                                    <th class="py-3 px-4 text-end">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $bulan_list = [
                                    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                                    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                                ];
                                
                                foreach($bulan_list as $index => $bulan):
                                    $payment_found = null;
                                    if (!empty($pembayaran)) {
                                        foreach($pembayaran as $payment) {
                                            $bulan_payment = is_object($payment) ? $payment->bulan : $payment['bulan'];
                                            $tahun_payment = is_object($payment) ? $payment->tahun : $payment['tahun'];
                                            
                                            if ($bulan_payment == $bulan && $tahun_payment == date('Y')) {
                                                $payment_found = $payment;
                                                break;
                                            }
                                        }
                                    }
                                    
                                    $is_current_month = (date('n') - 1) == $index;
                                ?>
                                    <tr class="align-middle <?= $is_current_month ? 'table-active' : '' ?>">
                                        <td class="py-3 px-4">
                                            <div class="d-flex align-items-center">
                                                <div class="month-indicator me-3 rounded-2 <?= $payment_found ? 'bg-success' : 'bg-warning' ?>">
                                                    <?php if($is_current_month): ?>
                                                        <span class="badge bg-info text-white position-absolute top-0 start-100 translate-middle rounded-pill px-2 py-1" style="font-size: 0.6rem;">Bulan Ini</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div>
                                                    <strong class="d-block"><?= $bulan ?></strong>
                                                    <small class="text-muted">Tahun <?= date('Y') ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="py-3 px-4 text-center">
                                            <?php if ($payment_found): ?>
                                                <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2 fw-medium rounded-pill">
                                                    <i class="bi bi-check-circle me-2"></i>Lunas
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25 px-3 py-2 fw-medium rounded-pill">
                                                    <i class="bi bi-clock me-2"></i>Belum Bayar
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="py-3 px-4 text-center">
                                            <?php if ($payment_found): 
                                                $tanggal_bayar = is_object($payment_found) ? $payment_found->tanggal_bayar : $payment_found['tanggal_bayar'];
                                            ?>
                                                <span class="text-muted"><?= date('d/m/Y', strtotime($tanggal_bayar)) ?></span>
                                            <?php else: ?>
                                                <span class="text-muted opacity-50">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="py-3 px-4 text-end">
                                            <span class="fw-bold <?= $payment_found ? 'text-success' : 'text-danger' ?>">
                                                <?php if ($payment_found): 
                                                    $jumlah_bayar = is_object($payment_found) ? $payment_found->jumlah_bayar : $payment_found['jumlah_bayar'];
                                                ?>
                                                    Rp <?= number_format($jumlah_bayar, 0, ',', '.') ?>
                                                <?php else: ?>
                                                    Rp <?= number_format($spp->nominal ?? 0, 0, ',', '.') ?>
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td class="py-3 px-4 text-end">
                                            <?php if (!$payment_found): ?>
                                                <a href="<?= base_url('siswa/pembayaran_siswa') ?>?bulan=<?= urlencode($bulan) ?>" 
                                                   class="btn btn-sm btn-primary rounded-pill px-3 py-1">
                                                    <i class="bi bi-credit-card me-1"></i> Bayar
                                                </a>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-outline-success rounded-pill px-3 py-1" disabled>
                                                    <i class="bi bi-check-lg me-1"></i> Sudah Bayar
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="row mt-4 pt-3 border-top">
                        <div class="col-md-6">
                            <div class="d-flex align-items-center">
                                <div class="legend-indicator bg-success me-2"></div>
                                <small class="text-muted">Lunas</small>
                                <div class="legend-indicator bg-warning mx-3"></div>
                                <small class="text-muted">Belum Bayar</small>
                            </div>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <a href="<?= base_url('siswa/laporan_siswa') ?>" class="btn btn-outline-primary rounded-pill px-4">
                                <i class="bi bi-download me-2"></i>Unduh Laporan
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column - Sidebar -->
        <div class="col-lg-4">
            <!-- Recent Payments -->
            <div class="card-siswa border-0 rounded-4 mb-4">
                <div class="card-header-siswa py-4 px-4">
                    <h5 class="m-0 fw-bold text-primary">
                        <i class="bi bi-receipt me-3"></i>
                        Pembayaran Terbaru
                    </h5>
                </div>
                <div class="card-body p-4">
                    <?php if (!empty($pembayaran)): ?>
                        <?php 
                        $recent_payments = array_slice($pembayaran, 0, 5);
                        foreach($recent_payments as $payment): 
                            $bulan = is_object($payment) ? $payment->bulan : $payment['bulan'];
                            $tahun = is_object($payment) ? $payment->tahun : $payment['tahun'];
                            $tanggal_bayar = is_object($payment) ? $payment->tanggal_bayar : $payment['tanggal_bayar'];
                            $metode_pembayaran = is_object($payment) ? $payment->metode_pembayaran : $payment['metode_pembayaran'];
                            $jumlah_bayar = is_object($payment) ? $payment->jumlah_bayar : $payment['jumlah_bayar'];
                            $nama_petugas = is_object($payment) ? ($payment->nama_petugas ?? 'Petugas') : ($payment['nama_petugas'] ?? 'Petugas');
                        ?>
                            <div class="recent-payment mb-3 pb-3 border-bottom">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <h6 class="mb-1 fw-semibold text-dark"><?= $bulan ?> <?= $tahun ?></h6>
                                        <small class="text-muted">
                                            <i class="bi bi-calendar me-1"></i>
                                            <?= date('d/m/Y', strtotime($tanggal_bayar)) ?>
                                        </small>
                                    </div>
                                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2 fw-medium">
                                        Rp <?= number_format($jumlah_bayar, 0, ',', '.') ?>
                                    </span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <i class="bi bi-credit-card me-1"></i>
                                        <?= $metode_pembayaran ?>
                                    </small>
                                    <small class="text-muted">
                                        <i class="bi bi-person me-1"></i>
                                        <?= $nama_petugas ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <div class="text-center mt-4 pt-2">
                            <a href="<?= base_url('siswa/history_siswa') ?>" class="btn btn-outline-primary rounded-3 px-4 py-2 fw-semibold w-100">
                                <i class="bi bi-eye me-2"></i>Lihat Semua Riwayat
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <div class="bg-light rounded-3 p-4 mb-4 d-inline-block">
                                <i class="bi bi-receipt text-muted fa-3x"></i>
                            </div>
                            <p class="text-muted mb-4">Belum ada riwayat pembayaran</p>
                            <a href="<?= base_url('siswa/pembayaran_siswa') ?>" class="btn btn-primary rounded-3 px-4 py-3 w-100 fw-semibold">
                                <i class="bi bi-cash-stack me-2"></i>Bayar Sekarang
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Information -->
            <div class="card-siswa border-0 rounded-4">
                <div class="card-header-siswa py-4 px-4">
                    <h5 class="m-0 fw-bold text-primary">
                        <i class="bi bi-info-circle me-3"></i>
                        Informasi Penting
                    </h5>
                </div>
                <div class="card-body p-4">
                    <div class="alert alert-warning border-warning border-opacity-25 bg-warning bg-opacity-10 rounded-3 mb-4">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="bi bi-calendar-x text-warning fs-5"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="alert-heading fw-semibold mb-2">Batas Waktu Pembayaran</h6>
                                <p class="mb-0 small">
                                    Pembayaran SPP maksimal tanggal 10 setiap bulannya.
                                    Keterlambatan dikenakan denda Rp 10.000 per bulan.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-info border-info border-opacity-25 bg-info bg-opacity-10 rounded-3 mb-4">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="bi bi-clock text-info fs-5"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="alert-heading fw-semibold mb-2">Jam Layanan</h6>
                                <p class="mb-2 small">Senin - Jumat: 08.00 - 15.00 WIB</p>
                                <p class="mb-0 small">Sabtu: 08.00 - 12.00 WIB</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-success border-success border-opacity-25 bg-success bg-opacity-10 rounded-3 mb-4">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="bi bi-telephone text-success fs-5"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="alert-heading fw-semibold mb-2">Kontak Tata Usaha</h6>
                                <p class="mb-1 small">
                                    <i class="bi bi-whatsapp me-2"></i>
                                    <strong>WA:</strong> 0822-9912-9507
                                </p>
                                <p class="mb-0 small">
                                    <i class="bi bi-telephone me-2"></i>
                                    <strong>Telp:</strong> 082299129507
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <a href="https://wa.me/6282299129507" target="_blank" class="btn btn-success rounded-3 px-4 py-3 fw-semibold w-100 mb-2">
                            <i class="bi bi-whatsapp me-2"></i>
                            Chat via WhatsApp
                        </a>
                        <a href="tel:082299129507" class="btn btn-outline-secondary rounded-3 px-4 py-3 fw-semibold w-100">
                            <i class="bi bi-telephone me-2"></i>
                            Hubungi via Telepon
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    :root {
        --primary-gradient: linear-gradient(135deg, #4e73df 0%, #2e59d9 100%);
        --primary-light: #4e73df;
        --primary-dark: #2e59d9;
        --success-light: #1cc88a;
        --warning-light: #f6c23e;
        --danger-light: #e74a3b;
        --border-radius-card: 1rem;
        --box-shadow-card: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        --box-shadow-hover: 0 0.35rem 2.5rem 0 rgba(58, 59, 69, 0.2);
    }
    
    .welcome-card {
        background: var(--primary-gradient);
        color: white;
        border-radius: var(--border-radius-card);
        box-shadow: 0 0.5rem 1.5rem rgba(78, 115, 223, 0.25);
        overflow: hidden;
        position: relative;
    }
    
    .welcome-card::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 100%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
        background-size: 20px 20px;
        opacity: 0.1;
        transform: rotate(45deg);
    }
    
    .icon-wrapper {
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255,255,255,0.2);
    }
    
    .stats-summary-card {
        transition: all 0.3s ease;
        min-width: 200px;
    }
    
    .stats-summary-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 1rem 3rem rgba(0,0,0,0.1) !important;
    }
    
    .card-siswa {
        background: white;
        border: none;
        border-radius: var(--border-radius-card);
        box-shadow: var(--box-shadow-card);
        transition: all 0.3s ease;
        height: 100%;
        overflow: hidden;
    }
    
    .card-siswa:hover {
        box-shadow: var(--box-shadow-hover);
        transform: translateY(-2px);
    }
    
    .card-header-siswa {
        background: white;
        border-bottom: 2px solid #f8f9fc;
        border-radius: var(--border-radius-card) var(--border-radius-card) 0 0 !important;
        padding: 1.5rem 1.5rem 0.5rem 1.5rem;
    }
    
    .icon-circle {
        width: 64px;
        height: 64px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50% !important;
    }
    
    .month-indicator {
        width: 8px;
        height: 48px;
        position: relative;
        border-radius: 4px;
    }
    
    .legend-indicator {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        display: inline-block;
    }
    
    .table-siswa {
        --bs-table-hover-bg: rgba(78, 115, 223, 0.05);
        border-collapse: separate;
        border-spacing: 0;
    }
    
    .table-siswa thead th {
        background-color: #f8f9fc;
        border-bottom: 2px solid #e3e6f0;
        color: var(--primary-light);
        font-weight: 700;
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        position: sticky;
        top: 0;
        z-index: 10;
    }
    
    .table-siswa tbody tr {
        transition: all 0.2s ease;
    }
    
    .table-siswa tbody tr:hover {
        background-color: var(--bs-table-hover-bg) !important;
        transform: scale(1.002);
    }
    
    .table-siswa tbody tr:last-child td {
        border-bottom: none;
    }
    
    .recent-payment {
        transition: all 0.3s ease;
        border-radius: 8px;
        padding: 12px;
    }
    
    .recent-payment:hover {
        background-color: #f8f9fc;
        transform: translateX(5px);
    }
    
    .progress-bar {
        transition: width 0.6s ease;
        border-radius: 4px;
    }
    
    /* Desktop specific styles */
    @media (min-width: 1200px) {
        .container-fluid {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .welcome-card {
            padding: 3rem 4rem !important;
        }
        
        .card-siswa {
            margin-bottom: 0;
        }
        
        .table-responsive-lg {
            max-height: 500px;
            overflow-y: auto;
            border-radius: 0.5rem;
            border: 1px solid #e3e6f0;
        }
        
        .table-responsive-lg thead th {
            position: sticky;
            top: 0;
            z-index: 10;
        }
    }
    
    @media (min-width: 992px) {
        .col-lg-8 {
            padding-right: 1rem;
        }
        
        .col-lg-4 {
            padding-left: 1rem;
        }
    }
    
    /* Animation for page load */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .welcome-card,
    .card-siswa {
        animation: fadeInUp 0.6s ease-out;
    }
    
    .card-siswa:nth-child(2) { animation-delay: 0.1s; }
    .card-siswa:nth-child(3) { animation-delay: 0.2s; }
    .card-siswa:nth-child(4) { animation-delay: 0.3s; }
    .card-siswa:nth-child(5) { animation-delay: 0.4s; }
    
    /* Custom scrollbar for tables */
    .table-responsive-lg::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    
    .table-responsive-lg::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 4px;
    }
    
    .table-responsive-lg::-webkit-scrollbar-thumb {
        background: #c1c1c1;
        border-radius: 4px;
    }
    
    .table-responsive-lg::-webkit-scrollbar-thumb:hover {
        background: #a8a8a8;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Highlight current month in table
    const currentMonth = new Date().toLocaleString('id-ID', { month: 'long' });
    const tableRows = document.querySelectorAll('.table-siswa tbody tr');
    
    tableRows.forEach(row => {
        const monthCell = row.querySelector('td:first-child strong');
        if (monthCell && monthCell.textContent.trim() === currentMonth) {
            row.classList.add('table-active');
            row.style.backgroundColor = '#f0f7ff';
            row.querySelector('.month-indicator').innerHTML += 
                '<span class="badge bg-info text-white position-absolute top-0 start-100 translate-middle rounded-pill px-2 py-1" style="font-size: 0.6rem;">Bulan Ini</span>';
        }
    });
    
    // Add hover effect to payment rows
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.boxShadow = 'none';
        });
    });
    
    // Auto-dismiss alerts after 10 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 10000);
    
    // Payment reminder notification
    const today = new Date();
    const day = today.getDate();
    const month = today.getMonth() + 1;
    const unpaidMonths = <?= 12 - ($bulan_bayar ?? 0) ?>;
    
    // Only show notification for unpaid months and after 5th of month
    if (unpaidMonths > 0 && day > 5) {
        showPaymentReminder(unpaidMonths, day, month);
    }
    
    function showPaymentReminder(unpaidCount, currentDay, currentMonth) {
        const paymentCard = document.querySelector('.card-siswa:nth-child(4)');
        if (paymentCard) {
            paymentCard.classList.add('pulse-animation');
            
            // Remove animation after 3 seconds
            setTimeout(() => {
                paymentCard.classList.remove('pulse-animation');
            }, 3000);
        }
        
        // Show floating notification for desktop
        if (window.innerWidth > 768 && currentDay > 5) {
            const notification = createNotification(unpaidCount, currentDay);
            document.body.appendChild(notification);
            
            // Auto remove after 15 seconds
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 15000);
        }
    }
    
    function createNotification(unpaidCount, currentDay) {
        const notification = document.createElement('div');
        notification.className = 'payment-notification position-fixed shadow-lg rounded-3 p-3 border border-warning';
        notification.style.cssText = `
            bottom: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 320px;
            background: linear-gradient(135deg, #fff8e1 0%, #ffecb3 100%);
            animation: slideInRight 0.5s ease-out;
        `;
        
        let message = '';
        let icon = 'bi-exclamation-triangle';
        
        if (currentDay > 5 && currentDay <= 10) {
            message = `Anda memiliki ${unpaidCount} bulan belum dibayar. Batas tanggal 10!`;
            icon = 'bi-exclamation-circle';
        } else if (currentDay > 10) {
            message = `PERHATIAN: ${unpaidCount} bulan belum dibayar! Denda berlaku.`;
            icon = 'bi-exclamation-triangle-fill';
        }
        
        notification.innerHTML = `
            <div class="d-flex align-items-center">
                <div class="flex-shrink-0">
                    <i class="bi ${icon} text-warning fs-4"></i>
                </div>
                <div class="flex-grow-1 ms-3">
                    <h6 class="mb-1 fw-bold">Pengingat Pembayaran</h6>
                    <p class="mb-2 small">${message}</p>
                    <div class="d-flex justify-content-between">
                        <a href="<?= base_url('siswa/pembayaran_siswa') ?>" class="btn btn-sm btn-warning rounded-pill px-3">
                            <i class="bi bi-credit-card me-1"></i> Bayar Sekarang
                        </a>
                        <button class="btn btn-sm btn-outline-secondary rounded-pill px-3 close-notif">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Close button functionality
        notification.querySelector('.close-notif').addEventListener('click', function() {
            notification.style.animation = 'slideOutRight 0.3s ease-out forwards';
            setTimeout(() => notification.remove(), 300);
        });
        
        return notification;
    }
    
    // Add CSS for animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(231, 74, 59, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(231, 74, 59, 0); }
            100% { box-shadow: 0 0 0 0 rgba(231, 74, 59, 0); }
        }
        
        .pulse-animation {
            animation: pulse 2s infinite;
        }
        
        .payment-notification {
            backdrop-filter: blur(10px);
        }
    `;
    document.head.appendChild(style);
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>
<?= $this->endSection() ?>