<?= $this->extend('layout/main_siswa') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4 px-lg-5 py-4">
    <!-- Page Header -->
    <div class="row mb-4 align-items-center">
        <div class="col-lg-8">
            <div class="d-flex align-items-center">
                <div class="icon-header bg-primary bg-opacity-10 rounded-3 p-3 me-3">
                    <i class="bi bi-cash-stack text-primary fa-2x"></i>
                </div>
                <div>
                    <h1 class="h2 fw-bold text-dark mb-2">Pembayaran SPP</h1>
                    <p class="text-white mb-0">Lakukan pembayaran SPP bulanan Anda</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 text-lg-end">
            <div class="d-flex gap-2 justify-content-lg-end">
                <a href="<?= base_url('siswa/dashboard_siswa') ?>" class="btn btn-outline-secondary rounded-3 px-4 py-2">
                    <i class="bi bi-arrow-left me-2"></i>Kembali
                </a>
                
            </div>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 rounded-3 shadow-sm mb-4" role="alert">
            <div class="d-flex align-items-center">
                <div class="flex-shrink-0">
                    <i class="bi bi-check-circle-fill fs-4"></i>
                </div>
                <div class="flex-grow-1 ms-3">
                    <h6 class="alert-heading fw-bold mb-1">Berhasil!</h6>
                    <p class="mb-0"><?= session()->getFlashdata('success') ?></p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show border-0 rounded-3 shadow-sm mb-4" role="alert">
            <div class="d-flex align-items-center">
                <div class="flex-shrink-0">
                    <i class="bi bi-exclamation-triangle-fill fs-4"></i>
                </div>
                <div class="flex-grow-1 ms-3">
                    <h6 class="alert-heading fw-bold mb-1">Perhatian!</h6>
                    <p class="mb-0"><?= session()->getFlashdata('error') ?></p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Left Column - Payment Information -->
        <div class="col-lg-5">
            <div class="card border-0 rounded-4 shadow-sm h-100">
                <div class="card-header bg-white border-bottom py-4">
                    <h5 class="mb-0 fw-bold text-dark">
                        <i class="bi bi-info-circle me-2"></i>Informasi Pembayaran
                    </h5>
                    <p class="text-muted mb-0 small">Detail pembayaran dan status</p>
                </div>
                <div class="card-body p-4">
                    <!-- SPP Amount -->
                    <div class="info-card bg-primary bg-opacity-5 border border-white border-opacity-10 rounded-4 p-4 mb-4">
                        <div class="d-flex align-items-center">
                            <div class="icon-box bg-white bg-opacity-10 rounded-3 p-3 me-3">
                                <i class="bi bi-cash-coin text-white fa-2x"></i>
                            </div>
                            <div class="flex-grow-1">
                                <?php
                                $nominal_spp = is_array($spp) ? ($spp['nominal'] ?? 0) : ($spp->nominal ?? 0);
                                ?>
                                <h3 class="fw-bold text-white mb-1">Rp <?= number_format($nominal_spp, 0, ',', '.') ?></h3>
                                <p class="text-white mb-0">Nominal SPP per bulan</p>
                            </div>
                        </div>
                    </div>

                    <!-- Student Info -->
                    <div class="mb-4">
                        <h6 class="fw-semibold mb-3 text-dark">Informasi Siswa:</h6>
                        <div class="student-details">
                            <div class="detail-row d-flex align-items-center mb-3">
                                <div class="detail-icon bg-light rounded-2 p-2 me-3">
                                    <i class="bi bi-person text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">Nama Lengkap</small>
                                    <h6 class="mb-0 fw-semibold"><?= session()->get('nama_lengkap') ?></h6>
                                </div>
                            </div>
                            
                            <div class="detail-row d-flex align-items-center mb-3">
                                <div class="detail-icon bg-light rounded-2 p-2 me-3">
                                    <i class="bi bi-card-heading text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">NISN</small>
                                    <h6 class="mb-0 fw-semibold"><?= session()->get('nisn') ?></h6>
                                </div>
                            </div>
                            
                            <div class="detail-row d-flex align-items-center mb-3">
                                <div class="detail-icon bg-light rounded-2 p-2 me-3">
                                    <i class="bi bi-mortarboard text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">Kelas</small>
                                    <h6 class="mb-0 fw-semibold"><?= session()->get('nama_kelas') ?></h6>
                                </div>
                            </div>
                            
                            <div class="detail-row d-flex align-items-center">
                                <div class="detail-icon bg-light rounded-2 p-2 me-3">
                                    <i class="bi bi-calendar-range text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">Tahun Ajaran</small>
                                    <h6 class="mb-0 fw-semibold"><?= date('Y') ?>/<?= date('Y') + 1 ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Status -->
                    <div class="mb-4">
                        <h6 class="fw-semibold mb-3 text-dark">Status Pembayaran:</h6>
                        <div class="progress-container">
                            <?php
                            $total_months = 12;
                            $paid_months = 0;
                            $current_year = date('Y');
                            
                            if (!empty($pembayaran)) {
                                foreach($pembayaran as $payment) {
                                    $tahun_payment = is_array($payment) ? ($payment['tahun'] ?? '') : ($payment->tahun ?? '');
                                    if ($tahun_payment == $current_year) {
                                        $paid_months++;
                                    }
                                }
                            }
                            
                            $percentage = ($paid_months / $total_months) * 100;
                            ?>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted small">Progress Pembayaran</span>
                                <span class="fw-semibold small"><?= $paid_months ?>/<?= $total_months ?> bulan</span>
                            </div>
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar bg-success" role="progressbar" 
                                     style="width: <?= $percentage ?>%"
                                     aria-valuenow="<?= $percentage ?>" 
                                     aria-valuemin="0" 
                                     aria-valuemax="100"></div>
                            </div>
                            <div class="d-flex justify-content-between mt-2">
                                <small class="text-muted"><?= number_format($percentage, 1) ?>%</small>
                                <small class="text-muted"><?= $total_months - $paid_months ?> bulan tersisa</small>
                            </div>
                        </div>
                    </div>

                    <!-- Important Notes -->
                    <div class="alert alert-warning border-warning border-opacity-25 bg-warning bg-opacity-10 rounded-3">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="bi bi-exclamation-triangle text-warning fs-5"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="alert-heading fw-semibold mb-2">Perhatian Penting!</h6>
                                <ul class="mb-0 small ps-3">
                                    <li class="mb-2">Pembayaran dilakukan di kantor Tata Usaha</li>
                                    <li class="mb-2">Bawa uang tunai sesuai nominal</li>
                                    <li class="mb-2">Batas pembayaran tanggal 10 setiap bulan</li>
                                    <li class="mb-0">Simpan kwitansi sebagai bukti pembayaran</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column - Payment Form -->
        <div class="col-lg-7">
            <div class="card border-0 rounded-4 shadow-sm h-100">
                <div class="card-header bg-white border-bottom py-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-0 fw-bold text-dark">
                                <i class="bi bi-credit-card-2-front me-2"></i>Form Pembayaran SPP
                            </h5>
                            <p class="text-muted mb-0 small">Isi data pembayaran dengan benar</p>
                        </div>
                        <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2">
                            <i class="bi bi-calendar-date me-1"></i>Bulan <?= date('F Y') ?>
                        </span>
                    </div>
                </div>
                <div class="card-body p-4">
                    <form action="<?= base_url('siswa/pembayaran_siswa') ?>" method="POST" id="paymentForm">
                        <?= csrf_field() ?>
                        
                        <!-- Month Selection -->
                        <div class="row g-4 mb-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label fw-semibold mb-2">Pilih Bulan <span class="text-danger">*</span></label>
                                    <select class="form-select form-select-lg border-2 rounded-3 <?= isset($errors['bulan']) ? 'is-invalid' : '' ?>" 
                                            name="bulan" id="bulanSelect" required>
                                        <option value="">-- Pilih Bulan --</option>
                                        <?php
                                        $bulan_list = [
                                            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                                            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                                        ];
                                        
                                        $paid_months = [];
                                        if (!empty($pembayaran)) {
                                            foreach($pembayaran as $payment) {
                                                $tahun_payment = is_array($payment) ? ($payment['tahun'] ?? '') : ($payment->tahun ?? '');
                                                $bulan_payment = is_array($payment) ? ($payment['bulan'] ?? '') : ($payment->bulan ?? '');
                                                if ($tahun_payment == date('Y')) {
                                                    $paid_months[] = $bulan_payment;
                                                }
                                            }
                                        }
                                        
                                        $current_month = date('n') - 1; // 0-based index
                                        
                                        foreach($bulan_list as $index => $bulan):
                                            if (!in_array($bulan, $paid_months)):
                                        ?>
                                            <option value="<?= $bulan ?>" 
                                                    <?= old('bulan') == $bulan ? 'selected' : '' ?>
                                                    <?= $index == $current_month ? 'data-current="true"' : '' ?>>
                                                <?= $bulan ?>
                                                <?php if($index == $current_month): ?>
                                                    <span class="badge bg-info ms-2">Bulan Ini</span>
                                                <?php endif; ?>
                                            </option>
                                        <?php endif; endforeach; ?>
                                    </select>
                                    <?php if(isset($errors['bulan'])): ?>
                                        <div class="invalid-feedback d-block"><?= $errors['bulan'] ?></div>
                                    <?php endif; ?>
                                    <small class="text-muted mt-1 d-block">
                                        <i class="bi bi-info-circle me-1"></i>Hanya bulan yang belum dibayar
                                    </small>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label fw-semibold mb-2">Tahun</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0">
                                            <i class="bi bi-calendar text-muted"></i>
                                        </span>
                                        <input type="text" class="form-control form-control-lg border-start-0 bg-light" 
                                               value="<?= date('Y') ?>" readonly>
                                        <input type="hidden" name="tahun" value="<?= date('Y') ?>">
                                    </div>
                                    <small class="text-muted mt-1 d-block">
                                        <i class="bi bi-info-circle me-1"></i>Tahun ajaran berjalan
                                    </small>
                                </div>
                            </div>
                        </div>

                        <!-- Amount -->
                        <div class="form-group mb-4">
                            <label class="form-label fw-semibold mb-2">Jumlah Bayar <span class="text-danger">*</span></label>
                            <div class="input-group input-group-lg">
                                <span class="input-group-text bg-light border-end-0">Rp</span>
                                <input type="text" class="form-control <?= isset($errors['jumlah_bayar']) ? 'is-invalid' : '' ?> border-start-0"
                                       name="jumlah_bayar" id="jumlah_bayar"
                                       value="<?= old('jumlah_bayar', number_format($nominal_spp, 0, ',', '.')) ?>"
                                       required>
                            </div>
                            <?php if(isset($errors['jumlah_bayar'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['jumlah_bayar'] ?></div>
                            <?php endif; ?>
                            <div class="d-flex justify-content-between mt-1">
                                <small class="text-muted">
                                    <i class="bi bi-info-circle me-1"></i>Nominal sesuai SPP bulanan
                                </small>
                                <small class="text-muted">
                                    <span id="amountStatus"></span>
                                </small>
                            </div>
                        </div>

                        <!-- Payment Method -->
                        <div class="form-group mb-4">
                            <label class="form-label fw-semibold mb-2">Metode Pembayaran <span class="text-danger">*</span></label>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <button type="button" class="payment-method-card btn btn-outline-primary rounded-3 p-3 text-center w-100 <?= old('metode_pembayaran') == 'Tunai' ? 'active' : '' ?>"
                                            data-method="Tunai">
                                        <div class="mb-2">
                                            <div class="method-icon bg-primary bg-opacity-10 rounded-3 p-3 d-inline-block">
                                                <i class="bi bi-cash-coin text-primary fa-2x"></i>
                                            </div>
                                        </div>
                                        <h6 class="mb-2">Tunai</h6>
                                        <small class="text-muted d-block">Bayar langsung di TU</small>
                                        <input type="radio" name="metode_pembayaran" value="Tunai"
                                               <?= old('metode_pembayaran') == 'Tunai' ? 'checked' : '' ?> hidden>
                                    </button>
                                </div>
                                <div class="col-md-6">
                                    <button type="button" class="payment-method-card btn btn-outline-success rounded-3 p-3 text-center w-100 <?= old('metode_pembayaran') == 'Transfer' ? 'active' : '' ?>"
                                            data-method="Transfer">
                                        <div class="mb-2">
                                            <div class="method-icon bg-success bg-opacity-10 rounded-3 p-3 d-inline-block">
                                                <i class="bi bi-bank text-success fa-2x"></i>
                                            </div>
                                        </div>
                                        <h6 class="mb-2">Transfer Bank</h6>
                                        <small class="text-muted d-block">Transfer ke rekening sekolah</small>
                                        <input type="radio" name="metode_pembayaran" value="Transfer"
                                               <?= old('metode_pembayaran') == 'Transfer' ? 'checked' : '' ?> hidden>
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" id="metode_pembayaran_hidden" name="metode_pembayaran" value="<?= old('metode_pembayaran') ?>">
                            <?php if(isset($errors['metode_pembayaran'])): ?>
                                <div class="invalid-feedback d-block mt-2"><?= $errors['metode_pembayaran'] ?></div>
                            <?php endif; ?>

                            <!-- Selected Method Display -->
                            <div class="mt-3" id="selectedMethodDisplay" style="display: none;">
                                <div class="alert alert-info border-info border-opacity-25 bg-info bg-opacity-10 rounded-3 py-2">
                                    <div class="d-flex align-items-center">
                                        <i class="bi bi-check-circle text-info me-2"></i>
                                        <small class="mb-0">Metode pembayaran yang dipilih: <span id="selectedMethodText" class="fw-semibold text-primary"></span></small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Notes -->
                        <div class="form-group mb-4">
                            <label class="form-label fw-semibold mb-2">Catatan Tambahan (Opsional)</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light align-items-start border-end-0">
                                    <i class="bi bi-chat-left-text text-muted mt-2"></i>
                                </span>
                                <textarea class="form-control border-start-0" name="keterangan" id="keterangan" 
                                          rows="3" placeholder="Contoh: Pembayaran untuk <?= date('F Y') ?>, atau catatan khusus lainnya..."><?= old('keterangan') ?></textarea>
                            </div>
                            <small class="text-muted mt-1 d-block">
                                <i class="bi bi-info-circle me-1"></i>Tambahkan catatan jika diperlukan
                            </small>
                        </div>

                        <!-- Process Info -->
                        <div class="alert alert-info border-info border-opacity-25 bg-info bg-opacity-10 rounded-3 mb-4">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-list-check text-info fs-5"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="alert-heading fw-semibold mb-2">Proses Pembayaran</h6>
                                    <ol class="mb-0 ps-3">
                                        <li class="mb-2">Isi dan verifikasi data pembayaran</li>
                                        <li class="mb-2">Cetak bukti pembayaran</li>
                                        <li class="mb-2">Bayar sesuai metode yang dipilih</li>
                                        <li class="mb-2">Petugas akan melakukan verifikasi</li>
                                        <li>Status otomatis berubah menjadi "Lunas"</li>
                                    </ol>
                                </div>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex justify-content-between align-items-center border-top pt-4 mt-4">
                            <div>
                                
                            </div>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-warning rounded-3 px-4 py-2" onclick="printPaymentForm()">
                                    <i class="bi bi-printer me-2"></i>Cetak Form
                                </button>
                                <button type="submit" class="btn btn-primary rounded-3 px-4 py-2" id="submitBtn">
                                    <i class="bi bi-save me-2"></i>Simpan Pembayaran
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-header bg-primary text-white border-0 rounded-top-4 py-4 px-5">
                <div class="d-flex align-items-center w-100">
                    <div class="flex-grow-1">
                        <h5 class="modal-title mb-0 text-white">
                            <i class="bi bi-eye me-2"></i>Pratinjau Pembayaran
                        </h5>
                        <p class="mb-0 text-white opacity-85 small">Tinjau data sebelum menyimpan</p>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
            </div>
            <div class="modal-body p-5">
                <div id="previewContent">
                    <!-- Preview content will be loaded here -->
                </div>
            </div>
            <div class="modal-footer border-0 rounded-bottom-4 py-4 px-5 bg-light">
                <button type="button" class="btn btn-outline-secondary rounded-3 px-4" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i>Tutup
                </button>
                <button type="button" class="btn btn-primary rounded-3 px-4" onclick="document.getElementById('paymentForm').submit()">
                    <i class="bi bi-check-circle me-1"></i>Konfirmasi & Simpan
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Unpaid Months Modal -->
<div class="modal fade" id="unpaidMonthsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-header bg-warning text-white border-0 rounded-top-4 py-4 px-5">
                <div class="d-flex align-items-center w-100">
                    <div class="flex-grow-1">
                        <h5 class="modal-title mb-0 text-white">
                            <i class="bi bi-calendar-x me-2"></i>Bulan Tertunggak
                        </h5>
                        <p class="mb-0 text-white opacity-85 small">Daftar bulan yang belum dibayar</p>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
            </div>
            <div class="modal-body p-5">
                <div id="unpaidMonthsContent">
                    <!-- Unpaid months will be loaded here -->
                </div>
            </div>
            <div class="modal-footer border-0 rounded-bottom-4 py-4 px-5 bg-light">
                <button type="button" class="btn btn-outline-secondary rounded-3 px-4" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i>Tutup
                </button>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    .icon-header {
        transition: all 0.3s ease;
    }
    
    .icon-header:hover {
        transform: rotate(10deg) scale(1.1);
    }
    
    .info-card {
        transition: all 0.3s ease;
    }
    
    .info-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
    }
    
    .icon-box {
        width: 64px;
        height: 64px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .detail-row {
        transition: all 0.3s ease;
        padding: 8px 0;
        border-bottom: 1px solid #f0f0f0;
    }
    
    .detail-row:hover {
        background-color: rgba(78, 115, 223, 0.03);
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 8px;
    }
    
    .detail-icon {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .payment-method-card {
        cursor: pointer;
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }

    .payment-method-card:hover {
        border-color: rgba(78, 115, 223, 0.3);
        transform: translateY(-3px);
    }

    .payment-method-card.active {
        border-color: #4e73df !important;
        background-color: rgba(78, 115, 223, 0.05) !important;
    }
    
    .method-icon {
        width: 60px;
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .card {
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    
    .card:hover {
        border-color: rgba(78, 115, 223, 0.2);
        transform: translateY(-2px);
    }
    
    .form-control-lg {
        padding: 0.75rem 1rem;
        font-size: 1.1rem;
    }
    
    .form-select-lg {
        padding: 0.75rem 2.25rem 0.75rem 1rem;
        font-size: 1.1rem;
    }
    
    .border-2 {
        border-width: 2px !important;
    }
    
    .progress {
        border-radius: 10px;
        overflow: hidden;
    }
    
    .progress-bar {
        border-radius: 10px;
        transition: width 1s ease-in-out;
    }
    
    /* Responsive adjustments */
    @media (min-width: 1200px) {
        .container-fluid {
            max-width: 1400px;
        }
        
        .col-lg-5 {
            max-width: 420px;
        }
        
        .col-lg-7 {
            max-width: calc(100% - 420px);
        }
    }
    
    @media (max-width: 768px) {
        .payment-method-card {
            margin-bottom: 1rem;
        }
        
        .d-flex.gap-2 {
            gap: 0.5rem !important;
        }
        
        .btn {
            padding: 0.5rem 1rem !important;
        }
    }
    
    /* Animation for form elements */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .card {
        animation: fadeIn 0.5s ease-out;
    }
    
    /* Print styles for payment form */
    @media print {
        .no-print, .btn, .modal, .alert {
            display: none !important;
        }
        
        body {
            background: white !important;
        }
        
        .card {
            border: none !important;
            box-shadow: none !important;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize modals
    const previewModal = new bootstrap.Modal(document.getElementById('previewModal'));
    const unpaidModal = new bootstrap.Modal(document.getElementById('unpaidMonthsModal'));
    
    // Format currency input
    const amountInput = document.getElementById('jumlah_bayar');
    if (amountInput) {
        amountInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^\d]/g, '');
            
            // Format number with thousand separators
            if (value) {
                value = parseInt(value).toLocaleString('id-ID');
            }
            
            e.target.value = value;
            
            // Check if amount matches SPP nominal
            const cleanValue = parseInt(value.replace(/\./g, ''));
            const sppNominal = <?= $nominal_spp ?>;
            
            const statusElement = document.getElementById('amountStatus');
            if (cleanValue === sppNominal) {
                statusElement.innerHTML = '<span class="text-success"><i class="bi bi-check-circle me-1"></i>Sesuai nominal</span>';
            } else if (cleanValue > sppNominal) {
                statusElement.innerHTML = '<span class="text-warning"><i class="bi bi-exclamation-triangle me-1"></i>Lebih dari nominal</span>';
            } else if (cleanValue > 0 && cleanValue < sppNominal) {
                statusElement.innerHTML = '<span class="text-danger"><i class="bi bi-x-circle me-1"></i>Kurang dari nominal</span>';
            } else {
                statusElement.innerHTML = '';
            }
        });
        
        // Trigger initial validation
        amountInput.dispatchEvent(new Event('input'));
    }
    
    // Payment method selection
    const methodCards = document.querySelectorAll('.payment-method-card');
    const methodHidden = document.getElementById('metode_pembayaran_hidden');
    
    methodCards.forEach(card => {
        card.addEventListener('click', function() {
            // Remove selected class from all cards
            methodCards.forEach(c => {
                c.classList.remove('selected');
                const radio = c.querySelector('input[type="radio"]');
                if (radio) radio.checked = false;
            });

            // Add selected class to clicked card
            this.classList.add('selected');
            const method = this.getAttribute('data-method');
            const radio = this.querySelector('input[type="radio"]');

            if (radio) {
                radio.checked = true;
            }

            if (methodHidden) {
                methodHidden.value = method;
            }

            // Update selected method display
            updateSelectedMethodDisplay(method);
        });
    });

    // Function to update selected method display
    function updateSelectedMethodDisplay(method) {
        const displayDiv = document.getElementById('selectedMethodDisplay');
        const displayText = document.getElementById('selectedMethodText');

        if (displayDiv && displayText && method) {
            displayText.textContent = method;
            displayDiv.style.display = 'block';
        } else if (displayDiv) {
            displayDiv.style.display = 'none';
        }
    }
    
    // Preview button functionality
    const previewBtn = document.getElementById('previewBtn');
    if (previewBtn) {
        previewBtn.addEventListener('click', function() {
            if (!validateForm()) {
                return;
            }
            
            generatePreview();
            previewModal.show();
        });
    }
    
    // Form validation
    function validateForm() {
        const bulanSelect = document.getElementById('bulanSelect');
        const amountValue = amountInput.value.replace(/\./g, '');
        const methodValue = methodHidden ? methodHidden.value : '';
        
        let valid = true;
        
        // Reset previous error states
        [bulanSelect, amountInput].forEach(input => {
            input.classList.remove('is-invalid');
            const errorDiv = input.parentElement.querySelector('.invalid-feedback');
            if (errorDiv) {
                errorDiv.remove();
            }
        });
        
        // Validate bulan
        if (!bulanSelect.value) {
            showError(bulanSelect, 'Pilih bulan pembayaran');
            valid = false;
        }
        
        // Validate amount
        if (!amountValue) {
            showError(amountInput, 'Masukkan jumlah pembayaran');
            valid = false;
        } else if (parseInt(amountValue) < 1000) {
            showError(amountInput, 'Jumlah pembayaran minimal Rp 1.000');
            valid = false;
        }
        
        // Validate payment method
        if (!methodValue) {
            const methodError = document.createElement('div');
            methodError.className = 'invalid-feedback d-block mt-2';
            methodError.textContent = 'Pilih metode pembayaran';
            document.querySelector('.payment-method-card').parentElement.parentElement.appendChild(methodError);
            valid = false;
        }
        
        return valid;
    }
    
    function showError(input, message) {
        input.classList.add('is-invalid');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback d-block mt-1';
        errorDiv.textContent = message;
        input.parentElement.appendChild(errorDiv);
    }
    
    // Generate preview content
    function generatePreview() {
        const bulan = document.getElementById('bulanSelect').value;
        const tahun = document.querySelector('input[name="tahun"]').value;
        const jumlah = document.getElementById('jumlah_bayar').value;
        const metode = document.querySelector('input[name="metode_pembayaran"]:checked')?.value || '';
        const keterangan = document.getElementById('keterangan').value;
        
        const previewContent = `
            <div class="preview-container">
                <div class="text-center mb-4">
                    <h4 class="fw-bold text-primary mb-3">PRATINJAU PEMBAYARAN SPP</h4>
                    <p class="text-muted mb-4">Pastikan data berikut sudah benar sebelum menyimpan</p>
                </div>
                
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="preview-card border rounded-3 p-4 h-100">
                            <h6 class="fw-semibold mb-3 text-primary">Informasi Siswa</h6>
                            <table class="table table-sm">
                                <tr>
                                    <td class="border-0 p-1"><small>Nama</small></td>
                                    <td class="border-0 p-1"><strong><?= session()->get('nama_lengkap') ?></strong></td>
                                </tr>
                                <tr>
                                    <td class="border-0 p-1"><small>NISN</small></td>
                                    <td class="border-0 p-1"><?= session()->get('nisn') ?></td>
                                </tr>
                                <tr>
                                    <td class="border-0 p-1"><small>Kelas</small></td>
                                    <td class="border-0 p-1"><?= session()->get('nama_kelas') ?></td>
                                </tr>
                                <tr>
                                    <td class="border-0 p-1"><small>Bulan/Tahun</small></td>
                                    <td class="border-0 p-1"><strong>${bulan} ${tahun}</strong></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="preview-card border rounded-3 p-4 h-100">
                            <h6 class="fw-semibold mb-3 text-primary">Detail Pembayaran</h6>
                            <table class="table table-sm">
                                <tr>
                                    <td class="border-0 p-1"><small>Jumlah Bayar</small></td>
                                    <td class="border-0 p-1"><strong class="text-success">Rp ${jumlah}</strong></td>
                                </tr>
                                <tr>
                                    <td class="border-0 p-1"><small>Metode</small></td>
                                    <td class="border-0 p-1"><span class="badge bg-primary">${metode}</span></td>
                                </tr>
                                ${keterangan ? `
                                <tr>
                                    <td class="border-0 p-1"><small>Catatan</small></td>
                                    <td class="border-0 p-1"><small>${keterangan}</small></td>
                                </tr>
                                ` : ''}
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="alert alert-warning border-warning border-opacity-25 bg-warning bg-opacity-10 rounded-3 mt-4">
                    <div class="d-flex">
                        <div class="flex-shrink-0">
                            <i class="bi bi-exclamation-triangle text-warning"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="alert-heading fw-semibold mb-2">Konfirmasi Data</h6>
                            <p class="mb-0 small">Setelah menyimpan, data pembayaran tidak dapat diubah. Pastikan semua informasi sudah benar.</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('previewContent').innerHTML = previewContent;
    }
    
    // Print payment form
    window.printPaymentForm = function() {
        if (!validateForm()) {
            return;
        }
        
        const printWindow = window.open('', '_blank');
        const bulan = document.getElementById('bulanSelect').value;
        const tahun = document.querySelector('input[name="tahun"]').value;
        const jumlah = document.getElementById('jumlah_bayar').value;
        const metode = document.querySelector('input[name="metode_pembayaran"]:checked')?.value || '';
        const keterangan = document.getElementById('keterangan').value;
        const uniqueId = 'SPP-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Form Pembayaran SPP - ${bulan} ${tahun}</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                <style>
                    @media print {
                        @page { size: A4; margin: 20mm; }
                        body { font-size: 12pt; line-height: 1.4; }
                        .no-print { display: none !important; }
                    }
                    .receipt-header {
                        border-bottom: 3px double #000;
                        padding-bottom: 20px;
                        margin-bottom: 30px;
                        text-align: center;
                    }
                    .info-table { margin-bottom: 30px; }
                    .info-table td { padding: 8px 0; }
                    .signature-section { margin-top: 80px; }
                    .signature-line { border-top: 1px solid #000; padding-top: 5px; }
                </style>
            </head>
            <body onload="window.print(); setTimeout(() => window.close(), 1000);">
                <div class="container-fluid">
                    <div class="receipt-header">
                        <h2 class="mb-2">FORM PEMBAYARAN SPP</h2>
                        <h5 class="text-muted mb-3">Sistem Pembayaran Sekolah</h5>
                        <p class="mb-0">${bulan} ${tahun}</p>
                    </div>
                    
                    <div class="info-table">
                        <h5 class="mb-3">Informasi Siswa</h5>
                        <table width="100%">
                            <tr>
                                <td width="30%"><strong>Nama Siswa</strong></td>
                                <td width="5%">:</td>
                                <td><?= session()->get('nama_lengkap') ?></td>
                            </tr>
                            <tr>
                                <td><strong>NISN</strong></td>
                                <td>:</td>
                                <td><?= session()->get('nisn') ?></td>
                            </tr>
                            <tr>
                                <td><strong>Kelas</strong></td>
                                <td>:</td>
                                <td><?= session()->get('nama_kelas') ?></td>
                            </tr>
                            <tr>
                                <td><strong>Bulan/Tahun</strong></td>
                                <td>:</td>
                                <td><strong>${bulan} ${tahun}</strong></td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="info-table">
                        <h5 class="mb-3">Detail Pembayaran</h5>
                        <table width="100%">
                            <tr>
                                <td width="30%"><strong>Jumlah Bayar</strong></td>
                                <td width="5%">:</td>
                                <td><strong style="font-size: 1.2em;">Rp ${jumlah}</strong></td>
                            </tr>
                            <tr>
                                <td><strong>Metode Pembayaran</strong></td>
                                <td>:</td>
                                <td>${metode}</td>
                            </tr>
                            ${keterangan ? `
                            <tr>
                                <td><strong>Catatan</strong></td>
                                <td>:</td>
                                <td>${keterangan}</td>
                            </tr>
                            ` : ''}
                            <tr>
                                <td><strong>Kode Referensi</strong></td>
                                <td>:</td>
                                <td><small>${uniqueId}</small></td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="signature-section">
                        <div class="row">
                            <div class="col-6 text-center">
                                <p>Petugas Tata Usaha</p>
                                <div class="signature-line" style="width: 200px; margin: 0 auto;">
                                    &nbsp;
                                </div>
                            </div>
                            <div class="col-6 text-center">
                                <p>Orang Tua/Wali</p>
                                <div class="signature-line" style="width: 200px; margin: 0 auto;">
                                    &nbsp;
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-5 pt-4 border-top">
                        <small class="text-muted">
                            Dicetak pada: ${new Date().toLocaleDateString('id-ID', {
                                weekday: 'long',
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                            })}
                        </small>
                    </div>
                </div>
            </body>
            </html>
        `);
        printWindow.document.close();
    };
    
    // Show unpaid months
    window.showUnpaidMonths = function() {
        <?php
        $paid_months = [];
        $current_year = date('Y');
        
        if (!empty($pembayaran)) {
            foreach($pembayaran as $payment) {
                $tahun_payment = is_array($payment) ? ($payment['tahun'] ?? '') : ($payment->tahun ?? '');
                $bulan_payment = is_array($payment) ? ($payment['bulan'] ?? '') : ($payment->bulan ?? '');
                if ($tahun_payment == $current_year) {
                    $paid_months[] = $bulan_payment;
                }
            }
        }
        
        $bulan_list = [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        
        $unpaid_months = array_diff($bulan_list, $paid_months);
        ?>
        
        let content = '<div class="unpaid-months-container">';
        
        if (<?= count($unpaid_months) ?> === 0) {
            content += `
                <div class="text-center py-4">
                    <div class="mb-3">
                        <i class="bi bi-check-circle text-success fa-4x"></i>
                    </div>
                    <h5 class="text-success mb-3">Semua Bulan Telah Dibayar!</h5>
                    <p class="text-muted">Selamat! Anda telah melunasi pembayaran SPP tahun ini.</p>
                </div>
            `;
        } else {
            content += `
                <div class="mb-4">
                    <p class="text-muted mb-3">Berikut adalah daftar bulan yang belum dibayar:</p>
                    <div class="row g-2">
            `;
            
            <?php $current_month_index = date('n') - 1; ?>
            <?php foreach($unpaid_months as $index => $bulan): ?>
                <?php $is_current = $index == $current_month_index; ?>
                <?php $is_past = $index < $current_month_index; ?>
                content += `
                    <div class="col-md-6">
                        <div class="unpaid-month-card border rounded-3 p-3 mb-2 ${<?= $is_current ? 'true' : 'false' ?> ? 'bg-info bg-opacity-10' : ''}">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1 fw-semibold">${<?= json_encode($bulan) ?>}</h6>
                                    <small class="text-muted">${<?= json_encode(date('Y')) ?>}</small>
                                </div>
                                <div>
                                    ${<?= $is_current ? 'true' : 'false' ?> ? 
                                        '<span class="badge bg-info">Bulan Ini</span>' : 
                                        <?= $is_past ? 'true' : 'false' ?> ? 
                                            '<span class="badge bg-warning">Terlambat</span>' : 
                                            ''}
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mt-2">
                                <small class="text-muted">Rp ${<?= number_format($nominal_spp, 0, ',', '.') ?>}</small>
                                <button type="button" class="btn btn-sm btn-primary" 
                                        onclick="selectMonth('${<?= json_encode($bulan) ?>}')">
                                    Bayar Sekarang
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            <?php endforeach; ?>
            
            content += `
                    </div>
                </div>
                <div class="alert alert-warning">
                    <h6><i class="bi bi-exclamation-triangle me-2"></i>Informasi</h6>
                    <p class="mb-0 small">
                        Bulan yang terlambat akan dikenakan denda sesuai ketentuan sekolah.
                        Segera lakukan pembayaran untuk menghindari denda.
                    </p>
                </div>
            `;
        }
        
        content += '</div>';
        document.getElementById('unpaidMonthsContent').innerHTML = content;
        unpaidModal.show();
    };
    
    // Select month from unpaid list
    window.selectMonth = function(month) {
        const bulanSelect = document.getElementById('bulanSelect');
        const options = bulanSelect.querySelectorAll('option');
        
        options.forEach(option => {
            if (option.value === month) {
                option.selected = true;
                bulanSelect.dispatchEvent(new Event('change'));
            }
        });
        
        bootstrap.Modal.getInstance(document.getElementById('unpaidMonthsModal')).hide();
        
        // Scroll to form
        document.getElementById('paymentForm').scrollIntoView({ behavior: 'smooth' });
    };
    
    // Form submission handling
    const submitBtn = document.getElementById('submitBtn');
    if (submitBtn) {
        submitBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (!validateForm()) {
                return;
            }
            
            // Show confirmation dialog
            if (confirm('Apakah Anda yakin ingin menyimpan data pembayaran ini?')) {
                const originalText = this.innerHTML;
                this.innerHTML = `
                    <div class="spinner-border spinner-border-sm me-2" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    Menyimpan...
                `;
                this.disabled = true;
                
                // Submit form
                document.getElementById('paymentForm').submit();
                
                // Re-enable after 5 seconds if still there
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                }, 5000);
            }
        });
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl+P to print
        if (e.ctrlKey && e.key === 'p') {
            e.preventDefault();
            printPaymentForm();
        }
        
        // Ctrl+Enter to submit
        if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            document.getElementById('paymentForm').dispatchEvent(new Event('submit'));
        }
    });
});
</script>
<?= $this->endSection() ?>