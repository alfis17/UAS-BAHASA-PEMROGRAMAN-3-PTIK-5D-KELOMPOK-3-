<?= $this->extend('layout/main_siswa') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4 px-lg-5 py-4">
    <!-- Page Header -->
    <div class="row mb-4 align-items-center">
        <div class="col-lg-8">
            <div class="d-flex align-items-center">
                <div class="icon-header bg-warning bg-opacity-10 rounded-3 p-3 me-3">
                    <i class="bi bi-shield-lock text-warning fa-2x"></i>
                </div>
                <div>
                    <h1 class="h2 fw-bold text-dark mb-2">Keamanan Akun</h1>
                    <p class="text-muted mb-0">Perbarui kata sandi untuk menjaga keamanan akun Anda</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 text-lg-end">
            <a href="<?= base_url('siswa/dashboard_siswa') ?>" class="btn btn-outline-secondary rounded-3 px-4 py-2">
                <i class="bi bi-arrow-left me-2"></i>Kembali ke Dashboard
            </a>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-10">
            <!-- Security Status Card -->
            <div class="card border-0 rounded-4 shadow-sm mb-4">
                <div class="card-header bg-white border-bottom py-4">
                    <h5 class="mb-0 fw-bold text-dark">
                        <i class="bi bi-shield-check me-2"></i>Status Keamanan Akun
                    </h5>
                </div>
                <div class="card-body p-4">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="security-item d-flex align-items-center">
                                <div class="security-icon bg-success bg-opacity-10 rounded-3 p-3 me-3">
                                    <i class="bi bi-person-check text-success fa-2x"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="fw-semibold mb-1">Verifikasi Identitas</h6>
                                    <p class="text-muted mb-0 small">Akun Anda telah diverifikasi</p>
                                </div>
                                <div class="flex-shrink-0">
                                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2 rounded-pill">
                                        <i class="bi bi-check-circle me-1"></i>Aktif
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="security-item d-flex align-items-center">
                                <div class="security-icon bg-warning bg-opacity-10 rounded-3 p-3 me-3">
                                    <i class="bi bi-clock-history text-warning fa-2x"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="fw-semibold mb-1">Perubahan Terakhir</h6>
                                    <p class="text-muted mb-0 small">
                                        <?php
                                        $last_password_change = session()->get('last_password_change') ?? '-';
                                        if ($last_password_change && $last_password_change != '-') {
                                            $date = new DateTime($last_password_change);
                                            $now = new DateTime();
                                            $interval = $now->diff($date);
                                            
                                            if ($interval->days == 0) {
                                                echo 'Hari ini';
                                            } elseif ($interval->days == 1) {
                                                echo '1 hari yang lalu';
                                            } elseif ($interval->days < 30) {
                                                echo $interval->days . ' hari yang lalu';
                                            } elseif ($interval->days < 365) {
                                                echo floor($interval->days / 30) . ' bulan yang lalu';
                                            } else {
                                                echo floor($interval->days / 365) . ' tahun yang lalu';
                                            }
                                        } else {
                                            echo 'Belum pernah diganti';
                                        }
                                        ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Password Change Form -->
            <div class="card border-0 rounded-4 shadow-sm">
                <div class="card-header bg-white border-bottom py-4">
                    <h5 class="mb-0 fw-bold text-dark">
                        <i class="bi bi-key me-2"></i>Ganti Kata Sandi
                    </h5>
                    <p class="text-muted mb-0 small">Isi form di bawah untuk mengubah kata sandi Anda</p>
                </div>
                
                <div class="card-body p-4">
                    <!-- Flash Messages -->
                    <?php if(session()->getFlashdata('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show border-0 rounded-3 shadow-sm mb-4" role="alert">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-check-circle-fill fs-4"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="alert-heading fw-bold mb-1">Berhasil!</h6>
                                    <p class="mb-0"><?= session()->getFlashdata('success') ?></p>
                                </div>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if(session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show border-0 rounded-3 shadow-sm mb-4" role="alert">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-exclamation-triangle-fill fs-4"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="alert-heading fw-bold mb-1">Perhatian!</h6>
                                    <p class="mb-0"><?= session()->getFlashdata('error') ?></p>
                                </div>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>

                    <form action="<?= base_url('siswa/change-password/update') ?>" method="POST" id="passwordForm">
                        <?= csrf_field() ?>
                        
                        <!-- Current Password -->
                        <div class="form-group mb-4">
                            <label class="form-label fw-semibold mb-2">Kata Sandi Saat Ini <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0">
                                    <i class="bi bi-lock text-muted"></i>
                                </span>
                                <input type="password" class="form-control <?= isset($errors['current_password']) ? 'is-invalid' : '' ?> border-start-0" 
                                       name="current_password" id="current_password" required
                                       placeholder="Masukkan kata sandi saat ini">
                                <button class="btn btn-outline-secondary border-start-0" type="button" id="toggleCurrentPassword">
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                            <?php if(isset($errors['current_password'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['current_password'] ?></div>
                            <?php endif; ?>
                            <small class="text-muted mt-1 d-block">
                                <i class="bi bi-info-circle me-1"></i>Masukkan kata sandi yang sedang digunakan
                            </small>
                        </div>

                        <!-- New Password -->
                        <div class="form-group mb-4">
                            <label class="form-label fw-semibold mb-2">Kata Sandi Baru <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0">
                                    <i class="bi bi-lock-fill text-muted"></i>
                                </span>
                                <input type="password" class="form-control <?= isset($errors['new_password']) ? 'is-invalid' : '' ?> border-start-0" 
                                       name="new_password" id="new_password" required
                                       placeholder="Minimal 6 karakter">
                                <button class="btn btn-outline-secondary border-start-0" type="button" id="toggleNewPassword">
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                            <?php if(isset($errors['new_password'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['new_password'] ?></div>
                            <?php endif; ?>
                            
                            <!-- Password Strength Meter -->
                            <div class="password-strength mt-2">
                                <div class="d-flex justify-content-between mb-1">
                                    <small class="text-muted">Kekuatan kata sandi:</small>
                                    <small class="text-muted" id="passwordStrengthText">Lemah</small>
                                </div>
                                <div class="progress" style="height: 6px;">
                                    <div class="progress-bar bg-danger" id="passwordStrengthBar" role="progressbar" 
                                         style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <div class="password-requirements mt-3">
                                    <small class="text-muted d-block mb-1">Syarat kata sandi:</small>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <small class="d-flex align-items-center mb-2">
                                                <span class="requirement-dot me-2" id="reqLength"></span>
                                                Minimal 6 karakter
                                            </small>
                                            <small class="d-flex align-items-center mb-2">
                                                <span class="requirement-dot me-2" id="reqLowercase"></span>
                                                Huruf kecil
                                            </small>
                                        </div>
                                        <div class="col-md-6">
                                            <small class="d-flex align-items-center mb-2">
                                                <span class="requirement-dot me-2" id="reqUppercase"></span>
                                                Huruf besar
                                            </small>
                                            <small class="d-flex align-items-center mb-2">
                                                <span class="requirement-dot me-2" id="reqNumber"></span>
                                                Angka
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Confirm New Password -->
                        <div class="form-group mb-4">
                            <label class="form-label fw-semibold mb-2">Konfirmasi Kata Sandi Baru <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0">
                                    <i class="bi bi-lock-fill text-muted"></i>
                                </span>
                                <input type="password" class="form-control <?= isset($errors['confirm_password']) ? 'is-invalid' : '' ?> border-start-0" 
                                       name="confirm_password" id="confirm_password" required
                                       placeholder="Ulangi kata sandi baru">
                                <button class="btn btn-outline-secondary border-start-0" type="button" id="toggleConfirmPassword">
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                            <?php if(isset($errors['confirm_password'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['confirm_password'] ?></div>
                            <?php endif; ?>
                            <div id="passwordMatch" class="mt-2">
                                <!-- Password match indicator will appear here -->
                            </div>
                        </div>

                        <!-- Security Tips -->
                        <div class="alert alert-info border-info border-opacity-25 bg-info bg-opacity-10 rounded-3 mb-4">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-lightbulb text-info fs-5"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="alert-heading fw-semibold mb-2">Tips Keamanan Kata Sandi</h6>
                                    <ul class="mb-0 small ps-3">
                                        <li class="mb-2">Gunakan kombinasi huruf besar, huruf kecil, angka, dan simbol</li>
                                        <li class="mb-2">Minimal 8 karakter untuk keamanan optimal</li>
                                        <li class="mb-2">Hindari menggunakan informasi pribadi seperti nama atau tanggal lahir</li>
                                        <li class="mb-2">Gunakan kata sandi yang berbeda untuk setiap akun</li>
                                        <li>Perbarui kata sandi secara berkala setiap 3-6 bulan</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex justify-content-between align-items-center border-top pt-4 mt-4">
                            <div>
                                <button type="button" class="btn btn-outline-secondary rounded-3 px-4 py-2" onclick="generatePassword()">
                                    <i class="bi bi-dice-5 me-2"></i>Generate Password
                                </button>
                            </div>
                            <div class="d-flex gap-2">
                                <button type="reset" class="btn btn-outline-secondary rounded-3 px-4 py-2">
                                    <i class="bi bi-arrow-clockwise me-2"></i>Reset Form
                                </button>
                                <button type="submit" class="btn btn-primary rounded-3 px-4 py-2" id="submitBtn">
                                    <i class="bi bi-save me-2"></i>Simpan Perubahan
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="card border-0 rounded-4 shadow-sm mt-4">
                <div class="card-header bg-white border-bottom py-4">
                    <h5 class="mb-0 fw-bold text-dark">
                        <i class="bi bi-clock-history me-2"></i>Aktivitas Keamanan Terbaru
                    </h5>
                </div>
                <div class="card-body p-4">
                    <div class="activity-list">
                        <div class="activity-item d-flex align-items-center mb-3 pb-3 border-bottom">
                            <div class="activity-icon bg-primary bg-opacity-10 rounded-3 p-2 me-3">
                                <i class="bi bi-person-check text-primary"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="mb-1 fw-semibold">Login Berhasil</h6>
                                <p class="text-muted mb-0 small">
                                    <?= date('d F Y H:i') ?> • 
                                    <span class="text-success">IP: <?= $_SERVER['REMOTE_ADDR'] ?? 'Tidak diketahui' ?></span>
                                </p>
                            </div>
                        </div>
                        
                        <div class="activity-item d-flex align-items-center">
                            <div class="activity-icon bg-warning bg-opacity-10 rounded-3 p-2 me-3">
                                <i class="bi bi-key text-warning"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="mb-1 fw-semibold">Peringatan Keamanan</h6>
                                <p class="text-muted mb-0 small">
                                    Segera perbarui kata sandi jika merasa ada aktivitas mencurigakan
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Generated Password Modal -->
<div class="modal fade" id="generatedPasswordModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-header bg-primary text-white border-0 rounded-top-4 py-4 px-5">
                <div class="d-flex align-items-center w-100">
                    <div class="flex-grow-1">
                        <h5 class="modal-title mb-0 text-white">
                            <i class="bi bi-dice-5 me-2"></i>Password Tergenerate
                        </h5>
                        <p class="mb-0 text-white opacity-85 small">Salin password yang aman ke clipboard</p>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
            </div>
            <div class="modal-body p-5">
                <div class="text-center mb-4">
                    <div class="password-display bg-light rounded-3 p-4 mb-3">
                        <code id="generatedPassword" class="fs-4 fw-bold text-primary">********</code>
                    </div>
                    <p class="text-muted small mb-0">
                        Password ini memenuhi semua kriteria keamanan
                    </p>
                </div>
                
                <div class="password-strength-info mb-4">
                    <h6 class="fw-semibold mb-3">Detail Keamanan:</h6>
                    <div class="row">
                        <div class="col-6">
                            <small class="d-flex align-items-center mb-2 text-success">
                                <i class="bi bi-check-circle me-2"></i>
                                12 karakter
                            </small>
                            <small class="d-flex align-items-center mb-2 text-success">
                                <i class="bi bi-check-circle me-2"></i>
                                Huruf besar & kecil
                            </small>
                        </div>
                        <div class="col-6">
                            <small class="d-flex align-items-center mb-2 text-success">
                                <i class="bi bi-check-circle me-2"></i>
                                Angka & simbol
                            </small>
                            <small class="d-flex align-items-center mb-2 text-success">
                                <i class="bi bi-check-circle me-2"></i>
                                Tidak ada kata umum
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 rounded-bottom-4 py-4 px-5 bg-light">
                <button type="button" class="btn btn-outline-secondary rounded-3 px-4" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i>Batal
                </button>
                <button type="button" class="btn btn-primary rounded-3 px-4" onclick="useGeneratedPassword()">
                    <i class="bi bi-clipboard-check me-1"></i>Gunakan Password Ini
                </button>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    .icon-header {
        transition: all 0.3s ease;
    }
    
    .icon-header:hover {
        transform: rotate(10deg) scale(1.1);
    }
    
    .security-item {
        padding: 15px;
        border-radius: 12px;
        transition: all 0.3s ease;
        background: linear-gradient(135deg, rgba(248, 249, 250, 0.5), rgba(233, 236, 239, 0.3));
        border: 1px solid transparent;
    }
    
    .security-item:hover {
        border-color: rgba(78, 115, 223, 0.2);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    }
    
    .security-icon {
        width: 56px;
        height: 56px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .activity-item {
        transition: all 0.3s ease;
        border-radius: 8px;
        padding: 8px 12px;
    }
    
    .activity-item:hover {
        background-color: rgba(78, 115, 223, 0.05);
        transform: translateX(5px);
    }
    
    .activity-icon {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .password-strength .progress {
        border-radius: 3px;
        overflow: hidden;
    }
    
    .requirement-dot {
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: #dee2e6;
    }
    
    .requirement-dot.valid {
        background-color: #28a745;
    }
    
    .password-display {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        border: 2px dashed #dee2e6;
        transition: all 0.3s ease;
    }
    
    .password-display:hover {
        border-color: #4e73df;
        background: linear-gradient(135deg, #fff 0%, #f8f9fa 100%);
    }
    
    .card {
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    
    .card:hover {
        border-color: rgba(78, 115, 223, 0.2);
        transform: translateY(-2px);
    }
    
    .form-control:focus {
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.25);
    }
    
    .input-group .btn-outline-secondary {
        border-color: #dee2e6;
        border-left: none;
    }
    
    .input-group .btn-outline-secondary:hover {
        background-color: #f8f9fa;
        border-color: #dee2e6;
    }
    
    /* Responsive adjustments */
    @media (min-width: 1200px) {
        .container-fluid {
            max-width: 1200px;
        }
        
        .col-xl-8 {
            max-width: 900px;
        }
    }
    
    @media (max-width: 768px) {
        .security-item {
            flex-direction: column;
            text-align: center;
            gap: 1rem;
        }
        
        .security-icon {
            margin: 0 auto;
        }
        
        .d-flex.gap-2 {
            gap: 0.5rem !important;
        }
        
        .btn {
            padding: 0.5rem 1rem !important;
        }
    }
    
    /* Animation for form elements */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .card {
        animation: fadeIn 0.5s ease-out;
    }
    
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }
    
    .password-display {
        animation: pulse 2s infinite;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize modals
    const passwordModal = new bootstrap.Modal(document.getElementById('generatedPasswordModal'));
    
    // Password visibility toggle
    const toggleCurrentPassword = document.getElementById('toggleCurrentPassword');
    const toggleNewPassword = document.getElementById('toggleNewPassword');
    const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
    
    toggleCurrentPassword?.addEventListener('click', function() {
        togglePasswordVisibility('current_password', this);
    });
    
    toggleNewPassword?.addEventListener('click', function() {
        togglePasswordVisibility('new_password', this);
    });
    
    toggleConfirmPassword?.addEventListener('click', function() {
        togglePasswordVisibility('confirm_password', this);
    });
    
    function togglePasswordVisibility(fieldId, button) {
        const field = document.getElementById(fieldId);
        if (field.type === 'password') {
            field.type = 'text';
            button.innerHTML = '<i class="bi bi-eye-slash"></i>';
            button.classList.add('active');
        } else {
            field.type = 'password';
            button.innerHTML = '<i class="bi bi-eye"></i>';
            button.classList.remove('active');
        }
    }
    
    // Password strength checker
    const newPasswordInput = document.getElementById('new_password');
    const strengthBar = document.getElementById('passwordStrengthBar');
    const strengthText = document.getElementById('passwordStrengthText');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const passwordMatchDiv = document.getElementById('passwordMatch');
    
    if (newPasswordInput) {
        newPasswordInput.addEventListener('input', function() {
            const password = this.value;
            const strength = calculatePasswordStrength(password);
            
            // Update progress bar
            strengthBar.style.width = strength.percentage + '%';
            
            // Update color based on strength
            if (strength.score <= 2) {
                strengthBar.className = 'progress-bar bg-danger';
                strengthText.textContent = 'Lemah';
            } else if (strength.score === 3) {
                strengthBar.className = 'progress-bar bg-warning';
                strengthText.textContent = 'Cukup';
            } else if (strength.score === 4) {
                strengthBar.className = 'progress-bar bg-info';
                strengthText.textContent = 'Baik';
            } else {
                strengthBar.className = 'progress-bar bg-success';
                strengthText.textContent = 'Sangat Baik';
            }
            
            // Update requirement dots
            updateRequirementDots(strength);
            
            // Check password match
            checkPasswordMatch();
        });
    }
    
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', checkPasswordMatch);
    }
    
    function calculatePasswordStrength(password) {
        let score = 0;
        const requirements = {
            length: password.length >= 6,
            lowercase: /[a-z]/.test(password),
            uppercase: /[A-Z]/.test(password),
            number: /[0-9]/.test(password),
            special: /[^A-Za-z0-9]/.test(password)
        };
        
        // Calculate score
        if (requirements.length) score++;
        if (requirements.lowercase) score++;
        if (requirements.uppercase) score++;
        if (requirements.number) score++;
        if (requirements.special) score++;
        
        // Adjust for length bonus
        if (password.length >= 12) score++;
        if (password.length >= 16) score++;
        
        // Cap score at 6 for percentage calculation
        const maxScore = 6;
        const percentage = Math.min((score / maxScore) * 100, 100);
        
        return {
            score: Math.min(score, 5), // For display purposes
            percentage: percentage,
            requirements: requirements
        };
    }
    
    function updateRequirementDots(strength) {
        const requirements = strength.requirements;
        const dots = {
            length: document.getElementById('reqLength'),
            lowercase: document.getElementById('reqLowercase'),
            uppercase: document.getElementById('reqUppercase'),
            number: document.getElementById('reqNumber')
        };
        
        if (dots.length) dots.length.className = `requirement-dot me-2 ${requirements.length ? 'valid' : ''}`;
        if (dots.lowercase) dots.lowercase.className = `requirement-dot me-2 ${requirements.lowercase ? 'valid' : ''}`;
        if (dots.uppercase) dots.uppercase.className = `requirement-dot me-2 ${requirements.uppercase ? 'valid' : ''}`;
        if (dots.number) dots.number.className = `requirement-dot me-2 ${requirements.number ? 'valid' : ''}`;
    }
    
    function checkPasswordMatch() {
        const password = newPasswordInput?.value || '';
        const confirm = confirmPasswordInput?.value || '';
        
        if (!passwordMatchDiv) return;
        
        if (confirm === '') {
            passwordMatchDiv.innerHTML = '';
            return;
        }
        
        if (password === confirm) {
            passwordMatchDiv.innerHTML = `
                <small class="text-success">
                    <i class="bi bi-check-circle me-1"></i>
                    Kata sandi cocok
                </small>
            `;
        } else {
            passwordMatchDiv.innerHTML = `
                <small class="text-danger">
                    <i class="bi bi-x-circle me-1"></i>
                    Kata sandi tidak cocok
                </small>
            `;
        }
    }
    
    // Generate random password
    window.generatePassword = function() {
        const charset = {
            lowercase: 'abcdefghijklmnopqrstuvwxyz',
            uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
            numbers: '0123456789',
            symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?'
        };
        
        // Create a balanced password
        let password = '';
        
        // Ensure at least one of each type
        password += charset.lowercase.charAt(Math.floor(Math.random() * charset.lowercase.length));
        password += charset.uppercase.charAt(Math.floor(Math.random() * charset.uppercase.length));
        password += charset.numbers.charAt(Math.floor(Math.random() * charset.numbers.length));
        password += charset.symbols.charAt(Math.floor(Math.random() * charset.symbols.length));
        
        // Fill remaining characters randomly
        const allChars = charset.lowercase + charset.uppercase + charset.numbers + charset.symbols;
        for (let i = password.length; i < 12; i++) {
            password += allChars.charAt(Math.floor(Math.random() * allChars.length));
        }
        
        // Shuffle the password
        password = password.split('').sort(() => Math.random() - 0.5).join('');
        
        // Show in modal
        document.getElementById('generatedPassword').textContent = password;
        passwordModal.show();
    };
    
    window.useGeneratedPassword = function() {
        const generatedPassword = document.getElementById('generatedPassword').textContent;
        
        // Set the generated password in the form
        newPasswordInput.value = generatedPassword;
        confirmPasswordInput.value = generatedPassword;
        
        // Trigger events to update UI
        newPasswordInput.dispatchEvent(new Event('input'));
        confirmPasswordInput.dispatchEvent(new Event('input'));
        
        // Close modal
        passwordModal.hide();
        
        // Show success message
        showToast('Password telah disalin ke form!', 'success');
    };
    
    // Form validation
    const form = document.getElementById('passwordForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const currentPassword = document.getElementById('current_password').value;
            const newPassword = newPasswordInput?.value || '';
            const confirmPassword = confirmPasswordInput?.value || '';
            
            let valid = true;
            
            // Reset previous error states
            const inputs = [document.getElementById('current_password'), newPasswordInput, confirmPasswordInput];
            inputs.forEach(input => {
                if (input) {
                    input.classList.remove('is-invalid');
                    const errorDiv = input.parentElement.parentElement.querySelector('.invalid-feedback');
                    if (errorDiv) {
                        errorDiv.remove();
                    }
                }
            });
            
            // Validate current password
            if (!currentPassword) {
                showError(document.getElementById('current_password'), 'Masukkan kata sandi saat ini');
                valid = false;
            }
            
            // Validate new password
            if (!newPassword) {
                showError(newPasswordInput, 'Masukkan kata sandi baru');
                valid = false;
            } else if (newPassword.length < 6) {
                showError(newPasswordInput, 'Kata sandi minimal 6 karakter');
                valid = false;
            } else if (newPassword === currentPassword) {
                showError(newPasswordInput, 'Kata sandi baru harus berbeda dengan yang lama');
                valid = false;
            }
            
            // Validate confirm password
            if (!confirmPassword) {
                showError(confirmPasswordInput, 'Konfirmasi kata sandi baru');
                valid = false;
            } else if (newPassword !== confirmPassword) {
                showError(confirmPasswordInput, 'Kata sandi tidak cocok');
                valid = false;
            }
            
            if (!valid) {
                e.preventDefault();
                // Scroll to first error
                const firstError = form.querySelector('.is-invalid');
                if (firstError) {
                    firstError.scrollIntoView({
                        behavior: 'smooth',
                        block: 'center'
                    });
                    firstError.focus();
                }
            } else {
                // Show loading state
                const submitBtn = document.getElementById('submitBtn');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = `
                    <div class="spinner-border spinner-border-sm me-2" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    Menyimpan...
                `;
                submitBtn.disabled = true;
                
                // Re-enable after 3 seconds if form hasn't submitted
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 3000);
            }
        });
    }
    
    function showError(input, message) {
        input.classList.add('is-invalid');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback d-block mt-1';
        errorDiv.textContent = message;
        input.parentElement.parentElement.appendChild(errorDiv);
    }
    
    // Add confirmation for reset
    const resetBtn = form.querySelector('button[type="reset"]');
    if (resetBtn) {
        resetBtn.addEventListener('click', function(e) {
            if (!confirm('Yakin ingin mengosongkan semua field?')) {
                e.preventDefault();
            }
        });
    }
    
    // Toast notification function
    function showToast(message, type = 'info') {
        const toastId = 'toast-' + Date.now();
        const toast = document.createElement('div');
        toast.id = toastId;
        toast.className = `toast align-items-center text-white bg-${type} border-0 position-fixed`;
        toast.style.cssText = `
            bottom: 20px;
            right: 20px;
            z-index: 9999;
        `;
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        document.body.appendChild(toast);
        const bsToast = new bootstrap.Toast(toast, { delay: 3000 });
        bsToast.show();
        
        toast.addEventListener('hidden.bs.toast', function() {
            document.body.removeChild(toast);
        });
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl+G to generate password
        if (e.ctrlKey && e.key === 'g') {
            e.preventDefault();
            generatePassword();
        }
        
        // Escape to close modals
        if (e.key === 'Escape') {
            const openModal = bootstrap.Modal.getInstance(document.querySelector('.modal.show'));
            if (openModal) {
                openModal.hide();
            }
        }
    });
    
    // Initialize requirement dots
    if (newPasswordInput) {
        newPasswordInput.dispatchEvent(new Event('input'));
    }
});
</script>
<?= $this->endSection() ?>