<?= $this->extend('layout/main_siswa') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4 px-lg-5 py-4">
    <!-- Page Header -->
    <div class="row mb-4 align-items-center">
        <div class="col-lg-8">
            <div class="d-flex align-items-center">
                <div class="icon-header bg-primary bg-opacity-10 rounded-3 p-3 me-3">
                    <i class="bi bi-person-circle text-primary fa-2x"></i>
                </div>
                <div>
                    <h1 class="h2 fw-bold text-dark mb-2">Profile Siswa</h1>
                    <p class="text-muted mb-0">Kelola informasi pribadi dan akun Anda</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="d-flex justify-content-lg-end gap-2">
               
                <a href="<?= base_url('siswa/dashboard_siswa') ?>" class="btn btn-outline-secondary rounded-3 px-4 py-2">
                    <i class="bi bi-arrow-left me-2"></i>Kembali
                </a>
            </div>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 rounded-3 shadow-sm mb-4" role="alert">
            <div class="d-flex align-items-center">
                <div class="flex-shrink-0">
                    <i class="bi bi-check-circle-fill fs-4"></i>
                </div>
                <div class="flex-grow-1 ms-3">
                    <h6 class="alert-heading fw-bold mb-1">Berhasil!</h6>
                    <p class="mb-0"><?= session()->getFlashdata('success') ?></p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show border-0 rounded-3 shadow-sm mb-4" role="alert">
            <div class="d-flex align-items-center">
                <div class="flex-shrink-0">
                    <i class="bi bi-exclamation-triangle-fill fs-4"></i>
                </div>
                <div class="flex-grow-1 ms-3">
                    <h6 class="alert-heading fw-bold mb-1">Perhatian!</h6>
                    <p class="mb-0"><?= session()->getFlashdata('error') ?></p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Left Column - Profile Info -->
        <div class="col-lg-4">
            <div class="card border-0 rounded-4 shadow-sm h-100">
                <div class="card-header bg-white border-bottom py-4">
                    <h5 class="mb-0 fw-bold text-dark">
                        <i class="bi bi-person-badge me-2"></i>Informasi Siswa
                    </h5>
                    <p class="text-muted mb-0 small">Data identitas pribadi</p>
                </div>
                <div class="card-body p-4">
                    <!-- Profile Photo -->
                    <div class="text-center mb-4">
                        <div class="profile-avatar mx-auto position-relative">
                            <div class="avatar-circle bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center"
                                 style="width: 140px; height: 140px;">
                                <i class="bi bi-person-fill text-primary" style="font-size: 70px;"></i>
                            </div>
                            <div class="online-indicator bg-success border border-3 border-white rounded-circle position-absolute"
                                 style="width: 20px; height: 20px; bottom: 10px; right: 30px;"></div>
                        </div>
                        <?php
                        $nama_siswa = is_array($siswa) ? ($siswa['nama_siswa'] ?? '') : ($siswa->nama_siswa ?? '');
                        $nisn = is_array($siswa) ? ($siswa['nisn'] ?? '') : ($siswa->nisn ?? '');
                        ?>
                        <h4 class="mt-4 mb-1 fw-bold"><?= $nama_siswa ?></h4>
                        <div class="d-flex align-items-center justify-content-center gap-2 mb-3">
                            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill">
                                NISN: <?= $nisn ?>
                            </span>
                        </div>
                    </div>

                    <!-- Profile Details -->
                    <div class="profile-details">
                        <div class="detail-item mb-3">
                            <div class="d-flex align-items-center mb-2">
                                <div class="detail-icon bg-primary bg-opacity-10 rounded-2 p-2 me-3">
                                    <i class="bi bi-gender-ambiguous text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">Jenis Kelamin</small>
                                    <h6 class="mb-0 fw-semibold">
                                        <?php
                                        $jenis_kelamin = is_array($siswa) ? ($siswa['jenis_kelamin'] ?? '') : ($siswa->jenis_kelamin ?? '');
                                        echo $jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan';
                                        ?>
                                    </h6>
                                </div>
                            </div>
                        </div>

                        <div class="detail-item mb-3">
                            <div class="d-flex align-items-center mb-2">
                                <div class="detail-icon bg-primary bg-opacity-10 rounded-2 p-2 me-3">
                                    <i class="bi bi-calendar-event text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">Tempat & Tanggal Lahir</small>
                                    <h6 class="mb-0 fw-semibold">
                                        <?php
                                        $tempat_lahir = is_array($siswa) ? ($siswa['tempat_lahir'] ?? '') : ($siswa->tempat_lahir ?? '');
                                        $tanggal_lahir = is_array($siswa) ? ($siswa['tanggal_lahir'] ?? '') : ($siswa->tanggal_lahir ?? '');
                                        echo $tempat_lahir ?: '-';
                                        if ($tanggal_lahir) {
                                            echo ', ' . date('d/m/Y', strtotime($tanggal_lahir));
                                        }
                                        ?>
                                    </h6>
                                </div>
                            </div>
                        </div>

                        <div class="detail-item mb-3">
                            <div class="d-flex align-items-center mb-2">
                                <div class="detail-icon bg-primary bg-opacity-10 rounded-2 p-2 me-3">
                                    <i class="bi bi-telephone text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">Nomor Telepon/HP</small>
                                    <h6 class="mb-0 fw-semibold">
                                        <?php
                                        $no_hp = is_array($siswa) ? ($siswa['no_hp'] ?? '') : ($siswa->no_hp ?? '');
                                        echo $no_hp ?: '-';
                                        ?>
                                    </h6>
                                </div>
                            </div>
                        </div>

                        <div class="detail-item mb-3">
                            <div class="d-flex align-items-center mb-2">
                                <div class="detail-icon bg-primary bg-opacity-10 rounded-2 p-2 me-3">
                                    <i class="bi bi-house-door text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">Alamat</small>
                                    <h6 class="mb-0 fw-semibold">
                                        <?php
                                        $alamat = is_array($siswa) ? ($siswa['alamat'] ?? '') : ($siswa->alamat ?? '');
                                        echo $alamat ?: '-';
                                        ?>
                                    </h6>
                                </div>
                            </div>
                        </div>

                        <div class="detail-item mb-3">
                            <div class="d-flex align-items-center mb-2">
                                <div class="detail-icon bg-primary bg-opacity-10 rounded-2 p-2 me-3">
                                    <i class="bi bi-building text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">Kelas</small>
                                    <h6 class="mb-0 fw-semibold">
                                        <?php
                                        $nama_kelas = is_array($kelas) ? ($kelas['nama_kelas'] ?? 'Belum ada kelas') : ($kelas->nama_kelas ?? 'Belum ada kelas');
                                        echo $nama_kelas;
                                        ?>
                                    </h6>
                                </div>
                            </div>
                        </div>

                        <div class="detail-item">
                            <div class="d-flex align-items-center mb-2">
                                <div class="detail-icon bg-primary bg-opacity-10 rounded-2 p-2 me-3">
                                    <i class="bi bi-calendar-plus text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted d-block">Tahun Masuk</small>
                                    <h6 class="mb-0 fw-semibold">
                                        <?php
                                        $tahun_masuk = is_array($siswa) ? ($siswa['tahun_masuk'] ?? '') : ($siswa->tahun_masuk ?? '');
                                        echo $tahun_masuk ?: '-';
                                        ?>
                                    </h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column - Edit Form & Account Info -->
        <div class="col-lg-8">
            <!-- Edit Profile Form -->
            <div class="card border-0 rounded-4 shadow-sm mb-4">
                <div class="card-header bg-white border-bottom py-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-0 fw-bold text-dark">
                                <i class="bi bi-pencil-square me-2"></i>Edit Profile
                            </h5>
                            <p class="text-muted mb-0 small">Perbarui informasi pribadi Anda</p>
                        </div>
                        <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2">
                            <i class="bi bi-info-circle me-1"></i>Data yang dapat diubah
                        </span>
                    </div>
                </div>
                <div class="card-body p-4">
                    <form action="<?= base_url('siswa/profile/update') ?>" method="POST" id="profileForm">
                        <?= csrf_field() ?>
                        
                        <div class="row g-4 mb-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label fw-semibold mb-2">NISN</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0">
                                            <i class="bi bi-card-heading text-muted"></i>
                                        </span>
                                        <input type="text" class="form-control border-start-0 bg-light" 
                                               value="<?= $siswa['nisn'] ?? '' ?>" readonly>
                                    </div>
                                    <small class="text-muted mt-1 d-block">
                                        <i class="bi bi-info-circle me-1"></i>NISN tidak dapat diubah
                                    </small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label fw-semibold mb-2">Nama Lengkap <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0">
                                            <i class="bi bi-person text-muted"></i>
                                        </span>
                                        <input type="text" class="form-control <?= isset($errors['nama_siswa']) ? 'is-invalid' : '' ?> border-start-0" 
                                               name="nama_siswa" value="<?= old('nama_siswa', $siswa['nama_siswa'] ?? '') ?>" 
                                               placeholder="Masukkan nama lengkap" required>
                                    </div>
                                    <?php if(isset($errors['nama_siswa'])): ?>
                                        <div class="invalid-feedback d-block"><?= $errors['nama_siswa'] ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="row g-4 mb-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label fw-semibold mb-2">No. Telepon/HP <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0">
                                            <i class="bi bi-phone text-muted"></i>
                                        </span>
                                        <input type="tel" class="form-control <?= isset($errors['no_hp']) ? 'is-invalid' : '' ?> border-start-0" 
                                               name="no_hp" value="<?= old('no_hp', $siswa['no_hp'] ?? '') ?>" 
                                               placeholder="Contoh: 081234567890" required>
                                    </div>
                                    <?php if(isset($errors['no_hp'])): ?>
                                        <div class="invalid-feedback d-block"><?= $errors['no_hp'] ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label fw-semibold mb-2">Kelas</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0">
                                            <i class="bi bi-mortarboard text-muted"></i>
                                        </span>
                                        <input type="text" class="form-control border-start-0 bg-light" 
                                               value="<?= $kelas['nama_kelas'] ?? '-' ?>" readonly>
                                    </div>
                                    <small class="text-muted mt-1 d-block">
                                        <i class="bi bi-info-circle me-1"></i>Kelas tidak dapat diubah
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="form-group mb-4">
                            <label class="form-label fw-semibold mb-2">Alamat Lengkap <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light align-items-start border-end-0">
                                    <i class="bi bi-geo-alt text-muted mt-2"></i>
                                </span>
                                <textarea class="form-control <?= isset($errors['alamat']) ? 'is-invalid' : '' ?> border-start-0" 
                                          name="alamat" rows="3" placeholder="Masukkan alamat lengkap" required><?= old('alamat', $siswa['alamat'] ?? '') ?></textarea>
                            </div>
                            <?php if(isset($errors['alamat'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['alamat'] ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="d-flex justify-content-between align-items-center border-top pt-4 mt-4">
                            <div>
                                <small class="text-muted">
                                    <i class="bi bi-exclamation-circle me-1"></i>
                                    Pastikan data yang diisi sudah benar
                                </small>
                            </div>
                            <div class="d-flex gap-2">
                                <button type="reset" class="btn btn-outline-secondary rounded-3 px-4 py-2">
                                    <i class="bi bi-arrow-clockwise me-2"></i>Reset
                                </button>
                                <button type="submit" class="btn btn-primary rounded-3 px-4 py-2">
                                    <i class="bi bi-save me-2"></i>Simpan Perubahan
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Account Information -->
            <div class="card border-0 rounded-4 shadow-sm">
                <div class="card-header bg-white border-bottom py-4">
                    <h5 class="mb-0 fw-bold text-dark">
                        <i class="bi bi-shield-lock me-2"></i>Informasi Akun
                    </h5>
                    <p class="text-muted mb-0 small">Detail akun dan aktivitas login</p>
                </div>
                <div class="card-body p-4">
                    <div class="alert alert-info border-info border-opacity-25 bg-info bg-opacity-10 rounded-3 mb-4">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="bi bi-info-circle text-info fs-5"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="alert-heading fw-semibold mb-2">Informasi Login</h6>
                                <p class="mb-2">
                                    <strong>Username:</strong>
                                    <code class="bg-dark text-white px-2 py-1 rounded-2"><?= $nisn ?></code>
                                </p>
                                <p class="mb-0">
                                    Untuk keamanan akun, segera ganti password secara berkala.
                                    <a href="<?= base_url('siswa/change_password') ?>" class="alert-link fw-semibold">Klik di sini</a> untuk mengganti password.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-borderless">
                            <tbody>
                                <tr class="align-middle">
                                    <td style="width: 40px;">
                                        <div class="bg-primary bg-opacity-10 rounded-2 p-2 text-center">
                                            <i class="bi bi-calendar-plus text-primary"></i>
                                        </div>
                                    </td>
                                    <td>
                                        <h6 class="mb-1 fw-semibold">Terdaftar Sejak</h6>
                                        <small class="text-muted">Tanggal pendaftaran akun</small>
                                    </td>
                                    <td class="text-end">
                                        <h6 class="mb-0 fw-semibold text-dark">
                                            <?php
                                            $created_at = is_array($siswa) ? ($siswa['created_at'] ?? '') : ($siswa->created_at ?? '');
                                            if ($created_at) {
                                                echo date('d F Y', strtotime($created_at));
                                                echo '<br>';
                                                echo '<small class="text-muted">' . date('H:i', strtotime($created_at)) . ' WIB</small>';
                                            } else {
                                                echo '-';
                                            }
                                            ?>
                                        </h6>
                                    </td>
                                </tr>
                                
                                <tr class="align-middle">
                                    <td>
                                        <div class="bg-success bg-opacity-10 rounded-2 p-2 text-center">
                                            <i class="bi bi-clock-history text-success"></i>
                                        </div>
                                    </td>
                                    <td>
                                        <h6 class="mb-1 fw-semibold">Login Terakhir</h6>
                                        <small class="text-muted">Aktivitas login terakhir</small>
                                    </td>
                                    <td class="text-end">
                                        <h6 class="mb-0 fw-semibold <?= !empty($last_login) ? 'text-success' : 'text-warning' ?>">
                                            <?php
                                            $last_login = is_array($siswa) ? ($siswa['last_login'] ?? '') : ($siswa->last_login ?? '');
                                            if (!empty($last_login)) {
                                                echo date('d F Y', strtotime($last_login));
                                                echo '<br>';
                                                echo '<small class="text-muted">' . date('H:i', strtotime($last_login)) . ' WIB</small>';
                                            } else {
                                                echo 'Belum pernah login';
                                            }
                                            ?>
                                        </h6>
                                    </td>
                                </tr>
                                
                                <tr class="align-middle">
                                    <td>
                                        <div class="bg-success bg-opacity-10 rounded-2 p-2 text-center">
                                            <i class="bi bi-check-circle text-success"></i>
                                        </div>
                                    </td>
                                    <td>
                                        <h6 class="mb-1 fw-semibold">Status Akun</h6>
                                        <small class="text-muted">Status keaktifan akun</small>
                                    </td>
                                    <td class="text-end">
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2 rounded-pill">
                                            <i class="bi bi-check-circle me-1"></i>Aktif
                                        </span>
                                    </td>
                                </tr>
                                
                                <tr class="align-middle">
                                    <td>
                                        <div class="bg-primary bg-opacity-10 rounded-2 p-2 text-center">
                                            <i class="bi bi-person-check text-primary"></i>
                                        </div>
                                    </td>
                                    <td>
                                        <h6 class="mb-1 fw-semibold">Status Verifikasi</h6>
                                        <small class="text-muted">Status verifikasi data</small>
                                    </td>
                                    <td class="text-end">
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2 rounded-pill">
                                            <i class="bi bi-check-circle me-1"></i>Terverifikasi
                                        </span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4 pt-3 border-top">
                        <a href="<?= base_url('siswa/logout') ?>" class="btn btn-outline-danger rounded-3 px-4 py-2"
                           onclick="return confirm('Yakin ingin keluar dari akun?')">
                            <i class="bi bi-box-arrow-right me-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    .icon-header {
        transition: all 0.3s ease;
    }
    
    .icon-header:hover {
        transform: rotate(10deg) scale(1.1);
    }
    
    .profile-avatar {
        position: relative;
        width: fit-content;
        margin: 0 auto;
    }
    
    .avatar-circle {
        transition: all 0.3s ease;
        border: 4px solid transparent;
    }
    
    .profile-avatar:hover .avatar-circle {
        border-color: rgba(78, 115, 223, 0.3);
        transform: scale(1.05);
    }
    
    .online-indicator {
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { box-shadow: 0 0 0 0 rgba(40, 167, 69, 0.7); }
        70% { box-shadow: 0 0 0 10px rgba(40, 167, 69, 0); }
        100% { box-shadow: 0 0 0 0 rgba(40, 167, 69, 0); }
    }
    
    .detail-item {
        transition: all 0.3s ease;
        padding: 12px 0;
        border-bottom: 1px solid #f0f0f0;
    }
    
    .detail-item:hover {
        background-color: rgba(78, 115, 223, 0.03);
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 8px;
    }
    
    .detail-item:last-child {
        border-bottom: none;
    }
    
    .detail-icon {
        width: 45px;
        height: 45px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .card {
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    
    .card:hover {
        border-color: rgba(78, 115, 223, 0.2);
        transform: translateY(-2px);
    }
    
    .form-control:focus {
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.25);
    }
    
    .form-control.bg-light {
        background-color: #f8f9fc !important;
        color: #6c757d;
    }
    
    .input-group-text {
        background-color: #f8f9fc;
        border-color: #e3e6f0;
    }
    
    .table-borderless tbody tr {
        transition: all 0.3s ease;
    }
    
    .table-borderless tbody tr:hover {
        background-color: rgba(78, 115, 223, 0.03);
    }
    
    .badge {
        font-weight: 600;
        letter-spacing: 0.3px;
    }
    
    /* Responsive adjustments */
    @media (min-width: 1200px) {
        .container-fluid {
            max-width: 1400px;
        }
        
        .col-lg-4 {
            max-width: 380px;
        }
        
        .col-lg-8 {
            max-width: calc(100% - 380px);
        }
    }
    
    @media (max-width: 768px) {
        .profile-avatar .avatar-circle {
            width: 120px !important;
            height: 120px !important;
        }
        
        .online-indicator {
            bottom: 5px !important;
            right: 20px !important;
        }
        
        .detail-item {
            flex-direction: column;
            align-items: flex-start !important;
        }
        
        .detail-icon {
            margin-bottom: 10px;
        }
        
        .d-flex.gap-2 {
            gap: 0.5rem !important;
        }
    }
    
    /* Animation for form elements */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .card {
        animation: fadeIn 0.5s ease-out;
    }
    
    .card:nth-child(2) {
        animation-delay: 0.1s;
    }
    
    /* Custom scrollbar for textarea */
    textarea.form-control {
        resize: vertical;
        min-height: 100px;
    }
    
    /* Print styles */
    @media print {
        .no-print, .btn, .alert {
            display: none !important;
        }
        
        .card {
            border: 1px solid #000 !important;
            box-shadow: none !important;
        }
        
        .profile-avatar .avatar-circle {
            border: 2px solid #000 !important;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const form = document.getElementById('profileForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const namaInput = form.querySelector('input[name="nama_siswa"]');
            const noHpInput = form.querySelector('input[name="no_hp"]');
            const alamatInput = form.querySelector('textarea[name="alamat"]');
            let valid = true;
            
            // Reset previous error states
            [namaInput, noHpInput, alamatInput].forEach(input => {
                input.classList.remove('is-invalid');
                const errorDiv = input.parentElement.parentElement.querySelector('.invalid-feedback');
                if (errorDiv) {
                    errorDiv.remove();
                }
            });
            
            // Validate name
            if (!namaInput.value.trim()) {
                showError(namaInput, 'Nama lengkap wajib diisi');
                valid = false;
            } else if (namaInput.value.trim().length < 3) {
                showError(namaInput, 'Nama minimal 3 karakter');
                valid = false;
            }
            
            // Validate phone number
            const phoneRegex = /^[0-9]{10,13}$/;
            if (!noHpInput.value.trim()) {
                showError(noHpInput, 'Nomor telepon wajib diisi');
                valid = false;
            } else if (!phoneRegex.test(noHpInput.value.trim())) {
                showError(noHpInput, 'Nomor telepon harus 10-13 digit angka');
                valid = false;
            }
            
            // Validate address
            if (!alamatInput.value.trim()) {
                showError(alamatInput, 'Alamat wajib diisi');
                valid = false;
            } else if (alamatInput.value.trim().length < 10) {
                showError(alamatInput, 'Alamat minimal 10 karakter');
                valid = false;
            }
            
            if (!valid) {
                e.preventDefault();
                // Scroll to first error
                const firstError = form.querySelector('.is-invalid');
                if (firstError) {
                    firstError.scrollIntoView({
                        behavior: 'smooth',
                        block: 'center'
                    });
                    firstError.focus();
                }
            } else {
                // Show loading state
                const submitBtn = form.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = `
                    <div class="spinner-border spinner-border-sm me-2" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    Menyimpan...
                `;
                submitBtn.disabled = true;
                
                // Re-enable after 3 seconds if form hasn't submitted
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 3000);
            }
        });
    }
    
    function showError(input, message) {
        input.classList.add('is-invalid');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback d-block';
        errorDiv.textContent = message;
        input.parentElement.parentElement.appendChild(errorDiv);
    }
    
    // Auto format phone number
    const phoneInput = document.querySelector('input[name="no_hp"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 13) {
                value = value.slice(0, 13);
            }
            e.target.value = value;
        });
    }
    
    // Add character counter for textarea
    const addressTextarea = document.querySelector('textarea[name="alamat"]');
    if (addressTextarea) {
        const counterDiv = document.createElement('div');
        counterDiv.className = 'text-muted small mt-1 text-end';
        counterDiv.innerHTML = `<span id="charCount">0</span> / 500 karakter`;
        addressTextarea.parentElement.appendChild(counterDiv);
        
        addressTextarea.addEventListener('input', function() {
            const charCount = this.value.length;
            document.getElementById('charCount').textContent = charCount;
            
            if (charCount > 500) {
                this.value = this.value.substring(0, 500);
                document.getElementById('charCount').textContent = 500;
            }
            
            // Update counter color
            if (charCount > 450) {
                counterDiv.classList.remove('text-muted');
                counterDiv.classList.add('text-danger');
            } else {
                counterDiv.classList.remove('text-danger');
                counterDiv.classList.add('text-muted');
            }
        });
        
        // Initialize counter
        addressTextarea.dispatchEvent(new Event('input'));
    }
    
    // Add confirmation for reset
    const resetBtn = form.querySelector('button[type="reset"]');
    if (resetBtn) {
        resetBtn.addEventListener('click', function(e) {
            if (!confirm('Yakin ingin mengembalikan semua perubahan?')) {
                e.preventDefault();
            }
        });
    }
    
    // Add keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl+S to save
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            const submitBtn = document.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.click();
            }
        }
        
        // Escape to reset
        if (e.key === 'Escape') {
            if (confirm('Reset semua perubahan?')) {
                const resetBtn = document.querySelector('button[type="reset"]');
                if (resetBtn) {
                    resetBtn.click();
                }
            }
        }
    });
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>
<?= $this->endSection() ?>