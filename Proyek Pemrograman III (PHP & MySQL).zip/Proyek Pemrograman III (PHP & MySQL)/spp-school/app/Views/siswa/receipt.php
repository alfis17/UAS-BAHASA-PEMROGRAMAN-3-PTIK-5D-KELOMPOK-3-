<div class="receipt-container">
    <style>
        .receipt-container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px solid #000;
            padding: 20px;
            font-family: 'Times New Roman', serif;
            font-size: 14px;
            line-height: 1.4;
        }
        .receipt-header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .receipt-header h2 {
            margin: 0;
            font-size: 18px;
            text-decoration: underline;
        }
        .info-row {
            display: flex;
            margin-bottom: 8px;
        }
        .info-label {
            width: 150px;
            font-weight: bold;
        }
        .amount-section {
            background-color: #f8f9fa;
            border: 2px solid #000;
            padding: 15px;
            margin: 20px 0;
            text-align: center;
        }
        .amount-text {
            font-size: 16px;
            font-weight: bold;
            color: #dc3545;
        }
        .receipt-footer {
            border-top: 2px solid #000;
            padding-top: 20px;
            margin-top: 30px;
            text-align: center;
        }
        @media print {
            .receipt-container { border: none; margin: 0; }
        }
    </style>

    <!-- Header -->
    <div class="receipt-header">
        <h2>KWITANSI PEMBAYARAN SPP</h2>
        <p class="mb-0">Sekolah Menengah Atas</p>
    </div>

    <!-- School Info -->
    <div class="info-row">
        <div class="info-label">No. Kwitansi:</div>
        <div>SPP/<?= date('Y', strtotime($pembayaran['tanggal_bayar'])) ?>/<?= date('m', strtotime($pembayaran['tanggal_bayar'])) ?>/<?= str_pad($pembayaran['id'], 4, '0', STR_PAD_LEFT) ?></div>
    </div>

    <div class="info-row">
        <div class="info-label">Telah Terima Dari:</div>
        <div><?= $pembayaran['nama_siswa'] ?> (NISN: <?= $pembayaran['nisn'] ?>)</div>
    </div>

    <div class="info-row">
        <div class="info-label">Kelas:</div>
        <div><?= $pembayaran['nama_kelas'] ?? 'Tidak ada kelas' ?></div>
    </div>

    <div class="info-row">
        <div class="info-label">Untuk Pembayaran:</div>
        <div>SPP Bulan <?= $pembayaran['bulan'] ?> <?= $pembayaran['tahun'] ?></div>
    </div>

    <div class="info-row">
        <div class="info-label">Tahun Ajaran:</div>
        <div><?= $pembayaran['tahun_ajaran'] ?? '-' ?></div>
    </div>

    <div class="info-row">
        <div class="info-label">Tanggal Bayar:</div>
        <div><?= date('d/m/Y', strtotime($pembayaran['tanggal_bayar'])) ?></div>
    </div>

    <div class="info-row">
        <div class="info-label">Metode Pembayaran:</div>
        <div><?= $pembayaran['metode_pembayaran'] ?></div>
    </div>

    <!-- Amount Section -->
    <div class="amount-section">
        <div class="amount-text">
            Rp <?= number_format($pembayaran['jumlah_bayar'], 0, ',', '.') ?>
        </div>
        <div class="mt-2">
            <strong>Status: <?= $pembayaran['status_pembayaran'] ?? 'Belum Lunas' ?></strong>
        </div>
    </div>

    <!-- Footer -->
    <div class="receipt-footer">
        <div class="row">
            <div class="col-6 text-center">
                <p class="mb-4">Petugas</p>
                <p><u><?= $pembayaran['petugas'] ?? 'Admin' ?></u></p>
            </div>
            <div class="col-6 text-center">
                <p class="mb-4">Penerima</p>
                <p><u><?= $pembayaran['nama_siswa'] ?></u></p>
            </div>
        </div>
        <div class="mt-3">
            <small>Dicetak pada: <?= $tanggal_cetak ?></small>
        </div>
    </div>
</div>
