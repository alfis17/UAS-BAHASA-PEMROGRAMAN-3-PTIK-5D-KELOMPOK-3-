<?= $this->extend('layout/main_siswa') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4 px-lg-5 py-4">
    <!-- Page Header -->
    <div class="row mb-4 align-items-center">
        <div class="col-lg-8">
            <div class="d-flex align-items-center mb-3">
                <div class="icon-header bg-primary bg-opacity-10 rounded-3 p-3 me-3">
                    <i class="bi bi-clock-history text-primary fa-2x"></i>
                </div>
                <div>
                    <h1 class="h2 fw-bold text-dark mb-2">Riwayat Pembayaran SPP</h1>
                    <p class="text-muted mb-0">Monitor semua transaksi pembayaran SPP Anda</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 text-lg-end">
            <a href="<?= base_url('siswa/pembayaran_siswa') ?>" class="btn btn-primary btn-lg rounded-3 px-4 py-3 shadow-sm">
                <i class="bi bi-plus-circle me-2"></i>Bayar SPP Baru
            </a>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card border-0 rounded-4 shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted fw-semibold mb-3">Total Transaksi</h6>
                            <h3 class="fw-bold mb-0"><?= count($pembayaran) ?></h3>
                            <small class="text-muted">Riwayat pembayaran</small>
                        </div>
                        <div class="bg-primary bg-opacity-10 rounded-3 p-3">
                            <i class="bi bi-receipt text-primary fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card border-0 rounded-4 shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted fw-semibold mb-3">Total Dibayar</h6>
                            <?php
                            $total_semua = 0;
                            if (!empty($pembayaran)) {
                                foreach($pembayaran as $payment) {
                                    $jumlah_bayar = is_object($payment) ? $payment->jumlah_bayar : $payment['jumlah_bayar'];
                                    $total_semua += (float) $jumlah_bayar;
                                }
                            }
                            ?>
                            <h3 class="fw-bold mb-0">Rp <?= number_format($total_semua, 0, ',', '.') ?></h3>
                            <small class="text-muted">Seluruh periode</small>
                        </div>
                        <div class="bg-success bg-opacity-10 rounded-3 p-3">
                            <i class="bi bi-cash-stack text-success fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card border-0 rounded-4 shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted fw-semibold mb-3">Status Terakhir</h6>
                            <?php
                            $last_status = 'Belum Ada';
                            $last_date = '-';
                            if (!empty($pembayaran)) {
                                $last = end($pembayaran);
                                $last_status = is_object($last) ? ($last->status_pembayaran ?? 'Lunas') : ($last['status_pembayaran'] ?? 'Lunas');
                                $last_date = is_object($last) ? ($last->tanggal_bayar ?? '-') : ($last['tanggal_bayar'] ?? '-');
                                if ($last_date != '-') {
                                    $last_date = date('d/m/Y', strtotime($last_date));
                                }
                            }
                            ?>
                            <h3 class="fw-bold mb-0 <?= $last_status == 'Lunas' ? 'text-success' : 'text-warning' ?>">
                                <?= $last_status == 'Lunas' ? 'Lunas' : 'Belum' ?>
                            </h3>
                            <small class="text-muted"><?= $last_date ?></small>
                        </div>
                        <div class="bg-warning bg-opacity-10 rounded-3 p-3">
                            <i class="bi bi-calendar-check text-warning fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card border-0 rounded-4 shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted fw-semibold mb-3">Tahun Aktif</h6>
                            <h3 class="fw-bold mb-0"><?= date('Y') ?></h3>
                            <small class="text-muted">Tahun berjalan</small>
                        </div>
                        <div class="bg-info bg-opacity-10 rounded-3 p-3">
                            <i class="bi bi-calendar-month text-info fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="card border-0 rounded-4 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom py-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0 fw-bold text-dark">
                        <i class="bi bi-funnel me-2"></i>Filter Data
                    </h5>
                    <p class="text-muted mb-0 small">Saring riwayat pembayaran sesuai kebutuhan</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-secondary" onclick="exportToExcel()">
                        <i class="bi bi-download me-1"></i>Excel
                    </button>
                    <button type="button" class="btn btn-outline-secondary" onclick="exportToPDF()">
                        <i class="bi bi-file-pdf me-1"></i>PDF
                    </button>
                </div>
            </div>
        </div>
        <div class="card-body p-4">
            <form action="" method="GET" class="row g-4">
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <label class="form-label fw-semibold">Tahun Pembayaran</label>
                    <select name="tahun" class="form-select form-select-lg border-2 rounded-3">
                        <option value="">Semua Tahun</option>
                        <?php for($i = date('Y'); $i >= 2020; $i--): ?>
                            <option value="<?= $i ?>" <?= ($tahun_filter ?? '') == $i ? 'selected' : '' ?>>
                                Tahun <?= $i ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <label class="form-label fw-semibold">Bulan Pembayaran</label>
                    <select name="bulan" class="form-select form-select-lg border-2 rounded-3">
                        <option value="">Semua Bulan</option>
                        <?php
                        $bulan_list = [
                            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                        ];
                        foreach($bulan_list as $index => $bulan): ?>
                            <option value="<?= $bulan ?>" <?= ($bulan_filter ?? '') == $bulan ? 'selected' : '' ?>>
                                <?= $bulan ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <label class="form-label fw-semibold">Status Pembayaran</label>
                    <select name="status" class="form-select form-select-lg border-2 rounded-3">
                        <option value="">Semua Status</option>
                        <option value="Lunas" <?= ($status_filter ?? '') == 'Lunas' ? 'selected' : '' ?>>
                            Lunas
                        </option>
                        <option value="Belum Lunas" <?= ($status_filter ?? '') == 'Belum Lunas' ? 'selected' : '' ?>>
                            Belum Lunas
                        </option>
                    </select>
                </div>
                <div class="col-xl-3 col-lg-12 col-md-6 d-flex align-items-end">
                    <div class="d-flex gap-2 w-100">
                        <button type="submit" class="btn btn-primary btn-lg rounded-3 flex-fill">
                            <i class="bi bi-search me-2"></i>Terapkan Filter
                        </button>
                        <a href="<?= current_url() ?>" class="btn btn-outline-secondary btn-lg rounded-3">
                            <i class="bi bi-arrow-clockwise"></i>
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="card border-0 rounded-4 shadow-sm">
        <div class="card-header bg-white border-bottom py-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0 fw-bold text-dark">
                        <i class="bi bi-list-check me-2"></i>Daftar Riwayat Pembayaran
                    </h5>
                    <p class="text-muted mb-0 small">
                        <?php if(empty($pembayaran)): ?>
                            Tidak ada data pembayaran
                        <?php else: ?>
                            Menampilkan <?= count($pembayaran) ?> transaksi pembayaran
                        <?php endif; ?>
                    </p>
                </div>
                <div class="d-flex gap-2">
                    <div class="input-group" style="width: 250px;">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="bi bi-search text-muted"></i>
                        </span>
                        <input type="text" id="searchInput" class="form-control border-start-0" placeholder="Cari transaksi...">
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card-body p-4">
            <?php if(empty($pembayaran)): ?>
                <div class="text-center py-5 my-4">
                    <div class="mb-4">
                        <div class="bg-light rounded-3 p-4 d-inline-block mb-3">
                            <i class="bi bi-receipt text-muted fa-4x"></i>
                        </div>
                        <h4 class="text-muted mb-3">Belum ada riwayat pembayaran</h4>
                        <p class="text-muted mb-4">Mulai dengan melakukan pembayaran SPP pertama Anda</p>
                        <a href="<?= base_url('siswa/pembayaran_siswa') ?>" class="btn btn-primary btn-lg rounded-3 px-4 py-3">
                            <i class="bi bi-cash-stack me-2"></i>Bayar SPP Sekarang
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <div class="table-responsive-xl">
                    <table class="table table-hover mb-0" id="historyTable">
                        <thead class="table-light">
                            <tr>
                                <th class="py-3 px-4 text-start" style="width: 60px;">#</th>
                                <th class="py-3 px-4 text-start">Periode</th>
                                <th class="py-3 px-4 text-start">Tanggal Bayar</th>
                                <th class="py-3 px-4 text-end">Jumlah</th>
                                <th class="py-3 px-4 text-center">Metode</th>
                                <th class="py-3 px-4 text-start">Petugas</th>
                                <th class="py-3 px-4 text-center">Status</th>
                                <th class="py-3 px-4 text-center" style="width: 120px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($pembayaran as $index => $payment): ?>
                            <?php
                            // Parse data safely
                            $bulan = is_object($payment) ? $payment->bulan : ($payment['bulan'] ?? '');
                            $tahun = is_object($payment) ? $payment->tahun : ($payment['tahun'] ?? '');
                            $tanggal_bayar = is_object($payment) ? $payment->tanggal_bayar : ($payment['tanggal_bayar'] ?? '');
                            $jumlah_bayar = is_object($payment) ? $payment->jumlah_bayar : ($payment['jumlah_bayar'] ?? 0);
                            $metode_pembayaran = is_object($payment) ? $payment->metode_pembayaran : ($payment['metode_pembayaran'] ?? '-');
                            $nama_petugas = is_object($payment) ? $payment->nama_petugas : ($payment['nama_petugas'] ?? 'Admin');
                            $status = is_object($payment) ? ($payment->status_pembayaran ?? 'Lunas') : ($payment['status_pembayaran'] ?? 'Lunas');
                            $payment_id = is_object($payment) ? $payment->id : ($payment['id'] ?? 0);
                            ?>
                            <tr class="align-middle">
                                <td class="py-3 px-4 text-start">
                                    <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill px-3 py-2">
                                        <?= $index + 1 ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4">
                                    <div>
                                        <h6 class="mb-1 fw-semibold text-dark"><?= $bulan ?> <?= $tahun ?></h6>
                                        <small class="text-muted">Bulan SPP</small>
                                    </div>
                                </td>
                                <td class="py-3 px-4">
                                    <?php if($tanggal_bayar): ?>
                                        <div>
                                            <h6 class="mb-1 fw-semibold"><?= date('d/m/Y', strtotime($tanggal_bayar)) ?></h6>
                                            <small class="text-muted"><?= date('H:i', strtotime($tanggal_bayar)) ?> WIB</small>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted opacity-50">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4 text-end">
                                    <h6 class="fw-bold text-success mb-1">Rp <?= number_format($jumlah_bayar, 0, ',', '.') ?></h6>
                                    <small class="text-muted">Nominal bayar</small>
                                </td>
                                <td class="py-3 px-4 text-center">
                                    <span class="badge bg-info bg-opacity-10 text-info border border-info border-opacity-25 px-3 py-2 rounded-pill">
                                        <?= $metode_pembayaran ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="d-flex align-items-center">
                                        <div class="bg-light rounded-circle p-2 me-3">
                                            <i class="bi bi-person text-muted"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0 fw-semibold"><?= $nama_petugas ?></h6>
                                            <small class="text-muted">Petugas TU</small>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3 px-4 text-center">
                                    <?php if($status == 'Lunas'): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2 rounded-pill">
                                            <i class="bi bi-check-circle me-1"></i>Lunas
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25 px-3 py-2 rounded-pill">
                                            <i class="bi bi-clock me-1"></i>Belum Lunas
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4 text-center">
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-outline-primary btn-sm rounded-pill px-3"
                                                onclick="showReceipt(<?= $payment_id ?>)"
                                                data-bs-toggle="tooltip" 
                                                data-bs-placement="top"
                                                title="Lihat Kwitansi">
                                            <i class="bi bi-receipt"></i>
                                        </button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3 ms-2"
                                                onclick="downloadReceipt(<?= $payment_id ?>)"
                                                data-bs-toggle="tooltip" 
                                                data-bs-placement="top"
                                                title="Download">
                                            <i class="bi bi-download"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if(isset($pager)): ?>
                <div class="row mt-4 pt-4 border-top">
                    <div class="col-md-6">
                        <p class="text-muted mb-0">
                            Menampilkan <?= $pager->getCurrentPage() ?> dari <?= $pager->getPageCount() ?> halaman
                        </p>
                    </div>
                    <div class="col-md-6">
                        <nav aria-label="Page navigation" class="d-flex justify-content-end">
                            <?= $pager->links() ?>
                        </nav>
                    </div>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Enhanced Modal for Receipt -->
<div id="receiptModal" class="modal fade" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-header bg-primary text-white border-0 rounded-top-4 py-4 px-5">
                <div class="d-flex align-items-center w-100">
                    <div class="flex-grow-1">
                        <h5 class="modal-title mb-0 text-white">
                            <i class="bi bi-receipt me-2"></i>Kwitansi Pembayaran SPP
                        </h5>
                        <p class="mb-0 text-white opacity-85 small">Bukti pembayaran resmi</p>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-light btn-sm rounded-pill px-3"
                                onclick="downloadReceiptModal()">
                            <i class="bi bi-download me-1"></i>Download
                        </button>
                        <button type="button" class="btn btn-light btn-sm rounded-pill px-3"
                                onclick="printReceipt()">
                            <i class="bi bi-printer me-1"></i>Cetak
                        </button>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                </div>
            </div>
            <div class="modal-body p-5">
                <div id="receiptContent">
                    <!-- Receipt will be loaded here -->
                    <div class="text-center py-5">
                        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                            <span class="visually-hidden">Memuat kwitansi...</span>
                        </div>
                        <p class="mt-3 text-muted">Memuat kwitansi pembayaran...</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 rounded-bottom-4 py-4 px-5 bg-light">
                <button type="button" class="btn btn-outline-secondary rounded-3 px-4" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i>Tutup
                </button>
                <button type="button" class="btn btn-primary rounded-3 px-4" onclick="printReceipt()">
                    <i class="bi bi-printer me-1"></i>Cetak Sekarang
                </button>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    .icon-header {
        transition: all 0.3s ease;
    }
    
    .icon-header:hover {
        transform: rotate(10deg) scale(1.1);
    }
    
    .card {
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    
    .card:hover {
        border-color: rgba(78, 115, 223, 0.2);
        transform: translateY(-2px);
    }
    
    .table {
        --bs-table-hover-bg: rgba(78, 115, 223, 0.05);
        border-collapse: separate;
        border-spacing: 0;
    }
    
    .table thead th {
        background-color: #f8f9fc;
        border-bottom: 2px solid #e3e6f0;
        color: #4e73df;
        font-weight: 700;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        position: sticky;
        top: 0;
        z-index: 10;
    }
    
    .table tbody tr {
        transition: all 0.2s ease;
    }
    
    .table tbody tr:hover {
        background-color: var(--bs-table-hover-bg) !important;
        transform: scale(1.002);
    }
    
    .badge {
        font-weight: 600;
        letter-spacing: 0.3px;
    }
    
    .form-select-lg {
        padding: 0.75rem 1rem;
        font-size: 1rem;
    }
    
    .btn-lg {
        padding: 0.75rem 2rem;
        font-weight: 600;
    }
    
    /* Modal custom styles */
    .modal-content {
        box-shadow: 0 0.5rem 2rem rgba(0, 0, 0, 0.15);
        border: none;
    }
    
    .modal-header {
        border-bottom: 2px solid rgba(255, 255, 255, 0.2);
    }
    
    /* Responsive adjustments */
    @media (min-width: 1200px) {
        .container-fluid {
            max-width: 1400px;
        }
        
        .modal-xl {
            max-width: 1100px;
        }
    }
    
    @media (max-width: 768px) {
        .card-header {
            flex-direction: column;
            gap: 1rem;
            align-items: flex-start !important;
        }
        
        .table-responsive-xl {
            font-size: 0.9rem;
        }
        
        .btn-group {
            flex-direction: column;
            gap: 0.25rem;
        }
        
        .btn-group .btn {
            width: 100%;
            margin-left: 0 !important;
        }
    }
    
    /* Animation for table rows */
    @keyframes fadeInRow {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .table tbody tr {
        animation: fadeInRow 0.3s ease-out;
        animation-fill-mode: both;
    }
    
    .table tbody tr:nth-child(1) { animation-delay: 0.1s; }
    .table tbody tr:nth-child(2) { animation-delay: 0.2s; }
    .table tbody tr:nth-child(3) { animation-delay: 0.3s; }
    .table tbody tr:nth-child(4) { animation-delay: 0.4s; }
    .table tbody tr:nth-child(5) { animation-delay: 0.5s; }
    
    /* Print styles for receipt */
    @media print {
        body * {
            visibility: hidden;
        }
        #receiptContent, #receiptContent * {
            visibility: visible;
        }
        #receiptContent {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            padding: 20px;
            background: white;
        }
        .no-print {
            display: none !important;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize modal
    const receiptModal = new bootstrap.Modal(document.getElementById('receiptModal'));
    
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('#historyTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }
    
    // Add row highlight on click
    const tableRows = document.querySelectorAll('#historyTable tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('click', function(e) {
            // Don't trigger if clicking on action buttons
            if (!e.target.closest('button') && !e.target.closest('a')) {
                tableRows.forEach(r => r.classList.remove('table-active'));
                this.classList.add('table-active');
            }
        });
    });
});

function showReceipt(paymentId) {
    // Show loading state
    document.getElementById('receiptContent').innerHTML = `
        <div class="text-center py-5">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="visually-hidden">Memuat kwitansi...</span>
            </div>
            <p class="mt-3 text-muted">Memuat kwitansi pembayaran...</p>
        </div>
    `;
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('receiptModal'));
    modal.show();
    
    // Store current payment ID for print/download
    document.getElementById('receiptModal').dataset.paymentId = paymentId;
    
    // Load receipt via AJAX
    fetch(`<?= base_url('siswa/receipt/') ?>${paymentId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(html => {
            document.getElementById('receiptContent').innerHTML = html;
            
            // Add print-specific classes
            const receiptElement = document.getElementById('receiptContent');
            const elementsToHide = receiptElement.querySelectorAll('.no-print');
            elementsToHide.forEach(el => el.classList.add('no-print'));
            
            // Initialize any scripts in the loaded content
            initReceiptScripts();
        })
        .catch(error => {
            console.error('Error loading receipt:', error);
            document.getElementById('receiptContent').innerHTML = `
                <div class="alert alert-danger border-0 rounded-3">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <i class="bi bi-exclamation-triangle fa-2x text-danger"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="alert-heading fw-bold mb-2">Gagal Memuat Kwitansi</h6>
                            <p class="mb-0">Terjadi kesalahan saat memuat kwitansi. Silakan coba lagi atau hubungi administrator.</p>
                        </div>
                    </div>
                </div>
            `;
        });
}

function initReceiptScripts() {
    // Initialize any dynamic elements in the receipt
    const receiptElement = document.getElementById('receiptContent');
    
    // Add current date if not present
    const dateElements = receiptElement.querySelectorAll('.current-date');
    dateElements.forEach(el => {
        if (!el.textContent.trim()) {
            const now = new Date();
            el.textContent = now.toLocaleDateString('id-ID', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
    });
}

function printReceipt() {
    const printWindow = window.open('', '_blank', 'width=800,height=600');
    const receiptContent = document.getElementById('receiptContent').innerHTML;
    
    printWindow.document.write(`
        <!DOCTYPE html>
        <html lang="id">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Cetak Kwitansi</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
            <style>
                @media print {
                    @page {
                        size: A4;
                        margin: 20mm;
                    }
                    body {
                        font-size: 12pt;
                        line-height: 1.4;
                    }
                    .no-print {
                        display: none !important;
                    }
                    .receipt-container {
                        border: 2px solid #000;
                        padding: 20px;
                        margin: 0 auto;
                        max-width: 800px;
                    }
                    .watermark {
                        position: absolute;
                        opacity: 0.1;
                        font-size: 120px;
                        transform: rotate(-45deg);
                        z-index: -1;
                        top: 40%;
                        left: 10%;
                        color: #000;
                    }
                }
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                }
                .header {
                    border-bottom: 3px double #000;
                    padding-bottom: 20px;
                    margin-bottom: 20px;
                }
                .footer {
                    border-top: 3px double #000;
                    padding-top: 20px;
                    margin-top: 40px;
                }
                .signature {
                    margin-top: 50px;
                }
                .table-bordered {
                    border: 2px solid #000 !important;
                }
                .table-bordered th,
                .table-bordered td {
                    border: 1px solid #000 !important;
                }
            </style>
        </head>
        <body onload="window.print(); setTimeout(() => window.close(), 1000);">
            <div class="receipt-container">
                <div class="watermark">KWITANSI RESMI</div>
                ${receiptContent}
            </div>
        </body>
        </html>
    `);
    
    printWindow.document.close();
}

function downloadReceipt(paymentId) {
    // Create a temporary link to download the receipt
    const link = document.createElement('a');
    link.href = `<?= base_url('siswa/receipt/') ?>${paymentId}?download=1`;
    link.target = '_blank';
    link.download = `kwitansi-spp-${paymentId}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function downloadReceiptModal() {
    const paymentId = document.getElementById('receiptModal').dataset.paymentId;
    if (paymentId) {
        downloadReceipt(paymentId);
    }
}

function exportToExcel() {
    // Implement Excel export functionality
    alert('Fitur ekspor ke Excel akan segera tersedia!');
}

function exportToPDF() {
    // Implement PDF export functionality
    alert('Fitur ekspor ke PDF akan segera tersedia!');
}

// Add keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl+F to focus search
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.focus();
        }
    }
    
    // Escape to close modal
    if (e.key === 'Escape') {
        const modal = bootstrap.Modal.getInstance(document.getElementById('receiptModal'));
        if (modal) {
            modal.hide();
        }
    }
});
</script>
<?= $this->endSection() ?>