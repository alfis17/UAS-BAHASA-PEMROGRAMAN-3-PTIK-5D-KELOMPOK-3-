<?= $this->extend('layout/main_siswa') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4 px-lg-5 py-4">
    <!-- Page Header -->
    <div class="row mb-4 align-items-center">
        <div class="col-lg-8">
            <div class="d-flex align-items-center">
                <div class="icon-header bg-primary bg-opacity-10 rounded-3 p-3 me-3">
                    <i class="bi bi-printer text-primary fa-2x"></i>
                </div>
                <div>
                    <h1 class="h2 fw-bold text-dark mb-2">Laporan Pembayaran SPP</h1>
                    <p class="text-muted mb-0">Cetak dan ekspor riwayat pembayaran Anda</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="d-flex justify-content-lg-end gap-2">
                <button type="button" class="btn btn-outline-secondary rounded-3 px-4 py-2" onclick="exportToPDF()">
                    <i class="bi bi-file-pdf me-2"></i>PDF
                </button>
                <button type="button" class="btn btn-outline-secondary rounded-3 px-4 py-2" onclick="exportToExcel()">
                    <i class="bi bi-file-earmark-excel me-2"></i>Excel
                </button>
                <button type="button" class="btn btn-primary rounded-3 px-4 py-2" onclick="printReport()">
                    <i class="bi bi-printer me-2"></i>Cetak
                </button>
                <a href="<?= base_url('siswa/history') ?>" class="btn btn-outline-secondary rounded-3 px-4 py-2">
                    <i class="bi bi-arrow-left me-2"></i>Kembali
                </a>
            </div>
        </div>
    </div>

    <!-- Report Preview Container -->
    <div class="card border-0 rounded-4 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom py-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0 fw-bold text-dark">
                        <i class="bi bi-eye me-2"></i>Pratinjau Laporan
                    </h5>
                    <p class="text-muted mb-0 small">Tinjau laporan sebelum mencetak</p>
                </div>
                <div class="d-flex gap-2">
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary btn-sm dropdown-toggle rounded-3" type="button" 
                                data-bs-toggle="dropdown">
                            <i class="bi bi-gear me-1"></i>Opsi Cetak
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" onclick="printReport('full')">
                                <i class="bi bi-file-text me-2"></i>Laporan Lengkap
                            </a></li>
                            <li><a class="dropdown-item" href="#" onclick="printReport('simple')">
                                <i class="bi bi-card-text me-2"></i>Ringkasan Saja
                            </a></li>
                            <li><a class="dropdown-item" href="#" onclick="printReport('table')">
                                <i class="bi bi-table me-2"></i>Hanya Tabel
                            </a></li>
                        </ul>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary btn-sm dropdown-toggle rounded-3" type="button" 
                                data-bs-toggle="dropdown">
                            <i class="bi bi-calendar me-1"></i>Rentang Waktu
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?= current_url() ?>?range=all">
                                <i class="bi bi-calendar-range me-2"></i>Semua Waktu
                            </a></li>
                            <li><a class="dropdown-item" href="<?= current_url() ?>?range=year">
                                <i class="bi bi-calendar-year me-2"></i>Tahun Ini
                            </a></li>
                            <li><a class="dropdown-item" href="<?= current_url() ?>?range=last6">
                                <i class="bi bi-calendar-month me-2"></i>6 Bulan Terakhir
                            </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <!-- Print Container -->
            <div class="print-container bg-white p-4 p-lg-5" id="printArea">
                <!-- Report Header -->
                <div class="report-header text-center mb-5 pb-4 border-bottom">
                    <div class="school-logo mb-3">
                        <div class="logo-placeholder bg-primary bg-opacity-10 rounded-3 p-4 d-inline-block">
                            <i class="bi bi-building text-primary fa-4x"></i>
                        </div>
                    </div>
                    
                    <div class="school-info mb-3">
                        <h2 class="mb-2 fw-bold text-dark" style="font-size: 28px;">SMA NEGERI 1 SUNGAYANG</h2>
                        <p class="mb-2 text-muted" style="font-size: 16px;">SUNGAYANG, TANAH DATAR</p>
                        <p class="mb-0 text-muted" style="font-size: 14px;">Telp: (022) 1234567 | Email: smansayang@gmai.com.sch.id</p>
                    </div>
                    
                    <div class="report-title mt-4">
                        <h1 class="mb-3 fw-bold text-primary" style="font-size: 32px; border-bottom: 3px solid #4e73df; display: inline-block; padding-bottom: 10px;">
                            LAPORAN RIWAYAT PEMBAYARAN SPP
                        </h1>
                        <p class="text-muted mb-2" style="font-size: 14px;">
                            Tahun Ajaran: <?= $spp->tahun_ajaran ?? date('Y') . '/' . (date('Y') + 1) ?>
                        </p>
                    </div>
                </div>
                
                <!-- Student Information -->
                <div class="student-info-section mb-5">
                    <h4 class="fw-bold mb-4 text-dark" style="border-left: 4px solid #4e73df; padding-left: 15px;">
                        <i class="bi bi-person-badge me-2"></i>Informasi Siswa
                    </h4>
                    
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="info-card border rounded-3 p-4 h-100">
                                <h6 class="fw-semibold mb-3 text-primary">Data Pribadi</h6>
                                <table class="table table-borderless mb-0">
                                    <tr>
                                        <td width="40%" class="text-muted">Nama Lengkap</td>
                                        <td width="60%" class="fw-semibold"><?= $siswa->nama_siswa ?? '-' ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">NISN</td>
                                        <td class="fw-semibold"><?= $siswa->nisn ?? '-' ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Tempat/Tgl Lahir</td>
                                        <td class="fw-semibold">
                                            <?= $siswa->tempat_lahir ?? '-' ?>, 
                                            <?= $siswa->tanggal_lahir ? date('d/m/Y', strtotime($siswa->tanggal_lahir)) : '-' ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Jenis Kelamin</td>
                                        <td class="fw-semibold"><?= $siswa->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan' ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-card border rounded-3 p-4 h-100">
                                <h6 class="fw-semibold mb-3 text-primary">Data Akademik</h6>
                                <table class="table table-borderless mb-0">
                                    <tr>
                                        <td width="40%" class="text-muted">Kelas</td>
                                        <td width="60%" class="fw-semibold"><?= $kelas->nama_kelas ?? '-' ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Jurusan</td>
                                        <td class="fw-semibold"><?= $kelas->jurusan ?? 'IPA' ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Tahun Masuk</td>
                                        <td class="fw-semibold"><?= $siswa->tahun_masuk ?? '-' ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Wali Kelas</td>
                                        <td class="fw-semibold"><?= $kelas->wali_kelas ?? '-' ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Stats -->
                <div class="quick-stats-section mb-5">
                    <h4 class="fw-bold mb-4 text-dark" style="border-left: 4px solid #4e73df; padding-left: 15px;">
                        <i class="bi bi-graph-up me-2"></i>Ringkasan Pembayaran
                    </h4>
                    
                    <div class="row g-4">
                        <div class="col-xl-3 col-md-6">
                            <div class="stat-card bg-primary bg-opacity-5 border border-primary border-opacity-10 rounded-3 p-4 text-center">
                                <div class="stat-icon bg-primary bg-opacity-10 rounded-circle p-3 mb-3 d-inline-block">
                                    <i class="bi bi-receipt text-primary fa-2x"></i>
                                </div>
                                <h3 class="fw-bold text-white mb-2"><?= count($pembayaran) ?></h3>
                                <p class="text-white mb-0">Total Transaksi</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="stat-card bg-success bg-opacity-5 border border-success border-opacity-10 rounded-3 p-4 text-center">
                                <div class="stat-icon bg-success bg-opacity-10 rounded-circle p-3 mb-3 d-inline-block">
                                    <i class="bi bi-check-circle text-success fa-2x"></i>
                                </div>
                                <h3 class="fw-bold text-white mb-2">
                                    <?php
                                    $lunas_count = array_reduce($pembayaran, function($carry, $item) {
                                        return $carry + (($item->status_pembayaran ?? 'Belum Lunas') == 'Lunas' ? 1 : 0);
                                    }, 0);
                                    echo $lunas_count;
                                    ?>
                                </h3>
                                <p class="text-white mb-0">Status Lunas</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="stat-card bg-warning bg-opacity-5 border border-warning border-opacity-10 rounded-3 p-4 text-center">
                                <div class="stat-icon bg-warning bg-opacity-10 rounded-circle p-3 mb-3 d-inline-block">
                                    <i class="bi bi-clock-history text-warning fa-2x"></i>
                                </div>
                                <h3 class="fw-bold text-white mb-2">
                                    <?php
                                    $belum_lunas_count = array_reduce($pembayaran, function($carry, $item) {
                                        return $carry + (($item->status_pembayaran ?? 'Belum Lunas') == 'Belum Lunas' ? 1 : 0);
                                    }, 0);
                                    echo $belum_lunas_count;
                                    ?>
                                </h3>
                                <p class="text-white mb-0">Belum Lunas</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="stat-card bg-danger bg-opacity-5 border border-danger border-opacity-10 rounded-3 p-4 text-center">
                                <div class="stat-icon bg-danger bg-opacity-10 rounded-circle p-3 mb-3 d-inline-block">
                                    <i class="bi bi-x-circle text-danger fa-2x"></i>
                                </div>
                                <?php
                                $total_pembayaran = count($pembayaran);
                                $ditolak_count = $total_pembayaran - $lunas_count - $belum_lunas_count;
                                ?>
                                <h3 class="fw-bold text-white mb-2"><?= $ditolak_count ?></h3>
                                <p class="text-white mb-0">Ditolak</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Total Amount -->
                    <div class="total-amount-card mt-4 p-4 bg-light border rounded-3">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h6 class="text-muted mb-2">Total Nominal Dibayar</h6>
                                <h3 class="fw-bold text-success mb-0">
                                    <?php
                                    $total_bayar = 0;
                                    foreach($pembayaran as $payment) {
                                        $total_bayar += $payment->jumlah_bayar;
                                    }
                                    ?>
                                    Rp <?= number_format($total_bayar, 0, ',', '.') ?>
                                </h3>
                            </div>
                            <div class="col-md-4 text-md-end">
                                <div class="nominal-spp bg-primary bg-opacity-10 rounded-3 p-3 d-inline-block">
                                    <small class="text-muted d-block">Nominal SPP</small>
                                    <span class="fw-bold text-primary">Rp <?= number_format($spp->nominal ?? 0, 0, ',', '.') ?>/bulan</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Detailed Payment History -->
                <div class="payment-history-section mb-5">
                    <h4 class="fw-bold mb-4 text-dark" style="border-left: 4px solid #4e73df; padding-left: 15px;">
                        <i class="bi bi-list-check me-2"></i>Detail Riwayat Pembayaran
                    </h4>
                    
                    <?php if(empty($pembayaran)): ?>
                        <div class="empty-state text-center py-5 my-4">
                            <div class="empty-icon bg-light rounded-3 p-4 d-inline-block mb-3">
                                <i class="bi bi-receipt text-muted fa-4x"></i>
                            </div>
                            <h5 class="text-muted mb-3">Belum ada riwayat pembayaran</h5>
                            <p class="text-muted mb-0">Tidak ada transaksi pembayaran yang tercatat</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive-lg">
                            <table class="table table-bordered table-hover mb-4">
                                <thead class="table-light">
                                    <tr>
                                        <th class="py-3 px-4 text-center" style="width: 50px;">No</th>
                                        <th class="py-3 px-4" style="min-width: 150px;">Periode</th>
                                        <th class="py-3 px-4" style="min-width: 120px;">Tanggal Bayar</th>
                                        <th class="py-3 px-4 text-end" style="min-width: 150px;">Jumlah Bayar</th>
                                        <th class="py-3 px-4 text-center" style="min-width: 100px;">Metode</th>
                                        <th class="py-3 px-4" style="min-width: 120px;">Petugas</th>
                                        <th class="py-3 px-4 text-center" style="min-width: 120px;">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $total_bayar = 0;
                                    foreach($pembayaran as $index => $payment):
                                        $total_bayar += $payment->jumlah_bayar;

                                        // Determine status
                                        $status = $payment->status_pembayaran ?? 'Belum Lunas';
                                        if ($status == 'Lunas') {
                                            $badge_class = 'badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2';
                                            $status_text = 'Lunas';
                                        } elseif ($status == 'Belum Lunas') {
                                            $badge_class = 'badge bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25 px-3 py-2';
                                            $status_text = 'Belum Lunas';
                                        } else {
                                            $badge_class = 'badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-3 py-2';
                                            $status_text = 'Ditolak';
                                        }
                                    ?>
                                    <tr>
                                        <td class="py-3 px-4 text-center"><?= $index + 1 ?></td>
                                        <td class="py-3 px-4">
                                            <div>
                                                <strong class="d-block"><?= $payment->bulan ?? '' ?></strong>
                                                <small class="text-muted">Tahun <?= $payment->tahun ?? '' ?></small>
                                            </div>
                                        </td>
                                        <td class="py-3 px-4">
                                            <?= date('d/m/Y', strtotime($payment->tanggal_bayar ?? '')) ?>
                                            <?php if($payment->created_at): ?>
                                                <small class="d-block text-muted">
                                                    <?= date('H:i', strtotime($payment->created_at)) ?> WIB
                                                </small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="py-3 px-4 text-end">
                                            <span class="fw-bold text-success">
                                                Rp <?= number_format($payment->jumlah_bayar ?? 0, 0, ',', '.') ?>
                                            </span>
                                        </td>
                                        <td class="py-3 px-4 text-center">
                                            <span class="badge bg-info bg-opacity-10 text-info border border-info border-opacity-25 px-3 py-2">
                                                <?= $payment->metode_pembayaran ?? 'Tunai' ?>
                                            </span>
                                        </td>
                                        <td class="py-3 px-4">
                                            <div class="d-flex align-items-center">
                                                <div class="bg-light rounded-circle p-2 me-2">
                                                    <i class="bi bi-person text-muted"></i>
                                                </div>
                                                <div>
                                                    <div class="fw-semibold"><?= $payment->petugas ?? 'Admin' ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="py-3 px-4 text-center">
                                            <span class="<?= $badge_class ?> rounded-pill">
                                                <?= $status_text ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    
                                    <!-- Total Row -->
                                    <tr class="table-light fw-bold">
                                        <td colspan="3" class="py-3 px-4 text-center">TOTAL</td>
                                        <td class="py-3 px-4 text-end text-success">
                                            Rp <?= number_format($total_bayar, 0, ',', '.') ?>
                                        </td>
                                        <td colspan="3" class="py-3 px-4 text-center">
                                            <?= count($pembayaran) ?> transaksi
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Statistics by Year -->
                <?php if(!empty($pembayaran)): ?>
                <div class="statistics-section mb-5">
                    <h4 class="fw-bold mb-4 text-dark" style="border-left: 4px solid #4e73df; padding-left: 15px;">
                        <i class="bi bi-bar-chart me-2"></i>Statistik per Tahun
                    </h4>
                    
                    <?php
                    // Group by tahun
                    $grouped_by_tahun = [];
                    foreach($pembayaran as $payment) {
                        $tahun = $payment->tahun ?? '';
                        if(!isset($grouped_by_tahun[$tahun])) {
                            $grouped_by_tahun[$tahun] = [
                                'total' => 0,
                                'count' => 0,
                                'lunas' => 0,
                                'pending' => 0,
                                'ditolak' => 0
                            ];
                        }
                        $grouped_by_tahun[$tahun]['total'] += $payment->jumlah_bayar;
                        $grouped_by_tahun[$tahun]['count']++;

                        $status = $payment->status_pembayaran ?? 'Belum Lunas';
                        if($status == 'Lunas') {
                            $grouped_by_tahun[$tahun]['lunas']++;
                        } elseif($status == 'Belum Lunas') {
                            $grouped_by_tahun[$tahun]['pending']++;
                        } else {
                            $grouped_by_tahun[$tahun]['ditolak']++;
                        }
                    }
                    
                    krsort($grouped_by_tahun); // Sort tahun descending
                    ?>
                    
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th class="py-3 px-4">Tahun</th>
                                    <th class="py-3 px-4 text-center">Jumlah Transaksi</th>
                                    <th class="py-3 px-4 text-center">Status Lunas</th>
                                    <th class="py-3 px-4 text-center">Belum Lunas</th>
                                    <th class="py-3 px-4 text-center">Ditolak</th>
                                    <th class="py-3 px-4 text-end">Total Nominal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($grouped_by_tahun as $tahun => $data): ?>
                                <tr>
                                    <td class="py-3 px-4 fw-semibold"><?= $tahun ?></td>
                                    <td class="py-3 px-4 text-center"><?= $data['count'] ?></td>
                                    <td class="py-3 px-4 text-center">
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2">
                                            <?= $data['lunas'] ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 text-center">
                                        <span class="badge bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25 px-3 py-2">
                                            <?= $data['pending'] ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 text-center">
                                        <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-3 py-2">
                                            <?= $data['ditolak'] ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 text-end fw-bold text-success">
                                        Rp <?= number_format($data['total'], 0, ',', '.') ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Notes and Signatures -->
                <div class="notes-section mt-5">
                    <div class="row g-4">
                        <div class="col-lg-8">
                            <div class="info-box bg-light border rounded-3 p-4 h-100">
                                <h6 class="fw-semibold mb-3 text-primary">
                                    <i class="bi bi-info-circle me-2"></i>Keterangan dan Catatan
                                </h6>
                                <ul class="mb-0 small ps-3">
                                    <li class="mb-2">Laporan ini dicetak secara otomatis oleh sistem pembayaran SPP</li>
                                    <li class="mb-2">Status "Lunas" berarti pembayaran telah dikonfirmasi oleh petugas</li>
                                    <li class="mb-2">Status "Belum Lunas" berarti pembayaran belum diverifikasi</li>
                                    <li class="mb-2">Status "Ditolak" berarti pembayaran tidak dapat diproses</li>
                                    <li class="mb-2">Untuk pertanyaan atau koreksi, hubungi petugas administrasi</li>
                                    <li>Dokumen ini sah dan dapat digunakan sebagai bukti pembayaran</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="timestamp-box border rounded-3 p-4 h-100">
                                <h6 class="fw-semibold mb-3 text-primary">
                                    <i class="bi bi-calendar-check me-2"></i>Informasi Cetak
                                </h6>
                                <div class="timestamp-info">
                                    <small class="text-muted d-block mb-1">Dicetak pada:</small>
                                    <p class="fw-semibold mb-3"><?= date('d F Y, H:i:s') ?></p>
                                    
                                    <small class="text-muted d-block mb-1">Oleh:</small>
                                    <p class="fw-semibold mb-0"><?= session()->get('nama_lengkap') ?? 'Siswa' ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Signatures -->
                <div class="signatures-section mt-5 pt-5 border-top">
                    <div class="row">
                        <div class="col-md-4 text-center mb-4 mb-md-0">
                            <div class="signature-card border rounded-3 p-4 h-100">
                                <p class="mb-4">Petugas Administrasi,</p>
                                <div class="signature-placeholder border-top pt-3">
                                    <p class="fw-semibold mb-1"><?= session()->get('nama_lengkap') ?? 'Administrator' ?></p>
                                    <small class="text-muted"><?= session()->get('nisn') ?? 'NISN' ?></small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 text-center mb-4 mb-md-0">
                            <div class="signature-card border rounded-3 p-4 h-100">
                                <p class="mb-4">Orang Tua/Wali,</p>
                                <div class="signature-placeholder border-top pt-3">
                                    <p class="text-muted mb-1">___________________</p>
                                    <small class="text-muted">Tanda tangan & stempel</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 text-center">
                            <div class="signature-card border rounded-3 p-4 h-100">
                                <p class="mb-4">Kepala Sekolah,</p>
                                <div class="signature-placeholder border-top pt-3">
                                    <p class="text-muted mb-1">___________________</p>
                                    <small class="text-muted">Tanda tangan & stempel</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <div class="report-footer mt-5 pt-4 border-top text-center">
                    <p class="text-muted mb-2 small">
                        Laporan Pembayaran SPP | Sistem Informasi Sekolah
                    </p>
                    <p class="text-muted mb-0 small">
                        Halaman 1 dari 1 | <?= date('d/m/Y H:i:s') ?> | Dokumen ini sah dan dapat digunakan sebagai bukti
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    .icon-header {
        transition: all 0.3s ease;
    }
    
    .icon-header:hover {
        transform: rotate(10deg) scale(1.1);
    }
    
    .stat-card {
        transition: all 0.3s ease;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    .stat-icon {
        transition: all 0.3s ease;
    }
    
    .stat-card:hover .stat-icon {
        transform: scale(1.1);
    }
    
    .info-card {
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }
    
    .info-card:hover {
        border-color: rgba(78, 115, 223, 0.2);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    }
    
    .total-amount-card {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        border: 2px solid #dee2e6;
    }
    
    .table thead th {
        background-color: #f8f9fc;
        border-bottom: 2px solid #e3e6f0;
        color: #4e73df;
        font-weight: 700;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .table tbody tr {
        transition: all 0.2s ease;
    }
    
    .table tbody tr:hover {
        background-color: rgba(78, 115, 223, 0.05);
    }
    
    .badge {
        font-weight: 600;
        letter-spacing: 0.3px;
    }
    
    .signature-card {
        transition: all 0.3s ease;
        background: linear-gradient(135deg, rgba(248, 249, 250, 0.5), rgba(233, 236, 239, 0.3));
    }
    
    .signature-card:hover {
        border-color: #4e73df;
        transform: translateY(-3px);
    }
    
    .timestamp-box {
        background: linear-gradient(135deg, rgba(248, 249, 250, 0.8), rgba(233, 236, 239, 0.6));
    }
    
    /* Print specific styles */
    @media print {
        body * {
            visibility: hidden;
        }
        
        #printArea, #printArea * {
            visibility: visible;
        }
        
        #printArea {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            padding: 20px;
            background: white;
        }
        
        .no-print {
            display: none !important;
        }
        
        .table-bordered th,
        .table-bordered td {
            border: 1px solid #ddd !important;
        }
        
        .badge {
            border: 1px solid currentColor !important;
        }
    }
    
    /* Responsive adjustments */
    @media (min-width: 1200px) {
        .container-fluid {
            max-width: 1400px;
        }
        
        .print-container {
            margin: 0 auto;
            max-width: 1000px;
        }
    }
    
    @media (max-width: 768px) {
        .school-logo .logo-placeholder {
            padding: 2rem !important;
        }
        
        .report-title h1 {
            font-size: 24px !important;
        }
        
        .stat-card {
            margin-bottom: 1rem;
        }
        
        .d-flex.gap-2 {
            gap: 0.5rem !important;
        }
    }
    
    /* Animation for report elements */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .card {
        animation: fadeIn 0.5s ease-out;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<script>
// Print function with options
function printReport(type = 'full') {
    // Get print area content
    const printArea = document.getElementById('printArea');
    const originalContent = printArea.innerHTML;
    
    // Modify content based on print type
    let modifiedContent = originalContent;
    
    if (type === 'simple') {
        // Remove detailed table and statistics
        modifiedContent = modifiedContent.replace(
            /<!-- Detailed Payment History -->[\s\S]*?<!-- Statistics by Year -->/,
            ''
        );
    } else if (type === 'table') {
        // Keep only header and table
        modifiedContent = modifiedContent.replace(
            /<!-- Student Information -->[\s\S]*?<!-- Detailed Payment History -->/,
            '<div class="mt-3"></div>'
        );
        modifiedContent = modifiedContent.replace(
            /<!-- Statistics by Year -->[\s\S]*?<!-- Notes and Signatures -->/,
            ''
        );
    }
    
    // Create print document
    const printWindow = window.open('', '_blank', 'width=900,height=600');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Laporan Pembayaran SPP - <?= $siswa->nama_siswa ?? 'Siswa' ?></title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
            <style>
                @page {
                    size: A4 portrait;
                    margin: 20mm;
                }
                
                body {
                    font-family: 'Arial', sans-serif;
                    font-size: 12pt;
                    line-height: 1.5;
                    color: #000;
                    background: white !important;
                    padding: 20px;
                }
                
                .report-header {
                    border-bottom: 3px double #000;
                    padding-bottom: 20px;
                    margin-bottom: 30px;
                }
                
                .report-title h1 {
                    font-size: 24pt;
                    border-bottom: 2px solid #000;
                }
                
                .table {
                    border-collapse: collapse;
                    width: 100%;
                    margin-bottom: 20px;
                }
                
                .table th,
                .table td {
                    padding: 8px;
                    border: 1px solid #ddd;
                }
                
                .table th {
                    background-color: #f8f9fa !important;
                    font-weight: bold;
                }
                
                .badge {
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 10pt;
                    font-weight: bold;
                }
                
                .signatures-section {
                    margin-top: 50px;
                }
                
                .signature-placeholder {
                    margin-top: 60px;
                }
                
                @media print {
                    .no-print {
                        display: none !important;
                    }
                    
                    body {
                        padding: 0;
                    }
                    
                    .page-break {
                        page-break-before: always;
                    }
                }
            </style>
        </head>
        <body onload="window.print(); setTimeout(() => window.close(), 1000);">
            ${modifiedContent}
        </body>
        </html>
    `);
    printWindow.document.close();
}

// Export to PDF
function exportToPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('p', 'pt', 'a4');
    
    // Add school header
    doc.setFontSize(20);
    doc.setTextColor(40, 40, 40);
    doc.text("SMA NEGERI 1 SUNGAYANG", 40, 40);
    
    doc.setFontSize(12);
    doc.text("SUNGAYANG, TANAH DATAR", 40, 60);
    
    // Add report title
    doc.setFontSize(24);
    doc.setTextColor(78, 115, 223);
    doc.text("LAPORAN RIWAYAT PEMBAYARAN SPP", 40, 100);
    
    // Add student info
    doc.setFontSize(12);
    doc.setTextColor(40, 40, 40);
    doc.text(`Nama: <?= $siswa->nama_siswa ?? '-' ?>`, 40, 130);
    doc.text(`NISN: <?= $siswa->nisn ?? '-' ?>`, 40, 145);
    doc.text(`Kelas: <?= $kelas->nama_kelas ?? '-' ?>`, 40, 160);
    doc.text(`Tahun Ajaran: <?= $spp->tahun_ajaran ?? date('Y') . '/' . (date('Y') + 1) ?>`, 40, 175);
    
    // Create table data
    const tableData = [];
    <?php foreach($pembayaran as $index => $payment): ?>
        tableData.push([
            '<?= $index + 1 ?>',
            '<?= $payment->bulan ?? '' ?> <?= $payment->tahun ?? '' ?>',
            '<?= date('d/m/Y', strtotime($payment->tanggal_bayar ?? '')) ?>',
            'Rp <?= number_format($payment->jumlah_bayar ?? 0, 0, ',', '.') ?>',
            '<?= $payment->metode_pembayaran ?? 'Tunai' ?>',
            '<?= $payment->petugas ?? 'Admin' ?>',
            '<?= $payment->status_pembayaran ?? 'Belum Lunas' ?>'
        ]);
    <?php endforeach; ?>
    
    // Add table
    doc.autoTable({
        head: [['No', 'Periode', 'Tanggal', 'Jumlah', 'Metode', 'Petugas', 'Status']],
        body: tableData,
        startY: 200,
        theme: 'grid',
        styles: {
            fontSize: 9,
            cellPadding: 5
        },
        headStyles: {
            fillColor: [78, 115, 223],
            textColor: 255
        }
    });
    
    // Add total
    const finalY = doc.lastAutoTable.finalY || 200;
    doc.setFontSize(11);
    doc.setFont(undefined, 'bold');
    doc.text(`Total Transaksi: <?= count($pembayaran) ?>`, 40, finalY + 20);
    doc.text(`Total Nominal: Rp <?= number_format($total_bayar ?? 0, 0, ',', '.') ?>`, 40, finalY + 35);
    
    // Add footer
    doc.setFontSize(8);
    doc.setTextColor(100, 100, 100);
    doc.text(`Dicetak pada: <?= date('d/m/Y H:i:s') ?>`, 40, doc.internal.pageSize.height - 40);
    doc.text(`Oleh: <?= session()->get('nama_lengkap') ?? 'Siswa' ?>`, 40, doc.internal.pageSize.height - 30);
    
    // Save PDF
    doc.save('Laporan-SPP-<?= $siswa->nama_siswa ?? 'Siswa' ?>.pdf');
}

// Export to Excel
function exportToExcel() {
    // Create HTML table for Excel
    let excelContent = `
        <table border="1">
            <tr>
                <th colspan="7" style="background-color:#4e73df;color:white;font-size:16pt;padding:10px;">
                    LAPORAN PEMBAYARAN SPP - <?= $siswa->nama_siswa ?? 'Siswa' ?>
                </th>
            </tr>
            <tr>
                <td colspan="7">
                    <strong>Nama:</strong> <?= $siswa->nama_siswa ?? '-' ?> | 
                    <strong>NISN:</strong> <?= $siswa->nisn ?? '-' ?> | 
                    <strong>Kelas:</strong> <?= $kelas->nama_kelas ?? '-' ?> | 
                    <strong>Tahun Ajaran:</strong> <?= $spp->tahun_ajaran ?? date('Y') . '/' . (date('Y') + 1) ?>
                </td>
            </tr>
            <tr>
                <th>No</th>
                <th>Bulan/Tahun</th>
                <th>Tanggal Bayar</th>
                <th>Jumlah Bayar</th>
                <th>Metode</th>
                <th>Petugas</th>
                <th>Status</th>
            </tr>
    `;
    
    <?php foreach($pembayaran as $index => $payment): ?>
        excelContent += `
            <tr>
                <td><?= $index + 1 ?></td>
                <td><?= $payment->bulan ?? '' ?> <?= $payment->tahun ?? '' ?></td>
                <td><?= date('d/m/Y', strtotime($payment->tanggal_bayar ?? '')) ?></td>
                <td>Rp <?= number_format($payment->jumlah_bayar ?? 0, 0, ',', '.') ?></td>
                <td><?= $payment->metode_pembayaran ?? 'Tunai' ?></td>
                <td><?= $payment->petugas ?? 'Admin' ?></td>
                <td><?= $payment->status_pembayaran ?? 'Belum Lunas' ?></td>
            </tr>
        `;
    <?php endforeach; ?>
    
    excelContent += `
        <tr>
            <td colspan="3" style="text-align:center;font-weight:bold;">TOTAL</td>
            <td style="font-weight:bold;color:green;">Rp <?= number_format($total_bayar ?? 0, 0, ',', '.') ?></td>
            <td colspan="3"><?= count($pembayaran) ?> transaksi</td>
        </tr>
        <tr>
            <td colspan="7" style="font-size:9pt;color:#666;padding:10px;">
                Dicetak pada: <?= date('d/m/Y H:i:s') ?> | 
                Oleh: <?= session()->get('nama_lengkap') ?? 'Siswa' ?>
            </td>
        </tr>
    </table>
    `;
    
    // Create blob and download
    const blob = new Blob([excelContent], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Laporan-SPP-<?= $siswa->nama_siswa ?? 'Siswa' ?>.xls';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Initialize print options
document.addEventListener('DOMContentLoaded', function() {
    // Add print button listeners
    const printButtons = document.querySelectorAll('[onclick^="printReport"]');
    printButtons.forEach(button => {
        const originalOnClick = button.getAttribute('onclick');
        button.removeAttribute('onclick');
        button.addEventListener('click', function() {
            const type = originalOnClick.match(/printReport\('(\w+)'\)/)?.[1] || 'full';
            printReport(type);
        });
    });
    
    // Add keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl+P to print
        if (e.ctrlKey && e.key === 'p') {
            e.preventDefault();
            printReport();
        }
        
        // Ctrl+E to export to Excel
        if (e.ctrlKey && e.key === 'e') {
            e.preventDefault();
            exportToExcel();
        }
        
        // Ctrl+D to export to PDF
        if (e.ctrlKey && e.key === 'd') {
            e.preventDefault();
            exportToPDF();
        }
    });
    
    // Show print preview on page load
    setTimeout(() => {
        const printArea = document.getElementById('printArea');
        if (printArea) {
            printArea.scrollIntoView({ behavior: 'smooth' });
        }
    }, 500);
});

// Add print status notification
function showPrintStatus(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0 position-fixed`;
    toast.style.cssText = `
        bottom: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 250px;
    `;
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    document.body.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast, { delay: 3000 });
    bsToast.show();
    
    toast.addEventListener('hidden.bs.toast', function() {
        document.body.removeChild(toast);
    });
}
</script>
<?= $this->endSection() ?>