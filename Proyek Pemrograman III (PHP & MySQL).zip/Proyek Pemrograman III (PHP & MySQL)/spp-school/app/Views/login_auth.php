<?= $this->extend('layout/auth'); ?>

<?= $this->section('content'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SPP SYSTEM</title>
    <style>
        /* CSS Kustom untuk Halaman Login Desktop */
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
            --success-color: #4cc9f0;
            --light-bg: #f8f9fa;
            --dark-text: #343a40;
            --shadow-color: rgba(67, 97, 238, 0.15);
            --gradient-primary: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%);
            --gradient-secondary: linear-gradient(135deg, #4cc9f0 0%, #4361ee 100%);
            --sidebar-width: 480px;
        }
        
        body {
            background: #f5f7ff;
            font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
            animation: fadeIn 1s ease;
            display: flex;
            margin: 0;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        /* Sidebar dengan background gradient */
        .login-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            width: var(--sidebar-width);
            background: var(--gradient-primary);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 3rem;
            z-index: 10;
            overflow: hidden;
            box-shadow: 5px 0 30px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-content {
            position: relative;
            z-index: 2;
            max-width: 400px;
        }
        
        .logo-container {
            margin-bottom: 3rem;
            animation: slideInLeft 1s ease;
        }
        
        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .logo {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .logo i {
            font-size: 3rem;
            background: rgba(255, 255, 255, 0.2);
            padding: 1rem;
            border-radius: 15px;
        }
        
        .tagline {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 0.5rem;
        }
        
        .version {
            font-size: 0.9rem;
            opacity: 0.7;
        }
        
        .feature-list {
            margin: 3rem 0;
            animation: slideInLeft 1s ease 0.3s both;
        }
        
        .feature-list h4 {
            font-size: 1.3rem;
            margin-bottom: 1.5rem;
            font-weight: 600;
        }
        
        .feature-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 1.5rem;
            opacity: 0.9;
        }
        
        .feature-item i {
            font-size: 1.2rem;
            margin-right: 1rem;
            margin-top: 0.2rem;
            color: #4cc9f0;
        }
        
        .feature-text h5 {
            font-size: 1rem;
            margin-bottom: 0.3rem;
            font-weight: 600;
        }
        
        .feature-text p {
            font-size: 0.9rem;
            opacity: 0.8;
            margin: 0;
        }
        
        /* Animasi background sidebar */
        .login-sidebar::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, 
                transparent 30%, 
                rgba(255, 255, 255, 0.05) 50%, 
                transparent 70%);
            animation: shine 10s infinite linear;
            z-index: 1;
        }
        
        @keyframes shine {
            0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
            100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
        }
        
        /* Main content area */
        .login-main {
            margin-left: var(--sidebar-width);
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            min-height: 100vh;
            background: #f5f7ff;
            position: relative;
        }
        
        /* Dekorasi background main */
        .login-main::before,
        .login-main::after {
            content: '';
            position: absolute;
            border-radius: 50%;
            z-index: 1;
            animation: float 8s ease-in-out infinite;
        }
        
        .login-main::before {
            width: 400px;
            height: 400px;
            background: var(--gradient-secondary);
            top: 10%;
            right: 10%;
            opacity: 0.08;
            animation-delay: 0s;
        }
        
        .login-main::after {
            width: 300px;
            height: 300px;
            background: var(--gradient-primary);
            bottom: 10%;
            left: 15%;
            opacity: 0.06;
            animation-delay: 2s;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-30px) rotate(180deg); }
        }
        
        /* Login card */
        .login-card {
            width: 100%;
            max-width: 420px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 50px rgba(67, 97, 238, 0.1);
            overflow: hidden;
            position: relative;
            z-index: 2;
            animation: slideInUp 0.8s ease;
            border: 1px solid rgba(67, 97, 238, 0.1);
        }
        
        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .login-card-header {
            background: white;
            padding: 2.5rem 2.5rem 1.5rem;
            border-bottom: 1px solid #eef2ff;
        }
        
        .login-card-header h3 {
            color: var(--primary-color);
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            text-align: center;
        }
        
        .login-card-header p {
            color: #666;
            text-align: center;
            margin-bottom: 0;
            font-size: 0.95rem;
        }
        
        .login-card-body {
            padding: 1.5rem 2.5rem 2.5rem;
        }
        
        /* Alert styling */
        .alert {
            border-radius: 12px;
            border: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.03);
            margin-bottom: 1.5rem;
            animation: fadeInDown 0.5s ease;
            padding: 1rem 1.25rem;
        }
        
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-info {
            background: #f0f8ff;
            border-left: 4px solid #4361ee;
            color: #4361ee;
        }
        
        .alert-info i {
            color: #4361ee;
        }
        
        /* Form styling */
        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
        }
        
        .form-label i {
            margin-right: 0.5rem;
            color: var(--primary-color);
        }
        
        .input-group {
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 2px solid #e0e7ff;
            background: white;
        }
        
        .input-group:focus-within {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(67, 97, 238, 0.1);
            transform: translateY(-2px);
        }
        
        .input-group:hover {
            border-color: #a5b4fc;
        }
        
        .input-group-text {
            background: #f8faff;
            border: none;
            color: var(--primary-color);
            font-size: 1.1rem;
            padding: 0.875rem 1rem;
        }
        
        .form-control {
            border: none;
            padding: 0.875rem 1rem;
            font-size: 1rem;
            background: transparent;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            box-shadow: none;
            background: transparent;
        }
        
        .form-control::placeholder {
            color: #94a3b8;
            font-size: 0.95rem;
        }
        
        /* Password toggle */
        #togglePassword {
            background: transparent;
            border: none;
            border-left: 1px solid #e0e7ff;
            color: #64748b;
            padding: 0 1rem;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        #togglePassword:hover {
            color: var(--primary-color);
            background: #f8faff;
        }
        
        /* Options row */
        .options-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 1.5rem 0;
        }
        
        .form-check {
            display: flex;
            align-items: center;
            margin: 0;
        }
        
        .form-check-input {
            width: 1.2em;
            height: 1.2em;
            margin-right: 0.75rem;
            cursor: pointer;
            border: 2px solid #cbd5e1;
        }
        
        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .form-check-input:focus {
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        .form-check-label {
            color: #475569;
            font-size: 0.95rem;
            cursor: pointer;
        }
        
        .forgot-link {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 0.95rem;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .forgot-link:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        /* Login button */
        .btn-login {
            background: var(--gradient-primary);
            border: none;
            color: white;
            padding: 1rem;
            font-weight: 600;
            font-size: 1rem;
            border-radius: 12px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            width: 100%;
            position: relative;
            overflow: hidden;
            margin-bottom: 1.5rem;
            letter-spacing: 0.5px;
        }
        
        .btn-login:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(67, 97, 238, 0.3);
        }
        
        .btn-login:active {
            transform: translateY(-1px);
        }
        
        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, 
                transparent, 
                rgba(255, 255, 255, 0.3), 
                transparent);
            transition: left 0.7s;
        }
        
        .btn-login:hover::before {
            left: 100%;
        }
        
        .btn-login i {
            margin-right: 0.5rem;
        }
        
        /* Register link */
        .register-link {
            text-align: center;
            padding-top: 1.5rem;
            border-top: 1px solid #eef2ff;
        }
        
        .register-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.95rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s;
        }
        
        .register-link a:hover {
            color: var(--secondary-color);
            gap: 0.75rem;
        }
        
        /* Footer */
        .login-footer {
            position: absolute;
            bottom: 2rem;
            right: 2rem;
            color: #94a3b8;
            font-size: 0.9rem;
            z-index: 2;
            animation: fadeIn 2s ease;
        }
        
        /* Spinner untuk loading */
        .spinner-border {
            vertical-align: middle;
            margin-right: 8px;
            border-width: 2px;
        }
        
        /* Animasi tambahan */
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(67, 97, 238, 0.4); }
            70% { box-shadow: 0 0 0 15px rgba(67, 97, 238, 0); }
            100% { box-shadow: 0 0 0 0 rgba(67, 97, 238, 0); }
        }
        
        .pulse-animation {
            animation: pulse 2s infinite;
        }
        
        /* Responsive untuk layar lebih kecil dari 1200px */
        @media (max-width: 1200px) {
            :root {
                --sidebar-width: 400px;
            }
            
            .login-sidebar {
                padding: 2rem;
            }
        }
        
        /* Responsive untuk layar laptop kecil (1024px) */
        @media (max-width: 1024px) {
            :root {
                --sidebar-width: 350px;
            }
            
            .login-sidebar {
                padding: 1.5rem;
            }
            
            .logo {
                font-size: 2rem;
            }
            
            .logo i {
                font-size: 2.5rem;
                padding: 0.75rem;
            }
            
            .feature-list {
                margin: 2rem 0;
            }
            
            .login-card {
                max-width: 380px;
            }
        }
        
        /* Responsive untuk tablet */
        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .login-sidebar {
                position: relative;
                width: 100%;
                height: auto;
                padding: 2rem;
                box-shadow: none;
            }
            
            .login-main {
                margin-left: 0;
                padding: 2rem 1rem;
                min-height: auto;
            }
            
            .login-main::before,
            .login-main::after {
                display: none;
            }
            
            .login-card {
                max-width: 100%;
                margin: 0 auto;
            }
            
            .login-footer {
                position: relative;
                bottom: auto;
                right: auto;
                text-align: center;
                margin-top: 2rem;
                padding: 1rem;
                width: 100%;
            }
        }
        
        /* Responsive untuk mobile */
        @media (max-width: 480px) {
            .login-sidebar {
                padding: 1.5rem;
            }
            
            .login-card-header {
                padding: 2rem 1.5rem 1rem;
            }
            
            .login-card-body {
                padding: 1rem 1.5rem 2rem;
            }
            
            .options-row {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="login-sidebar">
        <div class="sidebar-content">
            <div class="logo-container">
                <div class="logo">
                    <i class="bi bi-cash-stack"></i>
                    <div>
                        <div>SPP SYSTEM</div>
                        <div class="tagline">Sistem Pembayaran SPP Digital</div>
                        <div class="version">v1.0.0 | Kelompok 3</div>
                    </div>
                </div>
            </div>
            
            <div class="feature-list">
                <h4>Mengapa SPP SYSTEM?</h4>
                
                <div class="feature-item">
                    <i class="bi bi-shield-check"></i>
                    <div class="feature-text">
                        <h5>Keamanan Terjamin</h5>
                        <p>Sistem terenkripsi dengan teknologi terkini</p>
                    </div>
                </div>
                
                <div class="feature-item">
                    <i class="bi bi-lightning-charge"></i>
                    <div class="feature-text">
                        <h5>Proses Cepat</h5>
                        <p>Pembayaran SPP hanya dalam beberapa klik</p>
                    </div>
                </div>
                
                <div class="feature-item">
                    <i class="bi bi-graph-up"></i>
                    <div class="feature-text">
                        <h5>Laporan Lengkap</h5>
                        <p>Monitoring pembayaran real-time</p>
                    </div>
                </div>
                
                <div class="feature-item">
                    <i class="bi bi-phone"></i>
                    <div class="feature-text">
                        <h5>Akses Multi-Device</h5>
                        <p>Bisa diakses dari laptop, tablet, dan smartphone</p>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: auto;">
                <div class="feature-item">
                    <i class="bi bi-headset"></i>
                    <div class="feature-text">
                        <h5>Bantuan 24/7</h5>
                        <p>Tim support siap membantu kapan saja</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="login-main">
        <div class="login-card">
            <div class="login-card-header">
                <h3>Masuk ke Akun Anda</h3>
                <p>Akses sistem pembayaran SPP sekolah</p>
            </div>
            
            <div class="login-card-body">
                <!-- Informasi login -->
                <div class="alert alert-info">
                    <div style="display: flex; align-items: flex-start; gap: 0.75rem;">
                        <i class="bi bi-info-circle" style="font-size: 1.1rem; margin-top: 0.1rem;"></i>
                        <div>
                            <strong style="display: block; margin-bottom: 0.25rem;">Cara Login:</strong>
                            <small style="line-height: 1.5;">
                                • <strong>Admin/Petugas:</strong> Username atau Email<br>
                                • <strong>Siswa:</strong> NISN (10 digit angka)<br>
                                • <strong>Password default siswa:</strong> NISN
                            </small>
                        </div>
                    </div>
                </div>
                
                <?php if(session()->getFlashdata('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show d-flex align-items-center">
                        <i class="bi bi-check-circle me-2"></i>
                        <div><?= session()->getFlashdata('success') ?></div>
                        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <div><?= session()->getFlashdata('error') ?></div>
                        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('info')): ?>
                    <div class="alert alert-info alert-dismissible fade show d-flex align-items-center">
                        <i class="bi bi-info-circle me-2"></i>
                        <div><?= session()->getFlashdata('info') ?></div>
                        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php 
                $errors = session()->getFlashdata('errors');
                if($errors && !empty($errors)): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="bi bi-x-circle me-2"></i>
                        <div>
                            <strong style="display: block; margin-bottom: 0.5rem;">Kesalahan Input:</strong>
                            <ul class="mb-0" style="padding-left: 1.25rem;">
                                <?php foreach($errors as $error): ?>
                                    <li><?= $error ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <form action="<?= base_url('/login') ?>" method="POST" id="loginForm">
                    <?= csrf_field() ?>
                    
                    <div class="mb-4">
                        <label for="username" class="form-label">
                            <i class="bi bi-person"></i> Username, Email, atau NISN
                        </label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person-circle"></i></span>
                            <input type="text" class="form-control" 
                                   id="username" name="username" value="<?= old('username') ?>" 
                                   placeholder="Username/Email untuk Admin/Petugas, NISN untuk Siswa" 
                                   required autofocus>
                        </div>
                        <small class="text-muted mt-1 d-block">
                            <i class="bi bi-info-circle me-1"></i> Siswa: gunakan 10 digit NISN
                        </small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">
                            <i class="bi bi-lock"></i> Password
                        </label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-key"></i></span>
                            <input type="password" class="form-control" 
                                   id="password" name="password" placeholder="Masukkan password" required>
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                        <small class="text-muted mt-1 d-block">
                            <i class="bi bi-key me-1"></i> Password default siswa: NISN
                        </small>
                    </div>
                    
                    <div class="options-row">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="remember" name="remember" value="1">
                            <label class="form-check-label" for="remember">Ingat saya di perangkat ini</label>
                        </div>
                        
                        <a href="<?= base_url('/forgot-password') ?>" class="forgot-link">
                            <i class="bi bi-question-circle me-1"></i> Lupa password?
                        </a>
                    </div>
                    
                    <button type="submit" class="btn-login" id="loginBtn">
                        <i class="bi bi-box-arrow-in-right"></i> Masuk ke Sistem
                    </button>
                    
                    <div class="register-link">
                        <a href="<?= base_url('/register') ?>">
                            <i class="bi bi-person-plus"></i> Belum punya akun? Daftar sekarang
                            <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="login-footer">
            <small>
                &copy; <?= date('Y') ?> UAS Pemrograman III - Kelompok 1 | Sistem Pembayaran SPP
            </small>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle password visibility
    const togglePassword = document.getElementById('togglePassword');
    const password = document.getElementById('password');
    
    if (togglePassword && password) {
        togglePassword.addEventListener('click', function() {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            
            const icon = this.querySelector('i');
            if (type === 'password') {
                icon.className = 'bi bi-eye';
            } else {
                icon.className = 'bi bi-eye-slash';
            }
            
            // Tambahkan animasi tombol
            this.classList.add('pulse-animation');
            setTimeout(() => {
                this.classList.remove('pulse-animation');
            }, 600);
        });
    }
    
    // Auto-focus username field dengan efek
    const usernameField = document.getElementById('username');
    if (usernameField && !usernameField.value) {
        setTimeout(() => {
            usernameField.focus();
            usernameField.parentElement.classList.add('pulse-animation');
            setTimeout(() => {
                usernameField.parentElement.classList.remove('pulse-animation');
            }, 2000);
        }, 500);
    }
    
    // Efek hover pada input fields
    const inputGroups = document.querySelectorAll('.input-group');
    inputGroups.forEach(group => {
        const input = group.querySelector('input');
        
        if (input) {
            input.addEventListener('focus', function() {
                group.style.transform = 'translateY(-2px)';
                group.style.boxShadow = '0 10px 25px rgba(67, 97, 238, 0.1)';
            });
            
            input.addEventListener('blur', function() {
                group.style.transform = 'translateY(0)';
                group.style.boxShadow = 'none';
            });
            
            group.addEventListener('mouseenter', function() {
                if (document.activeElement !== input) {
                    this.style.transform = 'translateY(-2px)';
                    this.style.boxShadow = '0 5px 15px rgba(67, 97, 238, 0.08)';
                }
            });
            
            group.addEventListener('mouseleave', function() {
                if (document.activeElement !== input) {
                    this.style.transform = 'translateY(0)';
                    this.style.boxShadow = 'none';
                }
            });
        }
    });
    
    // Login form validation
    const loginForm = document.getElementById('loginForm');
    const loginBtn = document.getElementById('loginBtn');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            // Validasi
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            
            if (!username || !password) {
                e.preventDefault();
                
                // Tambahkan animasi shake pada input yang kosong
                if (!username) {
                    usernameField.parentElement.classList.add('pulse-animation');
                    setTimeout(() => {
                        usernameField.parentElement.classList.remove('pulse-animation');
                    }, 1000);
                }
                
                if (!password) {
                    password.parentElement.classList.add('pulse-animation');
                    setTimeout(() => {
                        password.parentElement.classList.remove('pulse-animation');
                    }, 1000);
                }
                
                return false;
            }
            
            // Disable button and show loading
            if (loginBtn) {
                loginBtn.disabled = true;
                loginBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Memproses...';
                
                // Animasi button saat loading
                loginBtn.style.opacity = '0.8';
                loginBtn.style.cursor = 'not-allowed';
            }
            
            return true;
        });
    }
    
    // Animasi saat halaman dimuat
    setTimeout(() => {
        const loginCard = document.querySelector('.login-card');
        if (loginCard) {
            loginCard.classList.add('pulse-animation');
            setTimeout(() => {
                loginCard.classList.remove('pulse-animation');
            }, 2000);
        }
    }, 300);
    
    // Deteksi enter untuk submit form
    if (usernameField) {
        usernameField.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const passwordField = document.getElementById('password');
                if (passwordField) {
                    passwordField.focus();
                }
            }
        });
    }
    
    if (password) {
        password.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                if (loginForm) {
                    loginForm.requestSubmit();
                }
            }
        });
    }
    
    // Tambahkan animasi hover pada card
    const card = document.querySelector('.login-card');
    if (card) {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 25px 60px rgba(67, 97, 238, 0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 20px 50px rgba(67, 97, 238, 0.1)';
        });
    }
});
</script>
</body>
</html>
<?= $this->endSection(); ?>