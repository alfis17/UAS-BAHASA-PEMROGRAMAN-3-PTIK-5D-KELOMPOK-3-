<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// =================== PUBLIC ROUTES ===================
$routes->group('', ['filter' => 'noauth'], function($routes) {
    // Auth routes
    $routes->get('/', 'Auth::login');
    $routes->get('login', 'Auth::login');
    $routes->post('login', 'Auth::processLogin');
    $routes->get('register', 'Auth::register');
    $routes->post('register', 'Auth::processRegister');
    $routes->post('auth/processRegister', 'Auth::processRegister');
    $routes->get('forgot-password', 'Auth::forgotPassword');
    $routes->post('forgot-password', 'Auth::processForgotPassword');
    $routes->get('reset-password/(:any)', 'Auth::resetPassword/$1');
    $routes->post('reset-password/(:any)', 'Auth::processResetPassword/$1');
});

// =================== AUTHENTICATED ROUTES ===================
$routes->group('', ['filter' => 'auth'], function($routes) {
$routes->get('debug/structure', 'Laporan::debug_structure', ['filter' => 'role:admin']);  
$routes->get('debug/full', 'Laporan::debug_full', ['filter' => 'role:admin']);  
    // ===== DASHBOARD =====
    $routes->get('dashboard', 'Dashboard::index');
    $routes->get('admin/dashboard', 'Admin::dashboard', ['filter' => 'role:admin']);
    $routes->get('admin/dashboard_admin', 'Admin::dashboard', ['filter' => 'role:admin']); // Tambahkan alias
    
    // ===== LOGOUT =====
    $routes->get('logout', 'Auth::logout');
    
    // ===== ADMIN MANAGEMENT =====
    $routes->group('admin', ['filter' => 'role:admin'], function($routes) {
       
        $routes->get('index_laporan', 'Admin::index_laporan');
        
        // User Management
        $routes->get('users', 'User::index');
        $routes->post('users/create', 'User::create');
        $routes->post('users/update/(:num)', 'User::update/$1');
        $routes->get('users/delete/(:num)', 'User::delete/$1');
        $routes->get('users/get/(:num)', 'User::get/$1');
        
        // Laporan Keuangan
        $routes->get('laporan_keuangan', 'Admin::laporan_keuangan');
        $routes->get('export_keuangan/(:any)', 'Admin::export_keuangan/$1');
        
        // Maintenance
        $routes->get('maintenance', 'Admin::maintenance');
        $routes->post('run_maintenance', 'Admin::run_maintenance');
        
        // Audit Log
        $routes->get('audit_log', 'Admin::audit_log');
        $routes->get('export_audit', 'Admin::export_audit');
        
        // Dashboard admin dengan nama berbeda
        $routes->get('dashboard_admin', 'Admin::dashboard');
    });
    
    // ===== SISWA ROUTES =====
    $routes->group('siswa', function($routes) {
        // Dashboard Siswa (untuk role siswa)
        $routes->get('dashboard', 'Siswa::dashboard', ['filter' => 'role:siswa']);
        $routes->get('dashboard_siswa', 'Siswa::dashboard', ['filter' => 'role:siswa']);
        $routes->get('profile', 'Siswa::profile_siswa', ['filter' => 'role:siswa']);
        $routes->post('profile/update', 'Siswa::updateProfile', ['filter' => 'role:siswa']);
        $routes->get('profile_siswa', 'Siswa::profile_siswa', ['filter' => 'role:siswa']); // TAMBAHKAN INI
        $routes->get('change-password', 'Siswa::changePassword', ['filter' => 'role:siswa']);
        $routes->get('change-password_siswa', 'Siswa::changePassword', ['filter' => 'role:siswa']);
        $routes->post('change-password/update', 'Siswa::updatePassword', ['filter' => 'role:siswa']);
        $routes->get('history', 'Siswa::history', ['filter' => 'role:siswa']);
        $routes->get('history_siswa', 'Siswa::history', ['filter' => 'role:siswa']); 
        $routes->get('print-history', 'Siswa::printHistory', ['filter' => 'role:siswa']);
        $routes->get('receipt/(:num)', 'Siswa::receipt/$1', ['filter' => 'role:siswa']);  // TAMBAHKAN IN
       
        $routes->get('invoice/(:num)', 'Siswa::invoice/$1', ['filter' => 'role:siswa']);
        
        // Pembayaran SPP
        $routes->get('pembayaran', 'Siswa::pembayaran', ['filter' => 'role:siswa']);
        $routes->get('pembayaran_siswa', 'Siswa::pembayaran', ['filter' => 'role:siswa']); // TAMBAHKAN ALTERNATIF
        $routes->post('pembayaran_siswa', 'Siswa::storePembayaran', ['filter' => 'role:siswa']); // TAMBAHKAN POST ROUTE
        $routes->post('pembayaran/store', 'Siswa::storePembayaran', ['filter' => 'role:siswa']);
        
        
        // CRUD Siswa (untuk admin/petugas)
        $routes->get('/', 'Siswa::index', ['filter' => 'role:admin,petugas']);
        $routes->get('list', 'Siswa::index', ['filter' => 'role:admin,petugas']);
        $routes->post('create', 'Siswa::create', ['filter' => 'role:admin,petugas']);
        $routes->post('update/(:num)', 'Siswa::update/$1', ['filter' => 'role:admin,petugas']);
        $routes->get('delete/(:num)', 'Siswa::delete/$1', ['filter' => 'role:admin,petugas']);
        $routes->get('get/(:num)', 'Siswa::get/$1', ['filter' => 'role:admin,petugas']);
        $routes->get('search', 'Siswa::search', ['filter' => 'role:admin,petugas']);
        $routes->post('check-nisn', 'Siswa::checkNisn', ['filter' => 'role:admin,petugas']);
        $routes->get('export', 'Siswa::export', ['filter' => 'role:admin,petugas']);
        $routes->get('import', 'Siswa::import', ['filter' => 'role:admin,petugas']);
        $routes->post('import', 'Siswa::processImport', ['filter' => 'role:admin,petugas']);
        $routes->get('detail/(:num)', 'Siswa::detail/$1', ['filter' => 'role:admin,petugas']);
    });
    
    // ===== SPP MANAGEMENT =====
    $routes->group('spp', ['filter' => 'role:admin,petugas'], function($routes) {
        $routes->get('/', 'SPP::index');
        $routes->post('create', 'SPP::create');
        $routes->post('update/(:num)', 'SPP::update/$1');
        $routes->get('delete/(:num)', 'SPP::delete/$1');
        $routes->post('delete/(:num)', 'SPP::delete/$1'); // POST alternative
        $routes->get('get/(:num)', 'SPP::get/$1');
        $routes->get('getCsrfToken', 'SPP::getCsrfToken'); // Add CSRF token endpoint
        $routes->get('history', 'SPP::history');
        $routes->get('export', 'SPP::export');
        $routes->get('stats', 'SPP::getStats');
        $routes->get('check-duplicate', 'SPP::checkDuplicate');
        $routes->get('tahun/(:any)', 'SPP::getByTahun/$1');
        $routes->get('tingkat/(:any)', 'SPP::getByTingkat/$1');
        $routes->get('options', 'SPP::getOptions');
    });
    
    // ===== KELAS MANAGEMENT =====
    $routes->group('kelas', ['filter' => 'role:admin,petugas'], function($routes) {
        $routes->get('/', 'Kelas::index');
        $routes->post('create', 'Kelas::create');
        $routes->post('update/(:num)', 'Kelas::update/$1');
        $routes->get('delete/(:num)', 'Kelas::delete/$1');
        $routes->post('check-nama', 'Kelas::checkNamaKelas');
        $routes->get('detail/(:num)', 'Kelas::detail/$1');
        $routes->get('siswa/(:num)', 'Kelas::siswa/$1');
    });
    
    // ===== PEMBAYARAN MANAGEMENT =====
    $routes->group('pembayaran', function($routes) {
        // Untuk admin/petugas
        $routes->get('/', 'Pembayaran::index', ['filter' => 'role:admin,petugas']);
        $routes->post('create', 'Pembayaran::create', ['filter' => 'role:admin,petugas']);
        $routes->get('report', 'Pembayaran::report', ['filter' => 'role:admin,petugas']);
        $routes->get('print/(:num)', 'Pembayaran::print/$1', ['filter' => 'role:admin,petugas']);
        $routes->get('get-siswa/(:num)', 'Pembayaran::getSiswaInfo/$1', ['filter' => 'role:admin,petugas']);
        $routes->get('export', 'Pembayaran::export', ['filter' => 'role:admin,petugas']);
        $routes->get('detail/(:num)', 'Pembayaran::detail/$1', ['filter' => 'role:admin,petugas']);
        $routes->post('bulk-create', 'Pembayaran::bulkCreate', ['filter' => 'role:admin,petugas']);

        // Action routes for table buttons
        $routes->get('view/(:num)', 'Pembayaran::view/$1', ['filter' => 'role:admin,petugas']);
        $routes->get('edit/(:num)', 'Pembayaran::edit/$1', ['filter' => 'role:admin,petugas']);
        $routes->get('edit-form/(:num)', 'Pembayaran::editForm/$1', ['filter' => 'role:admin,petugas']);
        $routes->post('edit/(:num)', 'Pembayaran::edit/$1', ['filter' => 'role:admin,petugas']);
        $routes->post('update', 'Pembayaran::updateAjax', ['filter' => 'role:admin,petugas']);
        $routes->get('delete/(:num)', 'Pembayaran::delete/$1', ['filter' => 'role:admin,petugas']);
        $routes->post('delete/(:num)', 'Pembayaran::delete/$1', ['filter' => 'role:admin,petugas']);

        // Untuk siswa
        $routes->get('my-payments', 'Pembayaran::myPayments', ['filter' => 'role:siswa']);
        $routes->get('invoice/(:num)', 'Pembayaran::invoice/$1', ['filter' => 'role:siswa']);

        // Route umum (tanpa filter) untuk kebutuhan AJAX
        $routes->get('get-siswa-info/(:num)', 'Pembayaran::getSiswaInfo/$1');
    });
    
    // ===== LAPORAN =====
    $routes->group('laporan', ['filter' => 'role:admin,petugas'], function($routes) {
        $routes->get('/', 'Laporan::index');
        $routes->get('cetak', 'Laporan::cetak');
        $routes->get('export-excel', 'Laporan::exportExcel');
        $routes->get('filter', 'Laporan::filter');
        $routes->get('summary', 'Laporan::summary');
        $routes->get('tunggakan', 'Laporan::tunggakan');
        $routes->get('keuangan', 'Laporan::keuangan');
    });
    
    // ===== INDEX LAPORAN (UNTUK MENGGUNAKAN FILE index_laporan.php) =====
    $routes->get('index_laporan', 'Laporan::index_laporan', ['filter' => 'role:admin,petugas']);
    
    // ===== PROFILE (UNTUK SEMUA ROLE) =====
    $routes->group('profile', function($routes) {
        $routes->get('/', 'Profile::index');
        $routes->post('update', 'Profile::update');
        $routes->get('change-password', 'Profile::changePassword');
        $routes->post('change-password', 'Profile::updatePassword');
        $routes->post('update-photo', 'Profile::updatePhoto');
        $routes->get('activity', 'Profile::activity');
    });
    
    // ===== PETUGAS ROUTES =====
    $routes->group('petugas', ['filter' => 'role:petugas'], function($routes) {
        $routes->get('dashboard', 'Petugas::dashboard');
        $routes->get('quick-payment', 'Petugas::quickPayment');
        $routes->get('recent-payments', 'Petugas::recentPayments');
        $routes->get('my-report', 'Petugas::myReport');
        
        // Tambahkan alias untuk dashboard petugas
        $routes->get('dashboard_petugas', 'Petugas::dashboard');
    });
    
    // ===== SETTING ROUTES =====
    $routes->group('settings', ['filter' => 'role:admin'], function($routes) {
        $routes->get('/', 'Settings::index');
        $routes->post('save', 'Settings::save');
        $routes->get('school', 'Settings::school');
        $routes->get('payment', 'Settings::payment');
        $routes->get('notification', 'Settings::notification');
        $routes->post('test-smtp', 'Settings::testSMTP');
    });
    
    // ===== NOTIFICATION ROUTES =====
    $routes->group('notifications', function($routes) {
        $routes->get('/', 'Notification::index');
        $routes->get('read/(:num)', 'Notification::read/$1');
        $routes->get('mark-all-read', 'Notification::markAllRead');
        $routes->get('clear-all', 'Notification::clearAll');
        $routes->get('settings', 'Notification::settings');
    });
    
    // ===== IMPORT/EXPORT ROUTES =====
    $routes->group('import-export', ['filter' => 'role:admin,petugas'], function($routes) {
        $routes->get('/', 'ImportExport::index');
        $routes->get('template/(:any)', 'ImportExport::template/$1');
        $routes->post('upload/(:any)', 'ImportExport::upload/$1');
        $routes->get('export/(:any)', 'ImportExport::export/$1');
    });
    
    // ===== REDIRECT BERDASARKAN ROLE =====
    $routes->get('redirect-based-on-role', function() {
        $session = session();
        if (!$session->get('logged_in')) {
            return redirect()->to('login');
        }
        
        $role = $session->get('role');
        
        switch($role) {
            case 'admin':
                return redirect()->to('admin/dashboard');
            case 'petugas':
                return redirect()->to('petugas/dashboard');
            case 'siswa':
                return redirect()->to('siswa/dashboard_siswa');
            default:
                return redirect()->to('dashboard');
        }
    });
});

// =================== API ROUTES ===================
$routes->group('api', ['namespace' => 'App\Controllers\Api'], function($routes) {
    $routes->post('login', 'Auth::login');
    $routes->get('check-nisn/(:num)', 'Siswa::checkNisn/$1');
    $routes->get('siswa/search', 'Siswa::search');
    $routes->get('pembayaran/siswa/(:num)', 'Pembayaran::bySiswa/$1');
    $routes->get('statistics', 'Statistics::index');
    $routes->post('upload/image', 'Upload::image');
    
    // SPP API
    $routes->group('spp', function($routes) {
        $routes->get('all', 'SPP::apiGetAll');
        $routes->get('tahun/(:any)', 'SPP::getByTahun/$1');
        $routes->get('tingkat/(:any)', 'SPP::getByTingkat/$1');
        $routes->get('stats', 'SPP::getStats');
    });
    
    // Webhook for notifications
    $routes->post('webhook/payment', 'Webhook::payment');
    $routes->post('webhook/backup', 'Webhook::backup');
});

// =================== WEBHOOK ROUTES ===================
$routes->group('webhook', function($routes) {
    $routes->post('payment-callback', 'Webhook::paymentCallback');
    $routes->post('backup-complete', 'Webhook::backupComplete');
    $routes->post('email-status', 'Webhook::emailStatus');
});

// =================== TEST & DEBUG ROUTES ===================
$routes->get('test', function() { 
    return "System OK! " . date('Y-m-d H:i:s'); 
});

$routes->get('test-db', function() {
    try {
        $db = \Config\Database::connect();
        $db->connect();
        
        // Test query
        $query = $db->table('users')->countAllResults();
        
        return "DB Connected! Users count: " . $query;
    } catch (\Exception $e) {
        return "DB Error: " . $e->getMessage();
    }
});

$routes->get('test-email', 'Test::email');
$routes->get('test-pdf', 'Test::pdf');
$routes->get('test-session', 'Test::session');

// =================== MAINTENANCE MODE ===================
$routes->get('maintenance-mode', 'Maintenance::index');

// =================== REDIRECTS (untuk backward compatibility) ===================
$routes->addRedirect('admin/dashboard_admin', 'admin/dashboard'); // Redirect ke dashboard admin yang benar
// $routes->addRedirect('index_laporan', 'pembayaran/report'); // COMMENT OUT INI
$routes->addRedirect('dashboard_siswa', 'siswa/dashboard_siswa');
$routes->addRedirect('admin', 'admin/dashboard');
$routes->addRedirect('petugas', 'petugas/dashboard');
$routes->addRedirect('backup', 'admin/backup_database');
$routes->addRedirect('settings', 'admin/pengaturan_sistem');
$routes->addRedirect('rekap', 'admin/rekap_bulanan');
$routes->addRedirect('tunggakan', 'admin/laporan_tunggakan');
$routes->addRedirect('activity', 'admin/activity_log');
$routes->addRedirect('logs', 'admin/audit_log');
$routes->addRedirect('keuangan', 'admin/laporan_keuangan');

// Redirect untuk siswa yang mencoba akses halaman admin
$routes->get('admin', function() {
    $session = session();
    if (!$session->get('logged_in')) {
        return redirect()->to('login');
    }
    
    $role = $session->get('role');
    if ($role == 'siswa') {
        return redirect()->to('siswa/dashboard');
    } elseif ($role == 'petugas') {
        return redirect()->to('petugas/dashboard');
    }
    
    return redirect()->to('admin/dashboard');
});

// =================== FALLBACK ROUTES ===================
$routes->get('(:any)', function($segment) {
    // Cek apakah ada session
    $session = session();
    
    // Jika tidak ada session, redirect ke login
    if (!$session->get('logged_in')) {
        return redirect()->to('login');
    }
    
    // Jika ada session, coba redirect berdasarkan role
    $role = $session->get('role');
    
    // Jika siswa mencoba akses halaman admin
    if (strpos($segment, 'admin/') === 0 && $role == 'siswa') {
        return redirect()->to('siswa/dashboard_siswa');
    }
});

// Auto route disabled for security
$routes->setAutoRoute(false);

// =================== CLI ROUTES ===================
if (is_cli()) {
    $routes->cli('backup/run', 'BackupCli::run');
    $routes->cli('backup/cleanup', 'BackupCli::cleanup');
    $routes->cli('cron/reminders', 'Cron::sendReminders');
    $routes->cli('cron/backup', 'Cron::autoBackup');
    $routes->cli('cron/cleanup', 'Cron::cleanupLogs');
    $routes->cli('migrate', 'Migrate::run');
    $routes->cli('seed', 'Seeder::run');
    
    // SPP CLI commands
    $routes->cli('spp/seed', 'SPPSeeder::run');
    $routes->cli('spp/cleanup', 'SPPSeeder::cleanup');
    $routes->cli('spp/check-duplicates', 'SPPSeeder::checkDuplicates');
}