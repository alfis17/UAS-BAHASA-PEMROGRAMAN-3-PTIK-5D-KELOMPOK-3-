<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class NoAuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        
        // If user is already logged in, redirect to appropriate dashboard
        if ($session->get('logged_in')) {
            $role = $session->get('role');
            
            if ($role === 'siswa') {
                return redirect()->to('siswa/dashboard_siswa')->with('info', 'Anda sudah login sebagai siswa');
            } else {
                return redirect()->to('/dashboard')->with('info', 'Anda sudah login');
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here after the controller executes
    }
}