<?php

namespace App\Controllers;

use App\Models\SPPModel;
use CodeIgniter\API\ResponseTrait;

class SPP extends BaseController
{
    use ResponseTrait;
    
    protected $sppModel;
    protected $validation;
    
    public function __construct()
    {
        $this->sppModel = new SPPModel();
        $this->validation = \Config\Services::validation();
        helper(['form', 'url', 'text', 'security']);
    }

    public function index()
    {
        // Check user role
        if (!in_array(session()->get('role'), ['admin', 'petugas'])) {
            return redirect()->to('/dashboard')->with('error', 'Akses ditolak.');
        }
        
        try {
            // Cek koneksi database dan table
            $db = \Config\Database::connect();
            $tables = $db->listTables();
            
            if (!in_array('spp', $tables)) {
                return redirect()->to('/dashboard')->with('error', 'Tabel SPP tidak ditemukan.');
            }
            
            $data = [
                'title' => 'Data SPP',
                'page_title' => 'Kelola Tarif SPP',
                'active_menu' => 'spp',
                'spp' => $this->sppModel->orderBy('tahun_ajaran', 'DESC')
                                       ->orderBy('tingkat', 'ASC')
                                       ->findAll(),
                'tahun_list' => $this->sppModel->getTahunAjaranTersedia(),
                'user' => session()->get(),
                'validation' => $this->validation
            ];
            
            return view('admin/index_spp', $data);
            
        } catch (\Exception $e) {
            log_message('error', 'Error in SPP index: ' . $e->getMessage());
            return redirect()->to('/dashboard')->with('error', 'Terjadi kesalahan sistem: ' . $e->getMessage());
        }
    }

    public function create()
    {
        // Only allow AJAX requests
        if (!$this->request->isAJAX()) {
            return $this->fail('Method not allowed', 405);
        }
        
        // Validate CSRF token
        $csrfToken = $this->request->getPost('csrf_test_name');
        $csrfValue = csrf_hash();
        
        if ($csrfToken !== $csrfValue) {
            return $this->fail('Token CSRF tidak valid', 403);
        }
        
        // Set validation rules
        $rules = [
            'tahun_ajaran' => [
                'label' => 'Tahun Ajaran',
                'rules' => 'required|regex_match[/^\d{4}\/\d{4}$/]|max_length[9]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'regex_match' => 'Format {field} harus YYYY/YYYY',
                    'max_length' => '{field} maksimal 9 karakter'
                ]
            ],
            'tingkat' => [
                'label' => 'Tingkat',
                'rules' => 'required|in_list[X,XI,XII]',
                'errors' => [
                    'required' => '{field} harus dipilih',
                    'in_list' => 'Pilih {field} yang valid'
                ]
            ],
            'nominal' => [
                'label' => 'Nominal SPP',
                'rules' => 'required|greater_than[99999]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'greater_than' => '{field} harus lebih dari 99.999'
                ]
            ]
        ];
        
        // Run validation
        if (!$this->validate($rules)) {
            return $this->failValidationError($this->validator->getErrors());
        }
        
        // Clean nominal data - remove dots and commas
        $nominalInput = $this->request->getPost('nominal');
        $nominal = preg_replace('/[^0-9]/', '', $nominalInput);
        
        if (empty($nominal) || !is_numeric($nominal)) {
            return $this->fail('Nominal SPP tidak valid', 400);
        }
        
        $nominal = (float) $nominal;
        
        // Get post data
        $data = [
            'tahun_ajaran' => $this->request->getPost('tahun_ajaran'),
            'tingkat' => $this->request->getPost('tingkat'),
            'nominal' => $nominal,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        // Check for duplicate
        $existing = $this->sppModel->where('tahun_ajaran', $data['tahun_ajaran'])
                                  ->where('tingkat', $data['tingkat'])
                                  ->first();
        
        if ($existing) {
            return $this->fail('Data SPP untuk tahun ajaran dan tingkat ini sudah ada', 409);
        }
        
        try {
            // Save data
            $saved = $this->sppModel->insert($data);
            
            if (!$saved) {
                return $this->fail('Gagal menyimpan data SPP', 500);
            }
            
            // Get the inserted data
            $newData = $this->sppModel->find($this->sppModel->getInsertID());
            
            // Format nominal for response
            $newData->nominal_formatted = 'Rp ' . number_format($newData->nominal, 0, ',', '.');
            
            // Log activity
            $this->logActivity('Menambahkan data SPP: ' . $data['tahun_ajaran'] . ' - Kelas ' . $data['tingkat'] . ' - Rp ' . number_format($data['nominal'], 0, ',', '.'));
            
            return $this->respondCreated([
                'success' => true,
                'message' => 'Data SPP berhasil ditambahkan',
                'data' => $newData
            ]);
            
        } catch (\Exception $e) {
            log_message('error', 'Error creating SPP: ' . $e->getMessage());
            return $this->fail('Terjadi kesalahan sistem: ' . $e->getMessage(), 500);
        }
    }

    public function update($id = null)
    {
        // Only allow AJAX requests
        if (!$this->request->isAJAX()) {
            return $this->fail('Method not allowed', 405);
        }
        
        // Validate CSRF token
        $csrfToken = $this->request->getPost('csrf_test_name');
        $csrfValue = csrf_hash();
        
        if ($csrfToken !== $csrfValue) {
            return $this->fail('Token CSRF tidak valid', 403);
        }
        
        // Check if ID is provided
        if (!$id) {
            return $this->fail('ID tidak ditemukan', 404);
        }
        
        // Check if data exists
        $existing = $this->sppModel->find($id);
        if (!$existing) {
            return $this->fail('Data SPP tidak ditemukan', 404);
        }
        
        // Set validation rules
        $rules = [
            'tahun_ajaran' => [
                'label' => 'Tahun Ajaran',
                'rules' => 'required|regex_match[/^\d{4}\/\d{4}$/]|max_length[9]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'regex_match' => 'Format {field} harus YYYY/YYYY',
                    'max_length' => '{field} maksimal 9 karakter'
                ]
            ],
            'tingkat' => [
                'label' => 'Tingkat',
                'rules' => 'required|in_list[X,XI,XII]',
                'errors' => [
                    'required' => '{field} harus dipilih',
                    'in_list' => 'Pilih {field} yang valid'
                ]
            ],
            'nominal' => [
                'label' => 'Nominal SPP',
                'rules' => 'required|greater_than[99999]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'greater_than' => '{field} harus lebih dari 99.999'
                ]
            ]
        ];
        
        // Run validation
        if (!$this->validate($rules)) {
            return $this->failValidationError($this->validator->getErrors());
        }
        
        // Clean nominal data - remove dots and commas
        $nominalInput = $this->request->getPost('nominal');
        $nominal = preg_replace('/[^0-9]/', '', $nominalInput);
        
        if (empty($nominal) || !is_numeric($nominal)) {
            return $this->fail('Nominal SPP tidak valid', 400);
        }
        
        $nominal = (float) $nominal;
        
        // Get post data
        $data = [
            'tahun_ajaran' => $this->request->getPost('tahun_ajaran'),
            'tingkat' => $this->request->getPost('tingkat'),
            'nominal' => $nominal,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        // Check for duplicate (excluding current record)
        $duplicate = $this->sppModel->where('tahun_ajaran', $data['tahun_ajaran'])
                                   ->where('tingkat', $data['tingkat'])
                                   ->where('id !=', $id)
                                   ->first();
        
        if ($duplicate) {
            return $this->fail('Data SPP untuk tahun ajaran dan tingkat ini sudah ada', 409);
        }
        
        try {
            // Update data
            $updated = $this->sppModel->update($id, $data);
            
            if (!$updated) {
                return $this->fail('Gagal memperbarui data SPP', 500);
            }
            
            // Get updated data
            $updatedData = $this->sppModel->find($id);
            
            // Format nominal for response
            $updatedData->nominal_formatted = 'Rp ' . number_format($updatedData->nominal, 0, ',', '.');
            
            // Log activity
            $this->logActivity('Memperbarui data SPP ID: ' . $id . ' - ' . $data['tahun_ajaran'] . ' - Kelas ' . $data['tingkat'] . ' - Rp ' . number_format($data['nominal'], 0, ',', '.'));
            
            return $this->respond([
                'success' => true,
                'message' => 'Data SPP berhasil diperbarui',
                'data' => $updatedData
            ]);
            
        } catch (\Exception $e) {
            log_message('error', 'Error updating SPP: ' . $e->getMessage());
            return $this->fail('Terjadi kesalahan sistem: ' . $e->getMessage(), 500);
        }
    }

        public function delete($id = null)
{
    try {
        // Check if ID is provided and valid
        if (!$id || !is_numeric($id)) {
            throw new \Exception('ID tidak valid');
        }
        
        $id = (int) $id;
        
        // Check if request is AJAX
        $isAjax = $this->request->isAJAX();
        
        // Validate CSRF token for all requests
        $csrfToken = $this->request->getHeaderLine('X-CSRF-TOKEN') ?: $this->request->getPost('csrf_test_name');

        if (!$csrfToken || $csrfToken !== csrf_hash()) {
            log_message('error', 'CSRF token mismatch. Received: ' . $csrfToken . ', Expected: ' . csrf_hash());
            if ($isAjax) {
                return $this->fail('Token keamanan tidak valid', 403);
            } else {
                return redirect()->back()->with('error', 'Token keamanan tidak valid');
            }
        }
        
        // Check if data exists
        $spp = $this->sppModel->find($id);
        if (!$spp) {
            throw new \Exception('Data SPP tidak ditemukan');
        }
        
        // Check if SPP is used in pembayaran (only if table exists)
        $db = \Config\Database::connect();
        if ($db->tableExists('pembayaran')) {
            $pembayaranCount = $db->table('pembayaran')
                                 ->where('id_spp', $id)
                                 ->countAllResults();
            
            if ($pembayaranCount > 0) {
                throw new \Exception('Data SPP tidak dapat dihapus karena sudah digunakan dalam ' . $pembayaranCount . ' pembayaran');
            }
        }
        
        // Delete data
        $deleted = $this->sppModel->delete($id);
        
        if (!$deleted) {
            throw new \Exception('Gagal menghapus data dari database');
        }
        
        // Log activity
        $this->logActivity('Menghapus data SPP: ' . $spp->tahun_ajaran . ' - Kelas ' . $spp->tingkat);
        
        // Response for AJAX
        if ($isAjax) {
            return $this->respond([
                'success' => true,
                'message' => 'Data SPP berhasil dihapus',
                'data' => [
                    'id' => $id,
                    'tahun_ajaran' => $spp->tahun_ajaran,
                    'tingkat' => $spp->tingkat
                ]
            ], 200);
        }
        
        // Response for normal request
        return redirect()->to('/spp')->with('success', 'Data SPP berhasil dihapus');
        
    } catch (\Exception $e) {
        log_message('error', 'Delete SPP Error: ' . $e->getMessage() . ' | ID: ' . $id);
        
        if ($this->request->isAJAX()) {
            return $this->fail($e->getMessage(), 400);
        }
        
        return redirect()->back()->with('error', $e->getMessage());
    }
}

    public function get($id)
    {
        // Allow both AJAX and regular requests
        if (!$this->request->isAJAX() && !$this->request->getGet('format')) {
            return redirect()->to('/spp');
        }
        
        // Check if ID is provided
        if (!$id) {
            return $this->fail('ID tidak ditemukan', 404);
        }
        
        // Get data
        $spp = $this->sppModel->find($id);
        
        if (!$spp) {
            return $this->fail('Data SPP tidak ditemukan', 404);
        }
        
        // Format nominal for display
        $spp->nominal_formatted = 'Rp ' . number_format($spp->nominal, 0, ',', '.');
        $spp->created_formatted = date('d/m/Y H:i', strtotime($spp->created_at));
        $spp->updated_formatted = date('d/m/Y H:i', strtotime($spp->updated_at));
        
        if ($this->request->isAJAX()) {
            return $this->respond([
                'success' => true,
                'data' => $spp
            ]);
        } 
    }

    public function history()
    {
        // Check user role
        if (!in_array(session()->get('role'), ['admin', 'petugas'])) {
            return redirect()->to('/dashboard')->with('error', 'Akses ditolak.');
        }
        
        try {
            $data = [
                'title' => 'Riwayat Perubahan SPP',
                'page_title' => 'Riwayat Perubahan Tarif SPP',
                'active_menu' => 'spp',
                'user' => session()->get()
            ];
            
            $data['spp_history'] = $this->sppModel->orderBy('updated_at', 'DESC')->findAll();
            
            // Format nominal for display
            foreach ($data['spp_history'] as &$spp) {
                $spp->nominal_formatted = 'Rp ' . number_format($spp->nominal, 0, ',', '.');
                $spp->updated_formatted = date('d/m/Y H:i', strtotime($spp->updated_at));
            }
            
            return view('admin/spp_history', $data);
            
        } catch (\Exception $e) {
            log_message('error', 'Error in SPP history: ' . $e->getMessage());
            return redirect()->to('/spp')->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    public function export()
    {
        // Check user role
        if (!in_array(session()->get('role'), ['admin'])) {
            return redirect()->to('/dashboard')->with('error', 'Akses ditolak.');
        }
        
        try {
            // Get all SPP data
            $sppData = $this->sppModel->orderBy('tahun_ajaran', 'DESC')
                                     ->orderBy('tingkat', 'ASC')
                                     ->findAll();
            
            if (empty($sppData)) {
                return redirect()->to('/spp')->with('error', 'Tidak ada data SPP untuk diekspor');
            }
            
            // Create CSV content
            $csv = "ID,Tahun Ajaran,Tingkat,Nominal SPP,Dibuat,Diperbarui\n";
            
            foreach ($sppData as $row) {
                $csv .= "{$row->id},{$row->tahun_ajaran},Kelas {$row->tingkat},Rp " . number_format($row->nominal, 0, ',', '.') . ",{$row->created_at},{$row->updated_at}\n";
            }
            
            // Set headers for download
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="data_spp_' . date('Y-m-d') . '.csv"');
            header('Cache-Control: max-age=0');
            
            echo $csv;
            exit();
            
        } catch (\Exception $e) {
            log_message('error', 'Error exporting SPP: ' . $e->getMessage());
            return redirect()->to('/spp')->with('error', 'Gagal mengekspor data: ' . $e->getMessage());
        }
    }

    public function checkDuplicate()
    {
        // Allow both AJAX and regular requests
        if (!$this->request->isAJAX() && !$this->request->getGet('format')) {
            return redirect()->to('/spp');
        }
        
        $tahun_ajaran = $this->request->getGet('tahun_ajaran');
        $tingkat = $this->request->getGet('tingkat');
        $exclude_id = $this->request->getGet('exclude_id');
        
        if (!$tahun_ajaran || !$tingkat) {
            return $this->fail('Parameter tidak lengkap', 400);
        }
        
        $query = $this->sppModel->where('tahun_ajaran', $tahun_ajaran)
                               ->where('tingkat', $tingkat);
        
        if ($exclude_id) {
            $query->where('id !=', $exclude_id);
        }
        
        $exists = $query->first();
        
        return $this->respond([
            'exists' => $exists ? true : false,
            'data' => $exists
        ]);
    }

    public function getStats()
    {
        // Only allow AJAX requests
        if (!$this->request->isAJAX()) {
            return $this->fail('Method not allowed', 405);
        }
        
        try {
            $stats = $this->sppModel->getTotalSPPPerTingkat();
            
            $totalSPP = 0;
            $totalNominal = 0;
            $count = 0;
            
            $sppData = $this->sppModel->findAll();
            foreach ($sppData as $spp) {
                $totalSPP++;
                $totalNominal += $spp->nominal;
                $count++;
            }
            
            $average = $count > 0 ? $totalNominal / $count : 0;
            $yearlyTotal = $average * 12;
            $estimated = $yearlyTotal * 100;
            
            // Format for display
            $formattedStats = [];
            foreach ($stats as $stat) {
                $formattedStats[] = [
                    'tingkat' => $stat->tingkat,
                    'total' => $stat->total,
                    'total_nominal' => $stat->total_nominal,
                    'total_nominal_formatted' => 'Rp ' . number_format($stat->total_nominal, 0, ',', '.'),
                    'rata_rata' => $stat->rata_rata,
                    'rata_rata_formatted' => 'Rp ' . number_format($stat->rata_rata, 0, ',', '.')
                ];
            }
            
            return $this->respond([
                'success' => true,
                'stats' => [
                    'total_data' => $totalSPP,
                    'average_per_month' => round($average),
                    'average_per_month_formatted' => 'Rp ' . number_format(round($average), 0, ',', '.'),
                    'yearly_per_student' => round($yearlyTotal),
                    'yearly_per_student_formatted' => 'Rp ' . number_format(round($yearlyTotal), 0, ',', '.'),
                    'estimated_100_students' => round($estimated),
                    'estimated_100_students_formatted' => 'Rp ' . number_format(round($estimated), 0, ',', '.'),
                    'by_tingkat' => $formattedStats
                ]
            ]);
            
        } catch (\Exception $e) {
            log_message('error', 'Error getting SPP stats: ' . $e->getMessage());
            return $this->fail('Terjadi kesalahan sistem', 500);
        }
    }

    public function getByTahun($tahun_ajaran)
    {
        // Allow both AJAX and regular requests
        if (!$this->request->isAJAX() && !$this->request->getGet('format')) {
            return redirect()->to('/spp');
        }
        
        try {
            $sppData = $this->sppModel->where('tahun_ajaran', $tahun_ajaran)
                                     ->orderBy('tingkat', 'ASC')
                                     ->findAll();
            
            if (!$sppData) {
                return $this->respond([
                    'success' => false,
                    'message' => 'Data tidak ditemukan untuk tahun ajaran ' . $tahun_ajaran
                ]);
            }
            
            // Format nominal for display
            foreach ($sppData as &$spp) {
                $spp->nominal_formatted = 'Rp ' . number_format($spp->nominal, 0, ',', '.');
            }
            
            return $this->respond([
                'success' => true,
                'data' => $sppData
            ]);
            
        } catch (\Exception $e) {
            log_message('error', 'Error getting SPP by tahun: ' . $e->getMessage());
            return $this->fail('Terjadi kesalahan sistem', 500);
        }
    }

    public function getByTingkat($tingkat)
    {
        // Allow both AJAX and regular requests
        if (!$this->request->isAJAX() && !$this->request->getGet('format')) {
            return redirect()->to('/spp');
        }
        
        if (!in_array($tingkat, ['X', 'XI', 'XII'])) {
            return $this->fail('Tingkat tidak valid', 400);
        }
        
        try {
            $sppData = $this->sppModel->where('tingkat', $tingkat)
                                     ->orderBy('tahun_ajaran', 'DESC')
                                     ->findAll();
            
            // Format nominal for display
            foreach ($sppData as &$spp) {
                $spp->nominal_formatted = 'Rp ' . number_format($spp->nominal, 0, ',', '.');
                $spp->created_formatted = date('d/m/Y', strtotime($spp->created_at));
            }
            
            return $this->respond([
                'success' => true,
                'data' => $sppData
            ]);
            
        } catch (\Exception $e) {
            log_message('error', 'Error getting SPP by tingkat: ' . $e->getMessage());
            return $this->fail('Terjadi kesalahan sistem', 500);
        }
    }

    /**
     * Get SPP for dropdown/select options
     */
    public function getOptions()
    {
        try {
            $sppData = $this->sppModel->orderBy('tahun_ajaran', 'DESC')
                                     ->orderBy('tingkat', 'ASC')
                                     ->findAll();
            
            $options = [];
            foreach ($sppData as $spp) {
                $options[$spp->id] = $spp->tahun_ajaran . ' - Kelas ' . $spp->tingkat . ' (Rp ' . number_format($spp->nominal, 0, ',', '.') . ')';
            }
            
            return $this->respond([
                'success' => true,
                'options' => $options
            ]);
            
        } catch (\Exception $e) {
            log_message('error', 'Error getting SPP options: ' . $e->getMessage());
            return $this->fail('Terjadi kesalahan sistem', 500);
        }
    }
        

    /**
     * Log activity helper
     */
    private function logActivity($activity)
    {
        try {
            $db = \Config\Database::connect();
            
            $data = [
                'user_id' => session()->get('id') ?? 0,
                'username' => session()->get('username') ?? 'system',
                'activity' => $activity,
                'ip_address' => $this->request->getIPAddress(),
                'user_agent' => $this->request->getUserAgent()->getAgentString(),
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $db->table('activity_logs')->insert($data);
        } catch (\Exception $e) {
            log_message('error', 'Failed to log activity: ' . $e->getMessage());
        }
    }

    /**
     * API endpoint for mobile/third-party apps
     */
    public function apiGetAll()
    {
        // Check API key
        $apiKey = $this->request->getHeaderLine('X-API-Key');
        if (!$this->validateApiKey($apiKey)) {
            return $this->failUnauthorized('API key tidak valid');
        }
        
        try {
            $sppData = $this->sppModel->orderBy('tahun_ajaran', 'DESC')
                                     ->orderBy('tingkat', 'ASC')
                                     ->findAll();
            
            return $this->respond([
                'success' => true,
                'timestamp' => date('Y-m-d H:i:s'),
                'data' => $sppData
            ]);
            
        } catch (\Exception $e) {
            log_message('error', 'API Error getting SPP: ' . $e->getMessage());
            return $this->fail('Internal server error', 500);
        }
    }

    /**
     * Get fresh CSRF token for AJAX requests
     */
    public function getCsrfToken()
    {
        // Only allow AJAX requests
        if (!$this->request->isAJAX()) {
            return $this->fail('Method not allowed', 405);
        }

        return $this->respond([
            'success' => true,
            'csrf_token' => csrf_hash(),
            'csrf_name' => csrf_token()
        ]);
    }

    /**
     * Validate API key
     */
    private function validateApiKey($apiKey)
    {
        // In real application, validate against database
        $validKeys = ['spp_api_2024', 'mobile_app_key'];
        return in_array($apiKey, $validKeys);
    }
}
