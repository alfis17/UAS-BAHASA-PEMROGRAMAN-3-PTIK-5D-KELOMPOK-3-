<?php

namespace App\Controllers;

use App\Models\PembayaranModel;
use App\Models\SiswaModel;
use App\Models\SPPModel;
use App\Models\KelasModel;
use App\Models\UserModel;
use CodeIgniter\API\ResponseTrait;

class Pembayaran extends BaseController
{
    use ResponseTrait;
    
    protected $pembayaranModel;
    protected $siswaModel;
    protected $sppModel;
    protected $kelasModel;
    protected $userModel;
    protected $validation;
    
    public function __construct()
    {
        $this->pembayaranModel = new PembayaranModel();
        $this->siswaModel = new SiswaModel();
        $this->sppModel = new SPPModel();
        $this->kelasModel = new KelasModel();
        $this->userModel = new UserModel();
        $this->validation = \Config\Services::validation();
        
        helper(['form', 'url', 'date', 'text']);
        
        // Cek session login
        if (!session()->has('user_id') || !in_array(session()->get('role'), ['admin', 'petugas'])) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu');
        }
    }

    public function index()
    {
        $data = [
            'title' => 'Data Pembayaran SPP',
            'page_title' => 'Kelola Pembayaran SPP',
            'active_menu' => 'pembayaran',
            'pembayaran' => $this->getPembayaranData(),
            'siswa_list' => $this->getSiswaList(),
            'spp_list' => $this->getSppList(),
            'bulan_list' => $this->getBulanList(),
            'tahun_list' => $this->getTahunList(),
            'user' => session()->get(),
            'validation' => $this->validation
        ];
        
        // Hitung statistik
        $data['stats'] = $this->getPaymentStats();
        
        return view('admin/index_pembayaran', $data);
    }

    private function getPembayaranData()
{
    $builder = $this->pembayaranModel->db->table('pembayaran p');
    $builder->select('p.*, s.nisn, s.nama_siswa, k.nama_kelas, sp.tahun_ajaran, sp.nominal as spp_nominal, u.nama_lengkap as petugas');
    $builder->join('siswa s', 's.id = p.id_siswa');
    $builder->join('kelas k', 'k.id = s.id_kelas', 'left');
    $builder->join('spp sp', 'sp.id = p.id_spp', 'left');
    $builder->join('users u', 'u.id = p.id_user', 'left');
    $builder->orderBy('p.tanggal_bayar', 'DESC');
    
    $result = $builder->get()->getResultArray();
    
    // Jika status tidak ada di database, baru set default
    foreach ($result as &$row) {
        if (!isset($row['status_pembayaran']) || empty($row['status_pembayaran'])) {
            // Logika untuk menentukan status berdasarkan jumlah bayar
            $jumlah_bayar = $row['jumlah_bayar'] ?? 0;
            $spp_nominal = $row['spp_nominal'] ?? 0;
            
            if ($spp_nominal > 0 && $jumlah_bayar >= $spp_nominal) {
                $row['status_pembayaran'] = 'Lunas';
            } else {
                $row['status_pembayaran'] = 'Belum Lunas';
            }
        }
    }
    
    return $result;
}

    private function getSiswaList()
    {
        $builder = $this->siswaModel->db->table('siswa s');
        $builder->select('s.id, s.nisn, s.nama_siswa, k.nama_kelas, k.tingkat');
        $builder->join('kelas k', 'k.id = s.id_kelas', 'left');
        $builder->where('s.status', 'active');
        $builder->orderBy('s.nama_siswa', 'ASC');
        
        return $builder->get()->getResultArray();
    }

    private function getSppList()
    {
        $builder = $this->sppModel->db->table('spp');
        $builder->select('*');
        $builder->where('status', 'aktif');
        $builder->orderBy('tahun_ajaran', 'DESC');
        $builder->orderBy('tingkat', 'ASC');
        
        return $builder->get()->getResultArray();
    }

    public function create()
    {
        // Handle AJAX request
        if ($this->request->isAJAX()) {
            return $this->createAjax();
        }
        
        // Handle regular request
        return $this->createRegular();
    }
    
    private function createAjax()
    {
        // Validasi input
        $rules = [
            'id_siswa' => 'required|numeric',
            'id_spp' => 'required|numeric',
            'bulan' => 'required',
            'tahun' => 'required|numeric|exact_length[4]',
            'jumlah_bayar' => 'required|numeric|greater_than[0]',
            'metode_pembayaran' => 'required|in_list[Tunai,Transfer,QRIS]',
            'keterangan' => 'permit_empty',
            'status_pembayaran' => 'required|in_list[Lunas,Belum Lunas]'
        ];
        
        $messages = [
            'id_siswa' => [
                'required' => 'Siswa harus dipilih',
                'numeric' => 'Data siswa tidak valid'
            ],
            'id_spp' => [
                'required' => 'Tarif SPP harus dipilih',
                'numeric' => 'Data SPP tidak valid'
            ],
            'bulan' => [
                'required' => 'Bulan harus dipilih'
            ],
            'tahun' => [
                'required' => 'Tahun harus diisi',
                'numeric' => 'Tahun harus angka',
                'exact_length' => 'Tahun harus 4 digit'
            ],
            'jumlah_bayar' => [
                'required' => 'Jumlah bayar harus diisi',
                'numeric' => 'Jumlah bayar harus angka',
                'greater_than' => 'Jumlah bayar harus lebih dari 0'
            ],
            'metode_pembayaran' => [
                'required' => 'Metode pembayaran harus dipilih',
                'in_list' => 'Pilih metode pembayaran yang valid'
            ],
            'status_pembayaran' => [
                'required' => 'Status pembayaran harus dipilih',
                'in_list' => 'Pilih status pembayaran yang valid'
            ]
        ];
        
        $this->validation->setRules($rules, $messages);
        
        if (!$this->validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
                'success' => false,
                'errors' => $this->validation->getErrors()
            ]);
        }
        
        // Ambil data dari form
        $postData = $this->request->getPost();
        
        // Cek duplikasi pembayaran
        $existing = $this->pembayaranModel
            ->where('id_siswa', $postData['id_siswa'])
            ->where('bulan', $postData['bulan'])
            ->where('tahun', $postData['tahun'])
            ->first();
        
        if ($existing) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Siswa sudah melakukan pembayaran untuk bulan dan tahun ini'
            ]);
        }
        
        // Ambil data SPP untuk validasi jumlah
        $sppData = $this->sppModel->find($postData['id_spp']);
        
        // Format jumlah bayar (hapus titik jika ada)
        $jumlah_bayar = str_replace('.', '', $postData['jumlah_bayar']);
        $jumlah_bayar = (float) $jumlah_bayar;
        
        // Validasi jika status Lunas tapi jumlah kurang dari nominal SPP
        if ($postData['status_pembayaran'] == 'Lunas' && $sppData) {
            $sppNominal = is_object($sppData) ? $sppData->nominal : $sppData['nominal'];
            if ($jumlah_bayar < $sppNominal) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Status Lunas tidak valid karena jumlah bayar kurang dari nominal SPP (Rp ' . number_format($sppNominal, 0, ',', '.') . ')'
                ]);
            }
        }
        
        // Data untuk disimpan
        $data = [
            'id_siswa' => $postData['id_siswa'],
            'id_spp' => $postData['id_spp'],
            'bulan' => $postData['bulan'],
            'tahun' => $postData['tahun'],
            'tanggal_bayar' => date('Y-m-d H:i:s'),
            'jumlah_bayar' => $jumlah_bayar,
            'metode_pembayaran' => $postData['metode_pembayaran'],
            'keterangan' => $postData['keterangan'] ?? '',
            'status_pembayaran' => $postData['status_pembayaran'],
            'id_user' => session()->get('user_id'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        // Simpan menggunakan Model
        if ($this->pembayaranModel->insert($data)) {
            // Ambil data siswa untuk log
            $siswa = $this->siswaModel->find($data['id_siswa']);
            $nama_siswa = is_object($siswa) ? $siswa->nama_siswa : $siswa['nama_siswa'];
            
            // Log activity
            $this->logActivity('Menambahkan pembayaran SPP untuk siswa: ' . $nama_siswa . 
                             ' - ' . $data['bulan'] . ' ' . $data['tahun'] . 
                             ' - Rp ' . number_format($data['jumlah_bayar'], 0, ',', '.') . 
                             ' - Status: ' . $data['status_pembayaran']);
            
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Pembayaran berhasil dicatat'
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Gagal menyimpan data pembayaran'
            ]);
        }
    }
    
    private function createRegular()
    {
        // Validasi input
        $rules = [
            'id_siswa' => 'required|numeric',
            'id_spp' => 'required|numeric',
            'bulan' => 'required',
            'tahun' => 'required|numeric|exact_length[4]',
            'jumlah_bayar' => 'required|numeric|greater_than[0]',
            'metode_pembayaran' => 'required|in_list[Tunai,Transfer,QRIS]',
            'keterangan' => 'permit_empty',
            'status_pembayaran' => 'required|in_list[Lunas,Belum Lunas]'
        ];
        
        $messages = [
            'id_siswa' => [
                'required' => 'Siswa harus dipilih',
                'numeric' => 'Data siswa tidak valid'
            ],
            'id_spp' => [
                'required' => 'Tarif SPP harus dipilih',
                'numeric' => 'Data SPP tidak valid'
            ],
            'bulan' => [
                'required' => 'Bulan harus dipilih'
            ],
            'tahun' => [
                'required' => 'Tahun harus diisi',
                'numeric' => 'Tahun harus angka',
                'exact_length' => 'Tahun harus 4 digit'
            ],
            'jumlah_bayar' => [
                'required' => 'Jumlah bayar harus diisi',
                'numeric' => 'Jumlah bayar harus angka',
                'greater_than' => 'Jumlah bayar harus lebih dari 0'
            ],
            'metode_pembayaran' => [
                'required' => 'Metode pembayaran harus dipilih',
                'in_list' => 'Pilih metode pembayaran yang valid'
            ],
            'status_pembayaran' => [
                'required' => 'Status pembayaran harus dipilih',
                'in_list' => 'Pilih status pembayaran yang valid'
            ]
        ];
        
        $this->validation->setRules($rules, $messages);
        
        if (!$this->validation->withRequest($this->request)->run()) {
            return redirect()->to('/pembayaran')
                           ->withInput()
                           ->with('errors', $this->validation->getErrors());
        }
        
        // Ambil data dari form
        $postData = $this->request->getPost();
        
        // Cek duplikasi pembayaran
        $existing = $this->pembayaranModel
            ->where('id_siswa', $postData['id_siswa'])
            ->where('bulan', $postData['bulan'])
            ->where('tahun', $postData['tahun'])
            ->first();
        
        if ($existing) {
            return redirect()->to('/pembayaran')
                           ->withInput()
                           ->with('error', 'Siswa sudah melakukan pembayaran untuk bulan dan tahun ini');
        }
        
        // Ambil data SPP untuk validasi jumlah
        $sppData = $this->sppModel->find($postData['id_spp']);
        
        // Format jumlah bayar (hapus titik jika ada)
        $jumlah_bayar = str_replace('.', '', $postData['jumlah_bayar']);
        $jumlah_bayar = (float) $jumlah_bayar;
        
        // Validasi jika status Lunas tapi jumlah kurang dari nominal SPP
        if ($postData['status_pembayaran'] == 'Lunas' && $sppData) {
            $sppNominal = is_object($sppData) ? $sppData->nominal : $sppData['nominal'];
            if ($jumlah_bayar < $sppNominal) {
                return redirect()->to('/pembayaran')
                               ->withInput()
                               ->with('error', 'Status Lunas tidak valid karena jumlah bayar kurang dari nominal SPP (Rp ' . number_format($sppNominal, 0, ',', '.') . ')');
            }
        }
        
        // Data untuk disimpan
        $data = [
            'id_siswa' => $postData['id_siswa'],
            'id_spp' => $postData['id_spp'],
            'bulan' => $postData['bulan'],
            'tahun' => $postData['tahun'],
            'tanggal_bayar' => date('Y-m-d H:i:s'),
            'jumlah_bayar' => $jumlah_bayar,
            'metode_pembayaran' => $postData['metode_pembayaran'],
            'keterangan' => $postData['keterangan'] ?? '',
            'status_pembayaran' => $postData['status_pembayaran'],
            'id_user' => session()->get('user_id'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        // Simpan menggunakan Model
        if ($this->pembayaranModel->insert($data)) {
            // Ambil data siswa untuk log
            $siswa = $this->siswaModel->find($data['id_siswa']);
            $nama_siswa = is_object($siswa) ? $siswa->nama_siswa : $siswa['nama_siswa'];
            
            // Log activity
            $this->logActivity('Menambahkan pembayaran SPP untuk siswa: ' . $nama_siswa . 
                             ' - ' . $data['bulan'] . ' ' . $data['tahun'] . 
                             ' - Rp ' . number_format($data['jumlah_bayar'], 0, ',', '.') . 
                             ' - Status: ' . $data['status_pembayaran']);
            
            return redirect()->to('/pembayaran')->with('success', 'Pembayaran berhasil dicatat');
        } else {
            return redirect()->to('/pembayaran')
                           ->withInput()
                           ->with('error', 'Gagal menyimpan data pembayaran');
        }
    }

    public function delete($id = null)
    {
        if (!$id) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'ID tidak ditemukan'
                ]);
            }
            return redirect()->to('/pembayaran')->with('error', 'ID tidak ditemukan');
        }
        
        $pembayaran = $this->pembayaranModel->find($id);
        
        if (!$pembayaran) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Data pembayaran tidak ditemukan'
                ]);
            }
            return redirect()->to('/pembayaran')->with('error', 'Data pembayaran tidak ditemukan');
        }
        
        try {
            // Ambil informasi sebelum dihapus untuk log
            if (is_object($pembayaran)) {
                $info = $pembayaran->id_siswa . '-' . $pembayaran->bulan . '-' . $pembayaran->tahun;
            } else {
                $info = $pembayaran['id_siswa'] . '-' . $pembayaran['bulan'] . '-' . $pembayaran['tahun'];
            }
            
            // Hapus dari database
            if ($this->pembayaranModel->delete($id)) {
                // Log activity
                $this->logActivity('Menghapus pembayaran SPP ID: ' . $id . ' - Info: ' . $info);
                
                if ($this->request->isAJAX()) {
                    return $this->response->setJSON([
                        'success' => true,
                        'message' => 'Data pembayaran berhasil dihapus'
                    ]);
                }
                
                return redirect()->to('/pembayaran')
                               ->with('show_popup_success', true)
                               ->with('popup_title', 'Berhasil!')
                               ->with('popup_message', 'Data pembayaran berhasil dihapus')
                               ->with('success', 'Data pembayaran berhasil dihapus');
            } else {
                if ($this->request->isAJAX()) {
                    return $this->response->setJSON([
                        'success' => false,
                        'message' => 'Gagal menghapus data pembayaran'
                    ]);
                }
                return redirect()->to('/pembayaran')->with('error', 'Gagal menghapus data pembayaran');
            }
            
        } catch (\Exception $e) {
            log_message('error', 'Error deleting payment: ' . $e->getMessage());
            
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Gagal menghapus data: ' . $e->getMessage()
                ]);
            }
            return redirect()->to('/pembayaran')->with('error', 'Gagal menghapus data: ' . $e->getMessage());
        }
    }

    public function editForm($id = null)
    {
        if (!$this->request->isAJAX()) {
            return $this->fail('Invalid request', 400);
        }

        if (!$id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'ID tidak valid'
            ]);
        }

        try {
            // Get payment data with details
            $builder = $this->pembayaranModel->db->table('pembayaran p');
            $builder->select('p.*, s.nisn, s.nama_siswa, k.nama_kelas, sp.tahun_ajaran, sp.nominal as spp_nominal, u.nama_lengkap as petugas');
            $builder->join('siswa s', 's.id = p.id_siswa');
            $builder->join('kelas k', 'k.id = s.id_kelas', 'left');
            $builder->join('spp sp', 'sp.id = p.id_spp', 'left');
            $builder->join('users u', 'u.id = p.id_user', 'left');
            $builder->where('p.id', $id);

            $pembayaran = $builder->get()->getRowArray();

            if (!$pembayaran) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Data pembayaran tidak ditemukan'
                ]);
            }

            // Generate edit form HTML
            $bulan_list = $this->getBulanList();
            $tahun_list = $this->getTahunList();

            $html = '<div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Siswa</label>
                            <input type="text" class="form-control" value="' . htmlspecialchars($pembayaran['nama_siswa'] . ' (NISN: ' . $pembayaran['nisn'] . ')') . '" readonly>
                            <small class="text-muted">Data siswa tidak dapat diubah</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Kelas</label>
                            <input type="text" class="form-control" value="' . htmlspecialchars($pembayaran['nama_kelas'] ?? 'Belum ada kelas') . '" readonly>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="editBulan" class="form-label">Bulan <span class="text-danger">*</span></label>
                            <select class="form-select" id="editBulan" name="bulan" required>';
            foreach ($bulan_list as $bulan_option) {
                $selected = ($bulan_option == $pembayaran['bulan']) ? 'selected' : '';
                $html .= '<option value="' . $bulan_option . '" ' . $selected . '>' . $bulan_option . '</option>';
            }
            $html .= '</select>
                            <div class="invalid-feedback" id="bulan_error"></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="editTahun" class="form-label">Tahun <span class="text-danger">*</span></label>
                            <select class="form-select" id="editTahun" name="tahun" required>';
            foreach ($tahun_list as $tahun_option) {
                $selected = ($tahun_option == $pembayaran['tahun']) ? 'selected' : '';
                $html .= '<option value="' . $tahun_option . '" ' . $selected . '>' . $tahun_option . '</option>';
            }
            $html .= '</select>
                            <div class="invalid-feedback" id="tahun_error"></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="editStatus" class="form-label">Status Pembayaran <span class="text-danger">*</span></label>
                            <select class="form-select" id="editStatus" name="status_pembayaran" required>
                                <option value="Lunas" ' . ($pembayaran['status_pembayaran'] == 'Lunas' ? 'selected' : '') . '>Lunas</option>
                                <option value="Belum Lunas" ' . ($pembayaran['status_pembayaran'] == 'Belum Lunas' ? 'selected' : '') . '>Belum Lunas</option>
                            </select>
                            <div class="invalid-feedback" id="status_pembayaran_error"></div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="editJumlahBayar" class="form-label">Jumlah Bayar <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number"
                                       class="form-control"
                                       id="editJumlahBayar"
                                       name="jumlah_bayar"
                                       value="' . $pembayaran['jumlah_bayar'] . '"
                                       min="1000"
                                       step="1000"
                                       required>
                            </div>
                            <small class="text-muted">Isi tanpa titik/koma (contoh: 500000)</small>
                            <div class="invalid-feedback" id="jumlah_bayar_error"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="editMetode" class="form-label">Metode Pembayaran <span class="text-danger">*</span></label>
                            <select class="form-select" id="editMetode" name="metode_pembayaran" required>
                                <option value="Tunai" ' . ($pembayaran['metode_pembayaran'] == 'Tunai' ? 'selected' : '') . '>Tunai</option>
                                <option value="Transfer" ' . ($pembayaran['metode_pembayaran'] == 'Transfer' ? 'selected' : '') . '>Transfer</option>
                                <option value="QRIS" ' . ($pembayaran['metode_pembayaran'] == 'QRIS' ? 'selected' : '') . '>QRIS</option>
                            </select>
                            <div class="invalid-feedback" id="metode_pembayaran_error"></div>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="editKeterangan" class="form-label">Keterangan</label>
                    <textarea class="form-control" id="editKeterangan" name="keterangan" rows="3"
                              placeholder="Catatan tambahan pembayaran...">' . htmlspecialchars($pembayaran['keterangan'] ?? '') . '</textarea>
                    <div class="invalid-feedback" id="keterangan_error"></div>
                </div>

                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i>
                    <strong>Informasi:</strong> Tarif SPP: Rp ' . number_format($pembayaran['spp_nominal'] ?? 0, 0, ',', '.') . '/bulan
                </div>';

            return $this->response->setJSON([
                'success' => true,
                'html' => $html
            ]);

        } catch (\Exception $e) {
            log_message('error', 'Error in editForm: ' . $e->getMessage());

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Terjadi kesalahan sistem. ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    public function edit($id = null)
    {
        if (!$id) {
            return redirect()->to('/pembayaran')->with('error', 'ID tidak ditemukan');
        }

        $pembayaran = $this->pembayaranModel->find($id);

        if (!$pembayaran) {
            return redirect()->to('/pembayaran')->with('error', 'Data pembayaran tidak ditemukan');
        }

        // Jika form disubmit via AJAX
        if ($this->request->isAJAX() && $this->request->getMethod() === 'post') {
            return $this->updateAjax($id);
        }

        // Jika form disubmit via regular POST
        if ($this->request->getMethod() === 'post') {
            $rules = [
                'jumlah_bayar' => 'required|numeric|greater_than[0]',
                'metode_pembayaran' => 'required|in_list[Tunai,Transfer,QRIS]',
                'keterangan' => 'permit_empty',
                'status_pembayaran' => 'required|in_list[Lunas,Belum Lunas]'
            ];

            $this->validation->setRules($rules);

            if ($this->validation->withRequest($this->request)->run()) {
                $postData = $this->request->getPost();

                // Format jumlah bayar
                $jumlah_bayar = str_replace('.', '', $postData['jumlah_bayar']);
                $jumlah_bayar = (float) $jumlah_bayar;

                // Validasi status Lunas
                if ($postData['status_pembayaran'] == 'Lunas') {
                    // Ambil data SPP untuk validasi
                    $pembayaranData = is_object($pembayaran) ? (array) $pembayaran : $pembayaran;
                    $sppData = $this->sppModel->find($pembayaranData['id_spp']);
                    if ($sppData) {
                        $sppNominal = is_object($sppData) ? $sppData->nominal : $sppData['nominal'];
                        if ($jumlah_bayar < $sppNominal) {
                            return redirect()->to('/pembayaran/edit/' . $id)
                                           ->withInput()
                                           ->with('error', 'Status Lunas tidak valid karena jumlah bayar kurang dari nominal SPP (Rp ' . number_format($sppNominal, 0, ',', '.') . ')');
                        }
                    }
                }

                // Update data
                $data = [
                    'id' => $id,
                    'bulan' => $postData['bulan'] ?? $pembayaranData['bulan'],
                    'tahun' => $postData['tahun'] ?? $pembayaranData['tahun'],
                    'jumlah_bayar' => $jumlah_bayar,
                    'metode_pembayaran' => $postData['metode_pembayaran'],
                    'keterangan' => $postData['keterangan'] ?? '',
                    'status_pembayaran' => $postData['status_pembayaran'],
                    'updated_at' => date('Y-m-d H:i:s')
                ];

                if ($this->pembayaranModel->update($id, $data)) {
                    $this->logActivity('Mengedit pembayaran SPP ID: ' . $id);
                    return redirect()->to('/pembayaran')->with('success', 'Data pembayaran berhasil diupdate');
                } else {
                    return redirect()->to('/pembayaran/edit/' . $id)
                                   ->withInput()
                                   ->with('error', 'Gagal mengupdate data pembayaran');
                }
            }
        }

        // Tampilkan halaman edit (untuk non-AJAX)
        $data = [
            'title' => 'Edit Pembayaran SPP',
            'page_title' => 'Edit Pembayaran',
            'active_menu' => 'pembayaran',
            'pembayaran' => is_object($pembayaran) ? (array) $pembayaran : $pembayaran,
            'validation' => $this->validation,
            'user' => session()->get()
        ];

        return view('admin/edit_pembayaran', $data);
    }
    
   public function updateAjax()
{
    try {
        // Get ID from POST data
        $id = $this->request->getPost('id');
        if (!$id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'ID pembayaran tidak ditemukan'
            ]);
        }

        // Validasi input
        $validation = \Config\Services::validation();

        $rules = [
            'bulan' => 'required',
            'tahun' => 'required|numeric|exact_length[4]',
            'jumlah_bayar' => 'required|numeric|greater_than[0]',
            'metode_pembayaran' => 'required|in_list[Tunai,Transfer,QRIS]',
            'keterangan' => 'permit_empty',
            'status_pembayaran' => 'required|in_list[Lunas,Belum Lunas]'
        ];

        if (!$validation->setRules($rules)->withRequest($this->request)->run()) {
            return $this->response->setJSON([
                'success' => false,
                'errors' => $validation->getErrors()
            ]);
        }

        // Ambil data dari POST
        $postData = $this->request->getPost();

        // Cek data pembayaran yang akan diedit
        $currentPayment = $this->pembayaranModel->find($id);
        if (!$currentPayment) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Data pembayaran tidak ditemukan'
            ]);
        }

        // Konversi ke array jika object
        if (is_object($currentPayment)) {
            $currentPayment = (array) $currentPayment;
        }

        // Format jumlah bayar
        $jumlah_bayar = str_replace(['.', ','], '', $postData['jumlah_bayar']);
        $jumlah_bayar = (float) $jumlah_bayar;

        // Validasi status Lunas
        if ($postData['status_pembayaran'] == 'Lunas') {
            $sppData = $this->sppModel->find($currentPayment['id_spp']);
            if ($sppData) {
                $sppNominal = is_object($sppData) ? $sppData->nominal : $sppData['nominal'];
                if ($jumlah_bayar < $sppNominal) {
                    return $this->response->setJSON([
                        'success' => false,
                        'message' => 'Status Lunas tidak valid karena jumlah bayar kurang dari nominal SPP'
                    ]);
                }
            }
        }

        // Data untuk update
        $updateData = [
            'bulan' => $postData['bulan'],
            'tahun' => $postData['tahun'],
            'jumlah_bayar' => $jumlah_bayar,
            'metode_pembayaran' => $postData['metode_pembayaran'],
            'status_pembayaran' => $postData['status_pembayaran'],
            'keterangan' => $postData['keterangan'] ?? '',
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Update data
        $result = $this->pembayaranModel->update($id, $updateData);

        if ($result) {
            $this->logActivity('Mengedit pembayaran SPP ID: ' . $id);
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Data pembayaran berhasil diupdate'
            ]);
        } else {
            $error = $this->pembayaranModel->errors();
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Gagal mengupdate data pembayaran',
                'errors' => $error
            ]);
        }

    } catch (\Exception $e) {
        log_message('error', 'Update AJAX Error: ' . $e->getMessage());

        // Return JSON error yang pasti valid
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Terjadi kesalahan sistem: ' . $e->getMessage()
        ]);
    }
}

    // ============================
    // AJAX METHODS
    // ============================
    
    public function view($id = null)
    {
        if (!$this->request->isAJAX()) {
            return $this->fail('Invalid request', 400);
        }

        if (!$id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'ID tidak valid'
            ]);
        }

        try {
            // Get payment data with details
            $builder = $this->pembayaranModel->db->table('pembayaran p');
            $builder->select('p.*, s.nisn, s.nama_siswa, k.nama_kelas, sp.tahun_ajaran, sp.nominal as spp_nominal, u.nama_lengkap as petugas');
            $builder->join('siswa s', 's.id = p.id_siswa');
            $builder->join('kelas k', 'k.id = s.id_kelas', 'left');
            $builder->join('spp sp', 'sp.id = p.id_spp', 'left');
            $builder->join('users u', 'u.id = p.id_user', 'left');
            $builder->where('p.id', $id);

            $pembayaran = $builder->get()->getRowArray();

            if (!$pembayaran) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Data pembayaran tidak ditemukan'
                ]);
            }

            // Format data untuk response
            $tanggalBayar = strtotime($pembayaran['tanggal_bayar']);

            $responseData = [
                'success' => true,
                'data' => [
                    'id' => $pembayaran['id'],
                    'tanggal_bayar_formatted' => date('d/m/Y', $tanggalBayar),
                    'nama_siswa' => $pembayaran['nama_siswa'],
                    'nisn' => $pembayaran['nisn'],
                    'nama_kelas' => $pembayaran['nama_kelas'] ?? 'Belum ada kelas',
                    'bulan' => $pembayaran['bulan'],
                    'tahun' => $pembayaran['tahun'],
                    'jumlah_bayar_formatted' => 'Rp ' . number_format($pembayaran['jumlah_bayar'], 0, ',', '.'),
                    'metode_pembayaran' => $pembayaran['metode_pembayaran'],
                    'status_pembayaran' => $pembayaran['status_pembayaran'] ?? 'Belum Lunas',
                    'petugas' => $pembayaran['petugas'] ?? 'System',
                    'keterangan' => $pembayaran['keterangan'] ?? '-'
                ]
            ];

            return $this->response->setJSON($responseData);

        } catch (\Exception $e) {
            log_message('error', 'Error in view payment: ' . $e->getMessage());

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Terjadi kesalahan sistem. ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    public function get($id = null)
{
    if (!$this->request->isAJAX()) {
        return $this->fail('Invalid request', 400);
    }

    if (!$id) {
        return $this->response->setJSON([
            'success' => false,
            'message' => 'ID tidak valid'
        ]);
    }

    try {
        // Gunakan method dari model yang sudah ada
        $pembayaran = $this->pembayaranModel->getPembayaranWithDetails($id);

        if (!$pembayaran) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Data pembayaran tidak ditemukan'
            ]);
        }

        // Convert object to array if needed
        $pembayaranData = is_object($pembayaran) ? (array) $pembayaran : $pembayaran;

        // Format data untuk response
        $tanggalBayar = isset($pembayaranData['tanggal_bayar']) ?
            strtotime($pembayaranData['tanggal_bayar']) : time();

        $createdAt = isset($pembayaranData['created_at']) ?
            strtotime($pembayaranData['created_at']) : time();

        $updatedAt = isset($pembayaranData['updated_at']) ?
            strtotime($pembayaranData['updated_at']) : time();

        $responseData = [
            'success' => true,
            'data' => [
                'id' => $pembayaranData['id'] ?? 0,
                'tanggal_bayar' => date('d/m/Y H:i:s', $tanggalBayar),
                'tanggal_bayar_formatted' => date('d/m/Y', $tanggalBayar),
                'jam_bayar' => date('H:i', $tanggalBayar),
                'nama_siswa' => $pembayaranData['nama_siswa'] ?? '',
                'nisn' => $pembayaranData['nisn'] ?? '',
                'nama_kelas' => $pembayaranData['nama_kelas'] ?? 'Belum ada kelas',
                'bulan' => $pembayaranData['bulan'] ?? '',
                'tahun' => $pembayaranData['tahun'] ?? '',
                'jumlah_bayar' => $pembayaranData['jumlah_bayar'] ?? 0,
                'jumlah_bayar_raw' => $pembayaranData['jumlah_bayar'] ?? 0,
                'jumlah_bayar_formatted' => 'Rp ' . number_format($pembayaranData['jumlah_bayar'] ?? 0, 0, ',', '.'),
                'metode_pembayaran' => $pembayaranData['metode_pembayaran'] ?? 'Tunai',
                'status_pembayaran' => $pembayaranData['status_pembayaran'] ?? 'Belum Lunas',
                'petugas' => $pembayaranData['petugas'] ?? 'System',
                'spp_nominal' => $pembayaranData['nominal'] ?? 0,
                'spp_nominal_formatted' => 'Rp ' . number_format($pembayaranData['nominal'] ?? 0, 0, ',', '.'),
                'tahun_ajaran' => $pembayaranData['tahun_ajaran'] ?? '-',
                'keterangan' => $pembayaranData['keterangan'] ?? '-',
                'created_at' => date('d/m/Y H:i:s', $createdAt),
                'updated_at' => date('d/m/Y H:i:s', $updatedAt)
            ]
        ];

        // Pastikan respons JSON valid
        return $this->response->setJSON($responseData);

    } catch (\Exception $e) {
        log_message('error', 'Error in get payment: ' . $e->getMessage());

        // Return JSON yang pasti valid
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Terjadi kesalahan sistem. ' . $e->getMessage()
        ])->setStatusCode(500);
    }
}
    
    public function getSiswaInfo($id_siswa = null)
    {
        if (!$this->request->isAJAX()) {
            return $this->fail('Invalid request', 400);
        }
        
        try {
            if (empty($id_siswa)) {
                return $this->respond([
                    'success' => false,
                    'message' => 'ID siswa tidak valid'
                ]);
            }
            
            // Get siswa data with kelas
            $builder = $this->siswaModel->db->table('siswa s');
            $builder->select('s.id, s.nisn, s.nama_siswa, k.nama_kelas, k.tingkat');
            $builder->join('kelas k', 'k.id = s.id_kelas', 'left');
            $builder->where('s.id', $id_siswa);
            $builder->where('s.status', 'active');
            
            $siswa = $builder->get()->getRowArray();
            
            if (!$siswa) {
                return $this->respond([
                    'success' => false,
                    'message' => 'Siswa tidak ditemukan'
                ]);
            }
            
            // Get SPP data based on student's class level
            $currentTahunAjaran = $this->getCurrentAcademicYear();
            $spp = $this->sppModel
                ->where('tingkat', $siswa['tingkat'] ?? 'X')
                ->where('tahun_ajaran', $currentTahunAjaran)
                ->first();
            
            if ($spp && is_object($spp)) {
                $spp = (array) $spp;
            }
            
            // Get payment history for this student in current year
            $currentYear = date('Y');
            $builder = $this->pembayaranModel->db->table('pembayaran p');
            $builder->select('p.*');
            $builder->where('p.id_siswa', $id_siswa);
            $builder->where('p.tahun', $currentYear);
            $builder->orderBy('FIELD(p.bulan, "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")');
            
            $pembayaran = $builder->get()->getResultArray();
            
            // Format months
            $months = $this->getBulanList();
            
            $paidMonths = [];
            $totalPaid = 0;
            $paymentHistory = [];
            
            foreach ($pembayaran as $p) {
                $paidMonths[] = $p['bulan'];
                $totalPaid += $p['jumlah_bayar'];
                
                $paymentHistory[] = [
                    'id' => $p['id'],
                    'bulan' => $p['bulan'],
                    'tahun' => $p['tahun'],
                    'jumlah_bayar' => $p['jumlah_bayar'],
                    'jumlah_bayar_formatted' => 'Rp ' . number_format($p['jumlah_bayar'], 0, ',', '.'),
                    'metode_pembayaran' => $p['metode_pembayaran'],
                    'status_pembayaran' => $p['status_pembayaran'] ?? 'Belum Lunas',
                    'tanggal_bayar' => $p['tanggal_bayar'],
                    'tanggal_bayar_formatted' => date('d/m/Y', strtotime($p['tanggal_bayar']))
                ];
            }
            
            $unpaidMonths = array_values(array_diff($months, $paidMonths));
            
            // Prepare response
            $response = [
                'success' => true,
                'siswa' => [
                    'id' => $siswa['id'],
                    'nisn' => $siswa['nisn'],
                    'nama_siswa' => $siswa['nama_siswa'],
                    'nama_kelas' => $siswa['nama_kelas'] ?? 'Belum ada kelas',
                    'tingkat' => $siswa['tingkat'] ?? 'X',
                ],
                'spp' => $spp ? [
                    'id' => $spp['id'],
                    'nominal' => $spp['nominal'],
                    'nominal_formatted' => 'Rp ' . number_format($spp['nominal'], 0, ',', '.'),
                    'tahun_ajaran' => $spp['tahun_ajaran'],
                    'tingkat' => $spp['tingkat']
                ] : null,
                'total_paid' => $totalPaid,
                'total_paid_formatted' => 'Rp ' . number_format($totalPaid, 0, ',', '.'),
                'paid_months' => $paidMonths,
                'unpaid_months' => $unpaidMonths,
                'payment_history' => $paymentHistory
            ];
            
            return $this->response->setJSON($response);
            
        } catch (\Exception $e) {
            log_message('error', 'Error in getSiswaInfo: ' . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Terjadi kesalahan sistem: ' . $e->getMessage()
            ]);
        }
    }
    
    public function checkDuplicate()
    {
        if (!$this->request->isAJAX()) {
            return $this->fail('Invalid request', 400);
        }
        
        $id_siswa = $this->request->getPost('id_siswa');
        $bulan = $this->request->getPost('bulan');
        $tahun = $this->request->getPost('tahun');
        
        if (!$id_siswa || !$bulan || !$tahun) {
            return $this->response->setJSON([
                'exists' => false
            ]);
        }
        
        $existing = $this->pembayaranModel
            ->where('id_siswa', $id_siswa)
            ->where('bulan', $bulan)
            ->where('tahun', $tahun)
            ->first();
        
        return $this->response->setJSON([
            'exists' => $existing ? true : false
        ]);
    }
    
    public function search()
    {
        if (!$this->request->isAJAX()) {
            return $this->fail('Invalid request', 400);
        }
        
        $keyword = $this->request->getGet('keyword');
        $bulan = $this->request->getGet('bulan');
        $tahun = $this->request->getGet('tahun');
        $status = $this->request->getGet('status');
        $metode = $this->request->getGet('metode');
        
        $builder = $this->pembayaranModel->db->table('pembayaran p');
        $builder->select('p.*, s.nisn, s.nama_siswa, k.nama_kelas, sp.tahun_ajaran, sp.nominal as spp_nominal, u.nama_lengkap as petugas');
        $builder->join('siswa s', 's.id = p.id_siswa');
        $builder->join('kelas k', 'k.id = s.id_kelas', 'left');
        $builder->join('spp sp', 'sp.id = p.id_spp', 'left');
        $builder->join('users u', 'u.id = p.id_user', 'left');
        
        if ($keyword) {
            $builder->groupStart()
                   ->like('s.nama_siswa', $keyword)
                   ->orLike('s.nisn', $keyword)
                   ->orLike('p.bulan', $keyword)
                   ->groupEnd();
        }
        
        if ($bulan && $bulan != '') {
            $builder->where('p.bulan', $bulan);
        }
        
        if ($tahun && $tahun != '') {
            $builder->where('p.tahun', $tahun);
        }
        
        if ($status && $status != '') {
            $builder->where('p.status_pembayaran', $status);
        }
        
        if ($metode && $metode != '') {
            $builder->where('p.metode_pembayaran', $metode);
        }
        
        $builder->orderBy('p.tanggal_bayar', 'DESC');
        $pembayaran = $builder->get()->getResultArray();
        
        // Format data
        $formattedData = [];
        foreach ($pembayaran as $p) {
            if (!isset($p['status_pembayaran'])) {
                $p['status_pembayaran'] = 'Belum Lunas';
            }
            
            $formattedData[] = [
                'id' => $p['id'],
                'tanggal_bayar' => $p['tanggal_bayar'],
                'tanggal_bayar_formatted' => date('d/m/Y', strtotime($p['tanggal_bayar'])),
                'jam_bayar' => date('H:i', strtotime($p['tanggal_bayar'])),
                'nama_siswa' => $p['nama_siswa'],
                'nisn' => $p['nisn'],
                'nama_kelas' => $p['nama_kelas'] ?? 'Belum ada kelas',
                'bulan' => $p['bulan'],
                'tahun' => $p['tahun'],
                'jumlah_bayar' => $p['jumlah_bayar'],
                'jumlah_bayar_formatted' => 'Rp ' . number_format($p['jumlah_bayar'], 0, ',', '.'),
                'spp_nominal' => $p['spp_nominal'] ?? 0,
                'spp_nominal_formatted' => $p['spp_nominal'] ? 'Rp ' . number_format($p['spp_nominal'], 0, ',', '.') : '',
                'metode_pembayaran' => $p['metode_pembayaran'],
                'status_pembayaran' => $p['status_pembayaran'],
                'petugas' => $p['petugas'] ?? 'System'
            ];
        }
        
        return $this->response->setJSON([
            'success' => true,
            'data' => $formattedData
        ]);
    }
    
    // ============================
    // REPORT METHODS (Tetap sama)
    // ============================
    
    public function report()
    {
        $bulan = $this->request->getGet('bulan') ?? date('F');
        $tahun = $this->request->getGet('tahun') ?? date('Y');
        $id_siswa = $this->request->getGet('id_siswa');
        $id_kelas = $this->request->getGet('id_kelas');
        $status = $this->request->getGet('status');
        
        $builder = $this->pembayaranModel->db->table('pembayaran p');
        $builder->select('p.*, s.nisn, s.nama_siswa, k.nama_kelas, sp.tahun_ajaran, sp.nominal as spp_nominal, u.nama_lengkap as petugas');
        $builder->join('siswa s', 's.id = p.id_siswa');
        $builder->join('kelas k', 'k.id = s.id_kelas', 'left');
        $builder->join('spp sp', 'sp.id = p.id_spp', 'left');
        $builder->join('users u', 'u.id = p.id_user', 'left');
        
        if ($bulan && $bulan != 'all') {
            $builder->where('p.bulan', $bulan);
        }
        
        if ($tahun && $tahun != 'all') {
            $builder->where('p.tahun', $tahun);
        }
        
        if ($id_siswa) {
            $builder->where('p.id_siswa', $id_siswa);
        }
        
        if ($id_kelas) {
            $builder->where('s.id_kelas', $id_kelas);
        }
        
        if ($status && $status != 'all') {
            $builder->where('p.status_pembayaran', $status);
        }
        
        $builder->orderBy('p.tanggal_bayar', 'DESC');
        $pembayaran = $builder->get()->getResultArray();
        
        // Pastikan status_pembayaran ada
        foreach ($pembayaran as &$p) {
            if (!isset($p['status_pembayaran'])) {
                $p['status_pembayaran'] = 'Belum Lunas';
            }
        }
        
        // Hitung rekap
        $total_pembayaran = 0;
        $total_siswa = [];
        $total_lunas = 0;
        $total_belum_lunas = 0;
        
        foreach ($pembayaran as $p) {
            $total_pembayaran += $p['jumlah_bayar'];
            $total_siswa[$p['id_siswa']] = true;
            
            if ($p['status_pembayaran'] == 'Lunas') {
                $total_lunas++;
            } else {
                $total_belum_lunas++;
            }
        }
        
        $data = [
            'title' => 'Laporan Pembayaran SPP',
            'page_title' => 'Laporan Pembayaran',
            'pembayaran' => $pembayaran,
            'rekap' => [
                'total_pembayaran' => $total_pembayaran,
                'total_transaksi' => count($pembayaran),
                'total_siswa' => count($total_siswa),
                'total_lunas' => $total_lunas,
                'total_belum_lunas' => $total_belum_lunas
            ],
            'filter' => [
                'bulan' => $bulan,
                'tahun' => $tahun,
                'id_siswa' => $id_siswa,
                'id_kelas' => $id_kelas,
                'status' => $status
            ],
            'siswa_list' => $this->getSiswaList(),
            'kelas_list' => $this->kelasModel->findAll(),
            'bulan_list' => $this->getBulanList(),
            'tahun_list' => $this->getTahunList(),
            'status_list' => ['Lunas', 'Belum Lunas'],
            'user' => session()->get()
        ];
        
        return view('admin/report_pembayaran', $data);
    }
    
    public function printReceipt($id)
    {
        $builder = $this->pembayaranModel->db->table('pembayaran p');
        $builder->select('p.*, s.nisn, s.nama_siswa, s.alamat as alamat_siswa, k.nama_kelas, sp.tahun_ajaran, sp.nominal as spp_nominal, u.nama_lengkap as petugas');
        $builder->join('siswa s', 's.id = p.id_siswa');
        $builder->join('kelas k', 'k.id = s.id_kelas', 'left');
        $builder->join('spp sp', 'sp.id = p.id_spp', 'left');
        $builder->join('users u', 'u.id = p.id_user', 'left');
        $builder->where('p.id', $id);
        
        $pembayaran = $builder->get()->getRowArray();
        
        if (!$pembayaran) {
            return redirect()->to('/pembayaran')->with('error', 'Data pembayaran tidak ditemukan');
        }
        
        // Pastikan status_pembayaran ada
        if (!isset($pembayaran['status_pembayaran'])) {
            $pembayaran['status_pembayaran'] = 'Belum Lunas';
        }
        
        $data = [
            'title' => 'Kwitansi Pembayaran SPP',
            'pembayaran' => $pembayaran,
            'tanggal_cetak' => date('d/m/Y H:i:s')
        ];
        
        return view('admin/print_receipt', $data);
    }
    
    // ============================
    // HELPER METHODS
    // ============================
    
    private function getPaymentStats()
    {
        $currentMonth = date('F');
        $currentYear = date('Y');
        $today = date('Y-m-d');
        
        $builder = $this->pembayaranModel->db->table('pembayaran');
        
        // Today's total
        $todayTotal = $builder->selectSum('jumlah_bayar')
                             ->where('DATE(tanggal_bayar)', $today)
                             ->get()
                             ->getRowArray();
        $todayTotal = $todayTotal['jumlah_bayar'] ?? 0;
        
        // Month's total
        $monthTotal = $builder->selectSum('jumlah_bayar')
                             ->where('bulan', $currentMonth)
                             ->where('tahun', $currentYear)
                             ->get()
                             ->getRowArray();
        $monthTotal = $monthTotal['jumlah_bayar'] ?? 0;
        
        // Month's transaction count
        $monthCount = $builder->select('COUNT(*) as count')
                             ->where('bulan', $currentMonth)
                             ->where('tahun', $currentYear)
                             ->get()
                             ->getRowArray();
        $monthCount = $monthCount['count'] ?? 0;
        
        // Unique students paid this month
        $paidStudents = $builder->select('COUNT(DISTINCT id_siswa) as count')
                               ->where('bulan', $currentMonth)
                               ->where('tahun', $currentYear)
                               ->get()
                               ->getRowArray();
        $paidStudents = $paidStudents['count'] ?? 0;
        
        // Count Lunas vs Belum Lunas for current month
        $statusCount = $builder->select('status_pembayaran, COUNT(*) as count')
                              ->where('bulan', $currentMonth)
                              ->where('tahun', $currentYear)
                              ->groupBy('status_pembayaran')
                              ->get()
                              ->getResultArray();
        
        $lunasCount = 0;
        $belumLunasCount = 0;
        
        foreach ($statusCount as $status) {
            $statusType = $status['status_pembayaran'] ?? 'Belum Lunas';
            if ($statusType == 'Lunas') {
                $lunasCount = $status['count'];
            } else {
                $belumLunasCount = $status['count'];
            }
        }
        
        return [
            'today_total' => $todayTotal,
            'month_total' => $monthTotal,
            'month_count' => $monthCount,
            'paid_students' => $paidStudents,
            'lunas_count' => $lunasCount,
            'belum_lunas_count' => $belumLunasCount
        ];
    }
    
    private function getBulanList()
    {
        return [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
    }
    
    private function getTahunList()
    {
        $years = [];
        $currentYear = date('Y');
        for ($i = $currentYear - 2; $i <= $currentYear + 1; $i++) {
            $years[] = $i;
        }
        return $years;
    }
    
    private function getCurrentAcademicYear()
    {
        $currentYear = date('Y');
        $currentMonth = date('n');
        
        // Jika bulan Juli atau setelahnya, tahun ajaran adalah tahun ini/tahun depan
        // Jika sebelum Juli, tahun ajaran adalah tahun lalu/tahun ini
        if ($currentMonth >= 7) {
            return $currentYear . '/' . ($currentYear + 1);
        } else {
            return ($currentYear - 1) . '/' . $currentYear;
        }
    }
    
    private function logActivity($activity)
    {
        try {
            $db = \Config\Database::connect();
            
            $data = [
                'user_id' => session()->get('user_id') ?? 0,
                'username' => session()->get('username') ?? 'system',
                'activity' => $activity,
                'ip_address' => $this->request->getIPAddress(),
                'user_agent' => $this->request->getUserAgent()->getAgentString(),
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $db->table('activity_logs')->insert($data);
        } catch (\Exception $e) {
            log_message('error', 'Failed to log activity: ' . $e->getMessage());
        }
    }
}