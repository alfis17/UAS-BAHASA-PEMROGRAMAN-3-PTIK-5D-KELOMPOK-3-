<?php

namespace App\Controllers;

use App\Models\PembayaranModel;
use App\Models\SiswaModel;
use App\Models\KelasModel;
use App\Models\SPPModel;
use App\Models\LaporanModel;

class Laporan extends BaseController
{
    protected $pembayaranModel;
    protected $siswaModel;
    protected $kelasModel;
    protected $sppModel;
    protected $laporanModel;

    public function __construct()
    {
        $this->pembayaranModel = new PembayaranModel();
        $this->siswaModel = new SiswaModel();
        $this->kelasModel = new KelasModel();
        $this->sppModel = new SPPModel();
        $this->laporanModel = new LaporanModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Laporan Pembayaran SPP',
            'pembayaran' => $this->pembayaranModel->findAll(),
            'siswa' => $this->siswaModel->findAll(),
            'kelas' => $this->kelasModel->findAll(),
            'spp' => $this->sppModel->findAll()
        ];

        return view('laporan/index', $data);
    }

    public function index_laporan()
    {
        // Get recent payments with related data
        $pembayaran = $this->pembayaranModel->select('pembayaran.*, siswa.nama_siswa, siswa.nisn, kelas.nama_kelas, spp.tahun_ajaran, spp.nominal')
            ->join('siswa', 'siswa.id = pembayaran.id_siswa')
            ->join('kelas', 'kelas.id = siswa.id_kelas')
            ->join('spp', 'spp.id = pembayaran.id_spp')
            ->orderBy('pembayaran.tanggal_bayar', 'DESC')
            ->findAll();

        $data = [
            'title' => 'Index Laporan Pembayaran',
            'pembayaran' => $pembayaran,
            'total_pembayaran' => count($pembayaran),
            'total_nominal' => array_sum(array_column($pembayaran, 'nominal'))
        ];

        return view('laporan/index_laporan', $data);
    }

    public function cetak()
    {
        $filter = $this->request->getGet();
        $pembayaran = $this->getFilteredPembayaran($filter);

        $data = [
            'title' => 'Cetak Laporan',
            'pembayaran' => $pembayaran,
            'filter' => $filter
        ];

        return view('laporan/cetak', $data);
    }

    public function exportExcel()
    {
        $filter = $this->request->getGet();
        $pembayaran = $this->getFilteredPembayaran($filter);

        // Simple CSV export for now (can be enhanced with proper Excel library)
        $filename = 'laporan_pembayaran_' . date('Y-m-d') . '.csv';

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $output = fopen('php://output', 'w');

        // Header
        fputcsv($output, ['NISN', 'Nama Siswa', 'Kelas', 'Tahun Ajaran', 'Nominal', 'Tanggal Bayar', 'Status']);

        // Data
        foreach ($pembayaran as $row) {
            fputcsv($output, [
                $row['nisn'],
                $row['nama_siswa'],
                $row['nama_kelas'],
                $row['tahun_ajaran'],
                $row['nominal'],
                $row['tanggal_bayar'],
                'Lunas'
            ]);
        }

        fclose($output);
        exit();
    }

    public function filter()
    {
        $filter = $this->request->getGet();
        $pembayaran = $this->getFilteredPembayaran($filter);

        return $this->response->setJSON([
            'success' => true,
            'data' => $pembayaran
        ]);
    }

    public function summary()
    {
        $filter = $this->request->getGet();
        $pembayaran = $this->getFilteredPembayaran($filter);

        $summary = [
            'total_pembayaran' => count($pembayaran),
            'total_nominal' => array_sum(array_column($pembayaran, 'nominal')),
            'rata_rata' => count($pembayaran) > 0 ? array_sum(array_column($pembayaran, 'nominal')) / count($pembayaran) : 0
        ];

        return $this->response->setJSON([
            'success' => true,
            'summary' => $summary
        ]);
    }

    public function tunggakan()
    {
        // Get students who haven't paid for current month
        $currentMonth = date('m');
        $currentYear = date('Y');

        $siswa = $this->siswaModel->select('siswa.*, kelas.nama_kelas, spp.tahun_ajaran, spp.nominal')
            ->join('kelas', 'kelas.id = siswa.id_kelas')
            ->join('spp', 'spp.tahun_ajaran = "' . $this->sppModel->getTahunAjaranAktif() . '"')
            ->findAll();

        $tunggakan = [];
        foreach ($siswa as $s) {
            $paid = $this->pembayaranModel->where('id_siswa', $s['id'])
                ->where('MONTH(tanggal_bayar)', $currentMonth)
                ->where('YEAR(tanggal_bayar)', $currentYear)
                ->countAllResults();

            if ($paid == 0) {
                $tunggakan[] = $s;
            }
        }

        $data = [
            'title' => 'Laporan Tunggakan',
            'tunggakan' => $tunggakan
        ];

        return view('laporan/tunggakan', $data);
    }

    public function keuangan()
    {
        $startDate = $this->request->getGet('start_date') ?? date('Y-m-01');
        $endDate = $this->request->getGet('end_date') ?? date('Y-m-t');

        $pembayaran = $this->pembayaranModel->select('pembayaran.*, spp.nominal')
            ->join('spp', 'spp.id = pembayaran.id_spp')
            ->where('tanggal_bayar >=', $startDate)
            ->where('tanggal_bayar <=', $endDate)
            ->findAll();

        $total = array_sum(array_column($pembayaran, 'nominal'));

        $data = [
            'title' => 'Laporan Keuangan',
            'pembayaran' => $pembayaran,
            'total' => $total,
            'start_date' => $startDate,
            'end_date' => $endDate
        ];

        return view('laporan/keuangan', $data);
    }

    private function getFilteredPembayaran($filter)
    {
        $query = $this->pembayaranModel->select('pembayaran.*, siswa.nama_siswa, siswa.nisn, kelas.nama_kelas, spp.tahun_ajaran, spp.nominal')
            ->join('siswa', 'siswa.id = pembayaran.id_siswa')
            ->join('kelas', 'kelas.id = siswa.id_kelas')
            ->join('spp', 'spp.id = pembayaran.id_spp');

        if (!empty($filter['kelas'])) {
            $query->where('siswa.id_kelas', $filter['kelas']);
        }

        if (!empty($filter['tahun'])) {
            $query->where('spp.tahun_ajaran', $filter['tahun']);
        }

        if (!empty($filter['bulan'])) {
            $query->where('MONTH(pembayaran.tanggal_bayar)', $filter['bulan']);
        }

        if (!empty($filter['start_date']) && !empty($filter['end_date'])) {
            $query->where('pembayaran.tanggal_bayar >=', $filter['start_date'])
                  ->where('pembayaran.tanggal_bayar <=', $filter['end_date']);
        }

        return $query->findAll();
    }
}
