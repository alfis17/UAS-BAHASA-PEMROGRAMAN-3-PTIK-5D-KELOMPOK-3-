<?php

namespace App\Controllers;

use App\Models\KelasModel;

class Kelas extends BaseController
{
    protected $kelasModel;
    
    public function __construct()
    {
        $this->kelasModel = new KelasModel();
    }

    public function index()
    {
        $kelasData = $this->kelasModel->getKelasWithSiswaCount();
        
        // Konversi array ke objek agar bisa diakses dengan $k->property
        $kelasObjects = array_map(function($item) {
            return (object) $item;
        }, $kelasData);
        
        $data = [
            'title' => 'Data Kelas - Sistem SPP',
            'kelas' => $kelasObjects,
            'user' => session()->get()
        ];
        
        return view('admin/index_kelas', $data);
    }

    public function create()
    {
        // Hanya terima AJAX request
        if (!$this->request->isAJAX()) {
            return redirect()->to('/kelas');
        }
        
        $validation = \Config\Services::validation();
        
        $rules = [
            'nama_kelas' => [
                'rules' => 'required|is_unique[kelas.nama_kelas]',
                'errors' => [
                    'required' => 'Nama kelas wajib diisi',
                    'is_unique' => 'Nama kelas sudah digunakan'
                ]
            ],
            'tingkat' => [
                'rules' => 'required|in_list[X,XI,XII]',
                'errors' => [
                    'required' => 'Tingkat wajib dipilih',
                    'in_list' => 'Tingkat tidak valid'
                ]
            ],
            'jurusan' => [
                'rules' => 'required',
                'errors' => ['required' => 'Jurusan wajib diisi']
            ],
            'wali_kelas' => [
                'rules' => 'required',
                'errors' => ['required' => 'Wali kelas wajib diisi']
            ],
            'kapasitas' => [
                'rules' => 'required|numeric|greater_than[0]|less_than_equal_to[50]',
                'errors' => [
                    'required' => 'Kapasitas wajib diisi',
                    'numeric' => 'Kapasitas harus angka',
                    'greater_than' => 'Kapasitas harus lebih dari 0',
                    'less_than_equal_to' => 'Kapasitas maksimal 50 siswa'
                ]
            ]
        ];
        
        $validation->setRules($rules);
        
        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Validasi gagal',
                'errors' => $validation->getErrors()
            ]);
        }
        
        $data = [
            'nama_kelas' => $this->request->getPost('nama_kelas'),
            'tingkat' => $this->request->getPost('tingkat'),
            'jurusan' => $this->request->getPost('jurusan'),
            'wali_kelas' => $this->request->getPost('wali_kelas'),
            'kapasitas' => $this->request->getPost('kapasitas'),
        ];
        
        try {
            // Nonaktifkan validation model sementara
            $this->kelasModel->skipValidation(true);
            
            if ($this->kelasModel->save($data)) {
                $response = [
                    'success' => true,
                    'message' => 'Data kelas berhasil ditambahkan'
                ];
            } else {
                $response = [
                    'success' => false,
                    'message' => 'Gagal menambahkan data kelas'
                ];
            }
            
            $this->kelasModel->skipValidation(false);
            
            return $this->response->setJSON($response);
        } catch (\Exception $e) {
            $this->kelasModel->skipValidation(false);
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ]);
        }
    }

    public function update($id)
    {
        // Hanya terima AJAX request
        if (!$this->request->isAJAX()) {
            return redirect()->to('/kelas');
        }
        
        $validation = \Config\Services::validation();
        
        $rules = [
            'nama_kelas' => [
                'rules' => "required|is_unique[kelas.nama_kelas,id,{$id}]",
                'errors' => [
                    'required' => 'Nama kelas wajib diisi',
                    'is_unique' => 'Nama kelas sudah digunakan'
                ]
            ],
            'tingkat' => [
                'rules' => 'required|in_list[X,XI,XII]',
                'errors' => [
                    'required' => 'Tingkat wajib dipilih',
                    'in_list' => 'Tingkat tidak valid'
                ]
            ],
            'jurusan' => [
                'rules' => 'required',
                'errors' => ['required' => 'Jurusan wajib diisi']
            ],
            'wali_kelas' => [
                'rules' => 'required',
                'errors' => ['required' => 'Wali kelas wajib diisi']
            ],
            'kapasitas' => [
                'rules' => 'required|numeric|greater_than[0]|less_than_equal_to[50]',
                'errors' => [
                    'required' => 'Kapasitas wajib diisi',
                    'numeric' => 'Kapasitas harus angka',
                    'greater_than' => 'Kapasitas harus lebih dari 0',
                    'less_than_equal_to' => 'Kapasitas maksimal 50 siswa'
                ]
            ]
        ];
        
        $validation->setRules($rules);
        
        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Validasi gagal',
                'errors' => $validation->getErrors()
            ]);
        }
        
        $data = [
            'nama_kelas' => $this->request->getPost('nama_kelas'),
            'tingkat' => $this->request->getPost('tingkat'),
            'jurusan' => $this->request->getPost('jurusan'),
            'wali_kelas' => $this->request->getPost('wali_kelas'),
            'kapasitas' => $this->request->getPost('kapasitas'),
        ];
        
        try {
            // Nonaktifkan validation model sementara
            $this->kelasModel->skipValidation(true);
            
            $result = $this->kelasModel->update($id, $data);
            
            $this->kelasModel->skipValidation(false);
            
            if ($result) {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'Data kelas berhasil diperbarui'
                ]);
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Gagal memperbarui data kelas'
                ]);
            }
        } catch (\Exception $e) {
            $this->kelasModel->skipValidation(false);
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Terjadi kesalahan: ' . $e->getMessage()
            ]);
        }
    }

    public function delete($id)
    {
        // Cek apakah ada siswa di kelas ini
        $db = \Config\Database::connect();
        $siswaCount = $db->table('siswa')->where('id_kelas', $id)->countAllResults();
        
        if ($siswaCount > 0) {
            session()->setFlashdata('error', 'Kelas tidak dapat dihapus karena masih memiliki ' . $siswaCount . ' siswa');
            return redirect()->to('/kelas');
        }
        
        if ($this->kelasModel->delete($id)) {
            // Set flashdata khusus untuk popup delete
            session()->setFlashdata('show_popup_success', true);
            session()->setFlashdata('popup_message', 'Data kelas berhasil dihapus');
            session()->setFlashdata('popup_title', 'Berhasil!');
        } else {
            session()->setFlashdata('error', 'Gagal menghapus data kelas');
        }
        
        return redirect()->to('/kelas');
    }
    
    public function checkNamaKelas()
    {
        if (!$this->request->isAJAX()) {
            return redirect()->to('/kelas');
        }
        
        $nama_kelas = $this->request->getPost('nama_kelas');
        $id = $this->request->getPost('id'); // Untuk edit
        
        if ($id) {
            // Untuk edit: cek apakah nama kelas sudah ada selain id ini
            $existing = $this->kelasModel
                ->where('nama_kelas', $nama_kelas)
                ->where('id !=', $id)
                ->first();
        } else {
            // Untuk tambah: cek apakah nama kelas sudah ada
            $existing = $this->kelasModel
                ->where('nama_kelas', $nama_kelas)
                ->first();
        }
        
        $is_unique = !$existing;
        
        return $this->response->setJSON([
            'is_unique' => $is_unique,
            'message' => $is_unique ? 'Nama kelas tersedia' : 'Nama kelas sudah digunakan'
        ]);
    }
}