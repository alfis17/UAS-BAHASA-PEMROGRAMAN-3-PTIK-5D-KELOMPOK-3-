<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

abstract class BaseController extends Controller
{
    protected $request;
    protected $helpers = ['form', 'url', 'session']; // TAMBAHKAN HELPER
    
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        
        // Load session
        $this->session = \Config\Services::session();
    }
    // Method untuk mendapatkan tahun ajaran aktif
protected function getTahunAjaranAktif()
{
    // Logika: ambil tahun ajaran dari setting, atau berdasarkan tanggal sekarang
    $bulan = date('n'); // Bulan saat ini (1-12)
    $tahun = date('Y');
    
    // Jika bulan Juli-Desember, tahun ajaran: YYYY/YYYY+1
    // Jika bulan Januari-Juni, tahun ajaran: YYYY-1/YYYY
    if ($bulan >= 7) {
        return $tahun . '/' . ($tahun + 1);
    } else {
        return ($tahun - 1) . '/' . $tahun;
    }
}

// Method untuk validasi SPP tersedia
protected function validateSPPTersedia($tingkat, $tahun_ajaran = null)
{
    if (!$tahun_ajaran) {
        $tahun_ajaran = $this->getTahunAjaranAktif();
    }
    
    $sppModel = new \App\Models\SPPModel();
    $spp = $sppModel->where('tingkat', $tingkat)
                    ->where('tahun_ajaran', $tahun_ajaran)
                    ->first();
    
    return $spp ? $spp : false;
}
}