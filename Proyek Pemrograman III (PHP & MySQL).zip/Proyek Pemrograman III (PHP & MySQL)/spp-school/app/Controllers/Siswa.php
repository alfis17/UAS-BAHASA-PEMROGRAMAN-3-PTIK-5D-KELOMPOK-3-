<?php

namespace App\Controllers;

use App\Models\SiswaModel;
use App\Models\KelasModel;
use App\Models\SPPModel;
use App\Models\PembayaranModel;
use CodeIgniter\Controller;

class Siswa extends BaseController
{
    protected $siswaModel;
    protected $kelasModel;
    protected $sppModel;
    protected $pembayaranModel;
    protected $session;
    
    public function __construct()
    {
        $this->siswaModel = new SiswaModel();
        $this->kelasModel = new KelasModel();
        $this->sppModel = new SPPModel();
        $this->pembayaranModel = new PembayaranModel();
        $this->session = session();
        
        // Cek apakah user login sebagai siswa
        if (!$this->session->get('logged_in')) {
            return redirect()->to('/login')->with('error', 'Silakan login sebagai siswa terlebih dahulu');
        }
    }


        public function profile_siswa()
{
    // Redirect ke method profile yang sudah ada
    return $this->profile();
}
    // dashboard
        
public function dashboard()
{
    // Tambahkan pengecekan ulang untuk memastikan hanya siswa yang bisa akses
    if (session()->get('role') !== 'siswa') {
        return redirect()->to('/dashboard')->with('error', 'Akses ditolak');
    }
    
    $siswa_id = $this->session->get('user_id');
    $siswa_nisn = $this->session->get('nisn');
    
    // Ambil data siswa lengkap
    $siswa = $this->siswaModel->find($siswa_id);
    if (!$siswa) {
        return redirect()->to('/login')->with('error', 'Data siswa tidak ditemukan');
    }

    // Pastikan $siswa dalam format array untuk konsistensi
    if (is_object($siswa)) {
        $siswa = (array) $siswa;
    }
    
    // Inisialisasi variabel data
    $data = [];
    
    // Ambil data kelas
    $kelas = $this->kelasModel->find($siswa['id_kelas']);
    
    // Konversi $kelas ke array jika perlu
    if (is_object($kelas)) {
        $kelas = (array) $kelas;
    }
    
    // Ambil data SPP berdasarkan tingkat dan tahun ajaran aktif
    $tahun_ajaran_aktif = $this->getTahunAjaranAktif();
    
    // Gunakan metode yang aman untuk mengakses tingkat
    $tingkat = isset($kelas['tingkat']) ? $kelas['tingkat'] : 
              (isset($kelas->tingkat) ? $kelas->tingkat : 'X');
    
    $spp = $this->sppModel->where('tingkat', $tingkat)
                          ->where('tahun_ajaran', $tahun_ajaran_aktif)
                          ->first();
    
    if (!$spp) {
        // Tambahkan warning jika SPP tidak ditemukan
        $data['spp_warning'] = 'Tarif SPP belum ditetapkan untuk tahun ajaran ini';
        $spp = ['nominal' => 0]; // Default nilai
    }
    
    // Konversi $spp ke array jika perlu
    if (is_object($spp)) {
        $spp = (array) $spp;
    }
    
    // INISIALISASI $pembayaran di sini
    $pembayaran = [];
    
    // Ambil riwayat pembayaran
    $pembayaran = $this->pembayaranModel
        ->where('id_siswa', $siswa_id)
        ->orderBy('tahun DESC, FIELD(bulan, "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember") DESC')
        ->findAll();
    
    // Hitung statistik
    $total_bulan = 12; // Jan-Des
    $bulan_bayar = count($pembayaran);
    $bulan_belum_bayar = $total_bulan - $bulan_bayar;
    
    // Data untuk chart pembayaran per bulan
    $bulan_labels = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    $pembayaran_per_bulan = array_fill(0, 12, 0);
    
    foreach ($pembayaran as $bayar) {
        // Pastikan $bayar dalam format array
        $bayarArray = is_object($bayar) ? (array) $bayar : $bayar;
        
        $bulan_index = array_search($bayarArray['bulan'], ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']);
        if ($bulan_index !== false) {
            $pembayaran_per_bulan[$bulan_index] = (float) $bayarArray['jumlah_bayar'];
        }
    }
    
    $data = [
        'title' => 'Dashboard Siswa - SPP System',
        'siswa' => $siswa,
        'kelas' => $kelas,
        'spp' => $spp,
        'pembayaran' => $pembayaran,
        'stats' => [
            'total_bulan' => $total_bulan,
            'bulan_bayar' => $bulan_bayar,
            'bulan_belum_bayar' => $bulan_belum_bayar,
            'persentase_bayar' => $total_bulan > 0 ? round(($bulan_bayar / $total_bulan) * 100) : 0,
        ],
        'chart_data' => [
            'labels' => $bulan_labels,
            'data' => $pembayaran_per_bulan
        ],
        'tahun_sekarang' => date('Y'),
        'bulan_sekarang' => date('F'),
        'user' => session()->get() // Tambahkan user data ke view
    ];
    
    return view('siswa/dashboard_siswa', $data);
}
    public function profile()
    {
        $siswa_id = $this->session->get('user_id');
        $siswa = $this->siswaModel->find($siswa_id);
        
        if (!$siswa) {
            return redirect()->to('siswa/dashboard_siswa')->with('error', 'Data siswa tidak ditemukan');
        }
        
        $kelas = $this->kelasModel->find($siswa['id_kelas']);
        
        $data = [
            'title' => 'Profile Siswa - SPP System',
            'siswa' => $siswa,
            'kelas' => $kelas
        ];
        
        return view('siswa/profile_siswa', $data);
    }

    public function pembayaran()
{
    $siswa_id = $this->session->get('user_id');
    $siswa = $this->siswaModel->find($siswa_id);

    if (!$siswa) {
        return redirect()->to('/siswa/dashboard')->with('error', 'Data siswa tidak ditemukan');
    }

    // Konversi ke array jika objek
    if (is_object($siswa)) {
        $siswa = (array) $siswa;
    }

    // Ambil data kelas
    $kelas = $this->kelasModel->find($siswa['id_kelas']);
    if (is_object($kelas)) {
        $kelas = (array) $kelas;
    }

    // Ambil tahun ajaran aktif
    $tahun_ajaran_aktif = $this->getTahunAjaranAktif();

    // Ambil data SPP
    $tingkat = $kelas['tingkat'] ?? 'X';
    $spp = $this->sppModel->where('tingkat', $tingkat)
                          ->where('tahun_ajaran', $tahun_ajaran_aktif)
                          ->first();

    if (is_object($spp)) {
        $spp = (array) $spp;
    }

    if (!$spp) {
        return redirect()->to('/siswa/dashboard')->with('error', 'Tarif SPP belum ditetapkan untuk tahun ajaran ini');
    }

    // Ambil bulan yang sudah dibayar tahun ini (TANPA STATUS)
    $pembayaran_tahun_ini = $this->pembayaranModel
        ->where('id_siswa', $siswa_id)
        ->where('tahun', date('Y'))
        ->findAll(); // Hapus where('status', 'lunas')

    $bulan_sudah_bayar = [];
    foreach ($pembayaran_tahun_ini as $bayar) {
        if (is_object($bayar)) {
            $bayar = (array) $bayar;
        }
        $bulan_sudah_bayar[] = $bayar['bulan'];
    }

    // List bulan
    $bulan_list = [
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];

    $data = [
        'title' => 'Pembayaran SPP - SPP System',
        'siswa' => $siswa,
        'kelas' => $kelas,
        'spp' => $spp,
        'bulan_list' => $bulan_list,
        'bulan_sudah_bayar' => $bulan_sudah_bayar,
        'tahun_sekarang' => date('Y'),
        'tahun_ajaran_aktif' => $tahun_ajaran_aktif,
        'bulan_bayar' => count($pembayaran_tahun_ini)
    ];

    return view('siswa/pembayaran_siswa', $data);
}

    public function storePembayaran()
    {
        $siswa_id = $this->session->get('user_id');

        // Validasi input
        $validation = \Config\Services::validation();
        $rules = [
            'bulan' => 'required',
            'tahun' => 'required|numeric',
            'jumlah_bayar' => 'required|numeric',
            'metode_pembayaran' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $bulan = $this->request->getPost('bulan');
        $tahun = $this->request->getPost('tahun');
        $jumlah_bayar = str_replace(['Rp', '.', ','], '', $this->request->getPost('jumlah_bayar'));
        $metode_pembayaran = $this->request->getPost('metode_pembayaran');
        $keterangan = $this->request->getPost('keterangan');

        // Cek apakah bulan ini sudah dibayar
        $existing_payment = $this->pembayaranModel
            ->where('id_siswa', $siswa_id)
            ->where('bulan', $bulan)
            ->where('tahun', $tahun)
            ->first();

        if ($existing_payment) {
            return redirect()->back()->with('error', 'Pembayaran untuk bulan ' . $bulan . ' ' . $tahun . ' sudah ada');
        }

        // Ambil data SPP
        $siswa = $this->siswaModel->find($siswa_id);
        if (is_object($siswa)) {
            $siswa = (array) $siswa;
        }
        $kelas = $this->kelasModel->find($siswa['id_kelas']);
        if (is_object($kelas)) {
            $kelas = (array) $kelas;
        }
        $tahun_ajaran_aktif = $this->getTahunAjaranAktif();
        $spp = $this->sppModel->where('tingkat', $kelas['tingkat'])
                              ->where('tahun_ajaran', $tahun_ajaran_aktif)
                              ->first();

        if (is_object($spp)) {
            $spp = (array) $spp;
        }

        if (!$spp) {
            return redirect()->back()->with('error', 'Tarif SPP tidak ditemukan');
        }

        // Simpan pembayaran
        $data = [
            'id_siswa' => $siswa_id,
            'id_spp' => is_array($spp) ? $spp['id'] : $spp->id,
            'bulan' => $bulan,
            'tahun' => $tahun,
            'jumlah_bayar' => $jumlah_bayar,
            'metode_pembayaran' => $metode_pembayaran,
            'keterangan' => $keterangan,
            'tanggal_bayar' => date('Y-m-d'),
            'status_pembayaran' => 'Lunas', // Status lunas karena pembayaran sesuai nominal SPP
            'id_user' => 1 // Use admin ID temporarily, will be updated when verified by petugas
        ];

        // Skip validation untuk submission siswa karena status pending dan id_user null
        $this->pembayaranModel->skipValidation(true);

        if ($this->pembayaranModel->save($data)) {
            $this->pembayaranModel->skipValidation(false); // Re-enable validation
            return redirect()->back()->with('success', 'Pembayaran berhasil disimpan');
        } else {
            $this->pembayaranModel->skipValidation(false); // Re-enable validation
            return redirect()->back()->with('error', 'Gagal menyimpan pembayaran');
        }
    }
    public function updateProfile()
    {
        $siswa_id = $this->session->get('user_id');
        $siswa = $this->siswaModel->find($siswa_id);
        
        if (!$siswa) {
            return redirect()->to('siswa/dashboard_siswa')->with('error', 'Data siswa tidak ditemukan');
        }
     
        $validation = \Config\Services::validation();
        
        $rules = [
            'nama_siswa' => 'required|max_length[150]',
            'no_hp' => 'required|max_length[20]',
            'alamat' => 'required'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->to('/siswa/profile')->withInput()->with('errors', $validation->getErrors());
        }
        
        $updateData = [
            'nama_siswa' => $this->request->getPost('nama_siswa'),
            'no_hp' => $this->request->getPost('no_hp'),
            'alamat' => $this->request->getPost('alamat')
        ];
        
        if ($this->siswaModel->update($siswa_id, $updateData)) {
            // Update session nama
            $this->session->set('nama_lengkap', $updateData['nama_siswa']);
            
            return redirect()->to('/siswa/profile')->with('success', 'Profile berhasil diperbarui');
        } else {
            return redirect()->to('/siswa/profile')->with('error', 'Gagal memperbarui profile');
        }
    }

     public function changePassword()
    {
        $siswa_id = $this->session->get('user_id');
        
        $data = [
            'title' => 'Ganti Password - SPP System'
        ];
        
        return view('siswa/change_password', $data);
    }
    public function updatePassword()
    {
        $siswa_id = $this->session->get('user_id');
        
        $validation = \Config\Services::validation();
        
        $rules = [
            'current_password' => 'required',
            'new_password' => 'required|min_length[6]',
            'confirm_password' => 'required|matches[new_password]'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->to('/siswa/change-password')->withInput()->with('errors', $validation->getErrors());
        }
        
        $current_password = $this->request->getPost('current_password');
        $new_password = $this->request->getPost('new_password');
        
        // Ambil data siswa
        $siswa = $this->siswaModel->find($siswa_id);
        
        // Verifikasi password lama
        if (!password_verify($current_password, $siswa['password'])) {
            return redirect()->to('/siswa/change-password')->with('error', 'Password saat ini salah');
        }
        
        // Update password baru
        $updateData = [
            'password' => $new_password
        ];
        
        if ($this->siswaModel->update($siswa_id, $updateData)) {
            return redirect()->to('/siswa/change-password')->with('success', 'Password berhasil diubah');
        } else {
            return redirect()->to('/siswa/change-password')->with('error', 'Gagal mengubah password');
        }
    }

    public function history()
    {
        $siswa_id = $this->session->get('user_id');

        // Ambil parameter filter dari GET
        $tahun_filter = $this->request->getGet('tahun');
        $bulan_filter = $this->request->getGet('bulan');
        $status_filter = $this->request->getGet('status');

        // Query pembayaran dengan filter
        $builder = $this->pembayaranModel
            ->select('pembayaran.*, users.nama_lengkap as petugas')
            ->join('users', 'users.id = pembayaran.id_user', 'left')
            ->where('pembayaran.id_siswa', $siswa_id);

        // Terapkan filter
        if ($tahun_filter && $tahun_filter != '') {
            $builder->where('pembayaran.tahun', $tahun_filter);
        }

        if ($bulan_filter && $bulan_filter != '') {
            $builder->where('pembayaran.bulan', $bulan_filter);
        }

        if ($status_filter && $status_filter != '') {
            $builder->where('pembayaran.status_pembayaran', $status_filter);
        }

        $pembayaran = $builder
            ->orderBy('pembayaran.tahun DESC, pembayaran.tanggal_bayar DESC')
            ->findAll();

        $data = [
            'title' => 'Riwayat Pembayaran - SPP System',
            'pembayaran' => $pembayaran,
            'tahun_filter' => $tahun_filter,
            'bulan_filter' => $bulan_filter,
            'status_filter' => $status_filter
        ];

        return view('siswa/history_siswa', $data);
    }

   public function printHistory()
{
    // Tambahkan pengecekan role untuk memastikan hanya siswa yang bisa akses
    if (session()->get('role') !== 'siswa') {
        return redirect()->to('/dashboard')->with('error', 'Akses ditolak');
    }

    $siswa_id = $this->session->get('user_id');
    $siswa = $this->siswaModel->find($siswa_id);
    
    if (!$siswa) {
        return redirect()->to('/siswa/history_siswa')->with('error', 'Data siswa tidak ditemukan');
    }
    
    // Konversi ke objek jika array
    if (is_array($siswa)) {
        $siswa = (object) $siswa;
    }
    
    $kelas = $this->kelasModel->find($siswa->id_kelas);
    if (is_array($kelas)) {
        $kelas = (object) $kelas;
    }
    
    $tahun_ajaran_aktif = $this->getTahunAjaranAktif();
    $spp = $this->sppModel->where('tingkat', $kelas->tingkat ?? 'X')
                          ->where('tahun_ajaran', $tahun_ajaran_aktif)
                          ->first();
    
    if (is_array($spp)) {
        $spp = (object) $spp;
    }
    
    $pembayaran = $this->pembayaranModel
        ->select('pembayaran.*, users.nama_lengkap as petugas')
        ->join('users', 'users.id = pembayaran.id_user', 'left')
        ->where('pembayaran.id_siswa', $siswa_id)
        ->orderBy('pembayaran.tahun DESC, pembayaran.tanggal_bayar DESC')
        ->findAll();

    // Convert arrays to objects for view compatibility
    $pembayaran = array_map(function($item) {
        return (object) $item;
    }, $pembayaran);

    $data = [
        'title' => 'Cetak Riwayat Pembayaran - SPP System',
        'siswa' => $siswa,
        'kelas' => $kelas,
        'spp' => $spp,
        'pembayaran' => $pembayaran,
        'tahun_sekarang' => date('Y'),
        'tanggal_cetak' => date('d/m/Y H:i:s')
    ];
    
    return view('siswa/print_history', $data);
}

    public function index()
    {
        // Untuk method index (admin view), cek apakah admin/petugas
        if (!in_array(session()->get('role'), ['admin', 'petugas'])) {
            return redirect()->to('admin/dashboard_admin')->with('error', 'Akses ditolak');
        }
        
        $data = [
            'title' => 'Data Siswa - Sistem SPP',
            'siswa' => $this->siswaModel->getSiswaWithKelas(),
            'kelas' => $this->kelasModel->findAll(),
            'user' => session()->get()
        ];
        
        return view('admin/index_siswa', $data);
    }

    public function create()
    {
        // Handle AJAX form submission
        $validation = \Config\Services::validation();
        
        $rules = [
            'nisn' => [
                'rules' => 'required|is_unique[siswa.nisn]',
                'errors' => [
                    'required' => 'NISN wajib diisi',
                    'is_unique' => 'NISN sudah digunakan'
                ]
            ],
            'nama_siswa' => [
                'rules' => 'required',
                'errors' => ['required' => 'Nama siswa wajib diisi']
            ],
            'jenis_kelamin' => [
                'rules' => 'required|in_list[L,P]',
                'errors' => ['required' => 'Jenis kelamin wajib dipilih']
            ],
            'tempat_lahir' => [
                'rules' => 'required',
                'errors' => ['required' => 'Tempat lahir wajib diisi']
            ],
            'tanggal_lahir' => [
                'rules' => 'required|valid_date',
                'errors' => [
                    'required' => 'Tanggal lahir wajib diisi',
                    'valid_date' => 'Format tanggal tidak valid'
                ]
            ],
            'alamat' => [
                'rules' => 'required',
                'errors' => ['required' => 'Alamat wajib diisi']
            ],
            'no_hp' => [
                'rules' => 'required',
                'errors' => ['required' => 'No. HP wajib diisi']
            ],
            'id_kelas' => [
                'rules' => 'required|numeric',
                'errors' => [
                    'required' => 'Kelas wajib dipilih',
                    'numeric' => 'Kelas tidak valid'
                ]
            ],
            'tahun_masuk' => [
                'rules' => 'required|numeric|greater_than[1999]|less_than_equal_to[' . (date('Y') + 1) . ']',
                'errors' => [
                    'required' => 'Tahun masuk wajib diisi',
                    'numeric' => 'Tahun harus angka',
                    'greater_than' => 'Tahun masuk minimal 2000',
                    'less_than_equal_to' => 'Tahun masuk tidak boleh melebihi tahun depan'
                ]
            ]
        ];
        
        $validation->setRules($rules);
        
        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Validasi gagal',
                'errors' => $validation->getErrors()
            ]);
        }
        
        $data = [
            'nisn' => $this->request->getPost('nisn'),
            'nama_siswa' => $this->request->getPost('nama_siswa'),
            'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
            'tempat_lahir' => $this->request->getPost('tempat_lahir'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'alamat' => $this->request->getPost('alamat'),
            'no_hp' => $this->request->getPost('no_hp'),
            'id_kelas' => $this->request->getPost('id_kelas'),
            'tahun_masuk' => $this->request->getPost('tahun_masuk'),
        ];
        
        try {
            // Nonaktifkan validation model
            $this->siswaModel->skipValidation(true);
            
            if ($this->siswaModel->save($data)) {
                $response = [
                    'success' => true,
                    'message' => 'Data siswa berhasil ditambahkan'
                ];
            } else {
                $response = [
                    'success' => false,
                    'message' => 'Gagal menambahkan data siswa'
                ];
            }
            
            $this->siswaModel->skipValidation(false);
            
            return $this->response->setJSON($response);
        } catch (\Exception $e) {
            $this->siswaModel->skipValidation(false);
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ]);
        }
    }

    public function update($id)
    {
        return $this->handleAjaxUpdate($id);
    }
    
    /**
     * Handle AJAX update request
     */
    protected function handleAjaxUpdate($id)
    {
        $validation = \Config\Services::validation();
        
        $rules = [
            'nisn' => [
                'rules' => "required|is_unique[siswa.nisn,id,{$id}]",
                'errors' => [
                    'required' => 'NISN wajib diisi',
                    'is_unique' => 'NISN sudah digunakan'
                ]
            ],
            'nama_siswa' => [
                'rules' => 'required',
                'errors' => ['required' => 'Nama siswa wajib diisi']
            ],
            'jenis_kelamin' => [
                'rules' => 'required|in_list[L,P]',
                'errors' => ['required' => 'Jenis kelamin wajib dipilih']
            ],
            'tempat_lahir' => [
                'rules' => 'required',
                'errors' => ['required' => 'Tempat lahir wajib diisi']
            ],
            'tanggal_lahir' => [
                'rules' => 'required|valid_date',
                'errors' => [
                    'required' => 'Tanggal lahir wajib diisi',
                    'valid_date' => 'Format tanggal tidak valid'
                ]
            ],
            'alamat' => [
                'rules' => 'required',
                'errors' => ['required' => 'Alamat wajib diisi']
            ],
            'no_hp' => [
                'rules' => 'required',
                'errors' => ['required' => 'No. HP wajib diisi']
            ],
            'id_kelas' => [
                'rules' => 'required|numeric',
                'errors' => [
                    'required' => 'Kelas wajib dipilih',
                    'numeric' => 'Kelas tidak valid'
                ]
            ],
            'tahun_masuk' => [
                'rules' => 'required|numeric|greater_than[1999]|less_than_equal_to[' . (date('Y') + 1) . ']',
                'errors' => [
                    'required' => 'Tahun masuk wajib diisi',
                    'numeric' => 'Tahun harus angka',
                    'greater_than' => 'Tahun masuk minimal 2000',
                    'less_than_equal_to' => 'Tahun masuk tidak boleh melebihi tahun depan'
                ]
            ]
        ];
        
        $validation->setRules($rules);
        
        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Validasi gagal',
                'errors' => $validation->getErrors()
            ]);
        }
        
        $data = [
            'nisn' => $this->request->getPost('nisn'),
            'nama_siswa' => $this->request->getPost('nama_siswa'),
            'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
            'tempat_lahir' => $this->request->getPost('tempat_lahir'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'alamat' => $this->request->getPost('alamat'),
            'no_hp' => $this->request->getPost('no_hp'),
            'id_kelas' => $this->request->getPost('id_kelas'),
            'tahun_masuk' => $this->request->getPost('tahun_masuk'),
        ];
        
        try {
            // Nonaktifkan validation model
            $this->siswaModel->skipValidation(true);
            
            $result = $this->siswaModel->update($id, $data);
            
            $this->siswaModel->skipValidation(false);
            
            if ($result) {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'Data siswa berhasil diperbarui'
                ]);
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Gagal memperbarui data siswa'
                ]);
            }
        } catch (\Exception $e) {
            $this->siswaModel->skipValidation(false);
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Terjadi kesalahan: ' . $e->getMessage()
            ]);
        }
    }

    public function delete($id)
    {
        $db = \Config\Database::connect();
        $pembayaranCount = $db->table('pembayaran')->where('id_siswa', $id)->countAllResults();
        
        if ($pembayaranCount > 0) {
            session()->setFlashdata('error', 'Siswa tidak dapat dihapus karena masih memiliki riwayat pembayaran');
            return redirect()->to('/siswa');
        }
        
        if ($this->siswaModel->delete($id)) {
            // Set flashdata khusus untuk popup delete
            session()->setFlashdata('show_popup_success', true);
            session()->setFlashdata('popup_message', 'Data siswa berhasil dihapus');
            session()->setFlashdata('popup_title', 'Berhasil!');
        } else {
            session()->setFlashdata('error', 'Gagal menghapus data siswa');
        }
        
        return redirect()->to('/siswa');
    }

    // AJAX Methods
    public function get($id)
    {
        $siswa = $this->siswaModel->getSiswaWithKelas($id);
        
        if ($siswa) {
            return $this->response->setJSON([
                'success' => true,
                'data' => $siswa
            ]);
        }
        
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Data siswa tidak ditemukan'
        ]);
    }

    public function search()
    {
        $keyword = $this->request->getGet('keyword');
        
        $builder = $this->siswaModel->db->table('siswa s');
        $builder->select('s.*, k.nama_kelas');
        $builder->join('kelas k', 'k.id = s.id_kelas', 'left');
        $builder->groupStart()
                ->like('s.nama_siswa', $keyword)
                ->orLike('s.nisn', $keyword)
                ->orLike('s.tempat_lahir', $keyword)
                ->orLike('s.no_hp', $keyword)
                ->groupEnd();
        $result = $builder->get()->getResult();
        
        return $this->response->setJSON([
            'success' => true,
            'data' => $result
        ]);
    }
    
    public function checkNisn()
    {
        $nisn = $this->request->getPost('nisn');
        $id = $this->request->getPost('id'); // Untuk edit

        $is_unique = true;

        if ($id) {
            // Untuk edit: cek apakah NISN sudah ada selain id ini
            $existing = $this->siswaModel
                ->where('nisn', $nisn)
                ->where('id !=', $id)
                ->first();
        } else {
            // Untuk tambah: cek apakah NISN sudah ada
            $existing = $this->siswaModel
                ->where('nisn', $nisn)
                ->first();
        }

        if ($existing) {
            $is_unique = false;
        }

        return $this->response->setJSON([
            'is_unique' => $is_unique,
            'message' => $is_unique ? 'NISN tersedia' : 'NISN sudah digunakan'
        ]);
    }



    public function receipt($id)
    {
        $siswa_id = $this->session->get('user_id');

        // Ambil data pembayaran dengan join
        $pembayaran = $this->pembayaranModel
            ->select('pembayaran.*, siswa.nisn, siswa.nama_siswa, siswa.alamat, kelas.nama_kelas, spp.tahun_ajaran, spp.nominal, users.nama_lengkap as petugas')
            ->join('siswa', 'siswa.id = pembayaran.id_siswa')
            ->join('kelas', 'kelas.id = siswa.id_kelas', 'left')
            ->join('spp', 'spp.id = pembayaran.id_spp', 'left')
            ->join('users', 'users.id = pembayaran.id_user', 'left')
            ->where('pembayaran.id', $id)
            ->where('pembayaran.id_siswa', $siswa_id) // Pastikan hanya data siswa sendiri
            ->first();

        if (!$pembayaran) {
            return $this->response->setStatusCode(404)->setBody('Kwitansi tidak ditemukan');
        }

        $data = [
            'pembayaran' => $pembayaran,
            'tanggal_cetak' => date('d/m/Y H:i:s')
        ];

        return view('siswa/receipt', $data);
    }
}