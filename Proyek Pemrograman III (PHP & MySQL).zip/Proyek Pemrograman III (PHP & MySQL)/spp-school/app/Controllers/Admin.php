<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\SiswaModel;
use App\Models\KelasModel;
use App\Models\PembayaranModel;
use App\Models\SPPModel;
use App\Models\LogModel;
use App\Models\BackupModel;
use App\Models\SettingModel;

class Admin extends BaseController
{
    protected $userModel;
    protected $siswaModel;
    protected $kelasModel;
    protected $pembayaranModel;
    protected $sppModel;
    protected $logModel;
    protected $backupModel;
    protected $settingModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->siswaModel = new SiswaModel();
        $this->kelasModel = new KelasModel();
        $this->pembayaranModel = new PembayaranModel();
        $this->sppModel = new SPPModel();
        $this->logModel = new LogModel();
        $this->backupModel = new BackupModel();
        $this->settingModel = new SettingModel();
        
        // Check if user is admin
        if (session()->get('role') != 'admin') {
            return redirect()->to('/dashboard');
        }
    }
public function index_laporan()
{
    // Redirect ke index_laporan biasa atau copy isi dari Laporan::index_laporan
    return redirect()->to('index_laporan');
}
    // ========================= BACKUP DATABASE =========================
    public function backup_database()
    {
        $data = [
            'title' => 'Backup Database',
            'db_info' => $this->backupModel->getDatabaseInfo(),
            'tables' => $this->backupModel->getTables(),
            'table_sizes' => $this->backupModel->getTableSizes(),
            'backup_files' => $this->backupModel->getBackupFiles(),
            'chart_data' => $this->backupModel->getChartData(),
            'last_backup_days' => $this->backupModel->getLastBackupDays()
        ];
        
        return view('admin/backup_database', $data);
    }

    public function create_backup()
    {
        $post = $this->request->getPost();
        
        try {
            $result = $this->backupModel->createBackup($post);
            
            if ($result) {
                $this->logModel->createLog(session()->get('id'), 'backup', 'Membuat backup database: ' . $result['filename']);
                return $this->response->setJSON(['success' => true, 'message' => 'Backup berhasil dibuat', 'data' => $result]);
            } else {
                return $this->response->setJSON(['success' => false, 'message' => 'Gagal membuat backup']);
            }
        } catch (\Exception $e) {
            return $this->response->setJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    public function schedule_backup()
    {
        $post = $this->request->getPost();
        
        try {
            $result = $this->backupModel->saveSchedule($post);
            
            if ($result) {
                $this->logModel->createLog(session()->get('id'), 'settings', 'Mengatur jadwal backup otomatis');
                session()->setFlashdata('success', 'Jadwal backup berhasil disimpan');
            } else {
                session()->setFlashdata('error', 'Gagal menyimpan jadwal backup');
            }
        } catch (\Exception $e) {
            session()->setFlashdata('error', 'Error: ' . $e->getMessage());
        }
        
        return redirect()->to('/admin/backup_database');
    }

    public function restore_backup()
    {
        $post = $this->request->getPost();
        $password = $this->request->getHeaderLine('X-Password-Confirm');
        
        // Verify admin password
        $user = $this->userModel->find(session()->get('id'));
        if (!password_verify($password, $user->password)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Password salah']);
        }
        
        try {
            $result = $this->backupModel->restoreBackup($post);
            
            if ($result) {
                $this->logModel->createLog(session()->get('id'), 'restore', 'Melakukan restore database dari backup');
                return $this->response->setJSON(['success' => true, 'message' => 'Restore berhasil']);
            } else {
                return $this->response->setJSON(['success' => false, 'message' => 'Gagal melakukan restore']);
            }
        } catch (\Exception $e) {
            return $this->response->setJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    public function download_backup($filename)
    {
        return $this->backupModel->downloadBackup($filename);
    }

    public function preview_backup()
    {
        $filename = $this->request->getGet('filename');
        $content = $this->backupModel->previewBackup($filename);
        
        return $content;
    }

    public function delete_backup()
    {
        $filename = $this->request->getPost('filename');
        
        try {
            $result = $this->backupModel->deleteBackup($filename);
            
            if ($result) {
                $this->logModel->createLog(session()->get('id'), 'backup', 'Menghapus backup: ' . $filename);
                return $this->response->setJSON(['success' => true, 'message' => 'Backup berhasil dihapus']);
            } else {
                return $this->response->setJSON(['success' => false, 'message' => 'Gagal menghapus backup']);
            }
        } catch (\Exception $e) {
            return $this->response->setJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    // ========================= PENGATURAN SISTEM =========================
    public function pengaturan_sistem()
    {
        $data = [
            'title' => 'Pengaturan Sistem',
            'settings' => $this->settingModel->getAllSettings(),
            'security_checks' => $this->settingModel->getSecurityChecks(),
            'backup_schedule' => $this->backupModel->getSchedule()
        ];
        
        return view('admin/pengaturan_sistem', $data);
    }

    public function save_settings()
    {
        $post = $this->request->getPost();
        
        try {
            $result = $this->settingModel->saveSettings($post);
            
            if ($result) {
                $this->logModel->createLog(session()->get('id'), 'settings', 'Menyimpan pengaturan sistem');
                return $this->response->setJSON(['success' => true, 'message' => 'Pengaturan berhasil disimpan']);
            } else {
                return $this->response->setJSON(['success' => false, 'message' => 'Gagal menyimpan pengaturan']);
            }
        } catch (\Exception $e) {
            return $this->response->setJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    public function test_email()
    {
        $email = $this->request->getPost('email');
        
        try {
            $result = $this->settingModel->testEmail($email);
            
            if ($result) {
                return $this->response->setJSON(['success' => true, 'message' => 'Test email berhasil dikirim']);
            } else {
                return $this->response->setJSON(['success' => false, 'message' => 'Gagal mengirim test email']);
            }
        } catch (\Exception $e) {
            return $this->response->setJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    public function test_cloud()
    {
        $post = $this->request->getPost();
        
        try {
            $result = $this->settingModel->testCloudConnection($post);
            
            if ($result) {
                return $this->response->setJSON(['success' => true, 'message' => 'Koneksi cloud berhasil']);
            } else {
                return $this->response->setJSON(['success' => false, 'message' => 'Gagal terhubung ke cloud']);
            }
        } catch (\Exception $e) {
            return $this->response->setJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    public function security_check()
    {
        try {
            $checks = $this->settingModel->runSecurityChecks();
            $passed = true;
            
            foreach ($checks as $check) {
                if (!$check['passed']) {
                    $passed = false;
                    break;
                }
            }
            
            return $this->response->setJSON([
                'success' => true,
                'passed' => $passed,
                'checks' => $checks
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    // ========================= PROFILE =========================
    public function profile()
    {
        $user_id = session()->get('id');
        
        $data = [
            'title' => 'Profile Admin',
            'user' => $this->userModel->find($user_id),
            'last_login' => $this->logModel->getLastLogin($user_id),
            'activities' => $this->logModel->getUserActivities($user_id, 10),
            'stats' => $this->userModel->getUserStats($user_id)
        ];
        
        return view('admin/profile', $data);
    }

    public function update_profile()
    {
        $id = session()->get('id');
        
        $rules = [
            'nama_lengkap' => 'required',
            'email' => "required|valid_email|is_unique[users.email,id,$id]"
        ];
        
        if ($this->validate($rules)) {
            $data = [
                'nama_lengkap' => $this->request->getPost('nama_lengkap'),
                'email' => $this->request->getPost('email'),
                'no_hp' => $this->request->getPost('no_hp'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'alamat' => $this->request->getPost('alamat')
            ];
            
   
        } else {
            session()->setFlashdata('error', 'Validasi gagal');
        }
        
        return redirect()->to('/admin/profile');
    }

    public function change_password()
    {
        $id = session()->get('id');
        $post = $this->request->getPost();
        
        // Verify current password
        $user = $this->userModel->find($id);
        if (!password_verify($post['current_password'], $user->password)) {
            session()->setFlashdata('error', 'Password saat ini salah');
            return redirect()->to('/admin/profile');
        }
        
        // Validate new password
        if (strlen($post['new_password']) < 8) {
            session()->setFlashdata('error', 'Password baru minimal 8 karakter');
            return redirect()->to('/admin/profile');
        }
        
        if ($post['new_password'] !== $post['confirm_password']) {
            session()->setFlashdata('error', 'Konfirmasi password tidak cocok');
            return redirect()->to('/admin/profile');
        }
        
        // Update password
        $hashedPassword = password_hash($post['new_password'], PASSWORD_DEFAULT);
        $this->userModel->update($id, ['password' => $hashedPassword]);
        
        $this->logModel->createLog($id, 'password', 'Mengubah password');
        session()->setFlashdata('success', 'Password berhasil diubah');
        
        return redirect()->to('/admin/profile');
    }

    public function update_photo()
    {
        $id = session()->get('id');
        $file = $this->request->getFile('photo');
        
        if ($file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads/profile', $newName);
            
            $this->userModel->update($id, ['photo' => 'uploads/profile/' . $newName]);
            session()->setFlashdata('success', 'Foto profil berhasil diupload');
        } else {
            session()->setFlashdata('error', 'Gagal upload foto');
        }
        
        return redirect()->to('/admin/profile');
    }

    public function delete_account()
    {
        $id = session()->get('id');
        $password = $this->request->getPost('password');
        
        // Verify password
        $user = $this->userModel->find($id);
        if (!password_verify($password, $user->password)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Password salah']);
        }
        
        // Cannot delete last admin
        $adminCount = $this->userModel->where('role', 'admin')->countAllResults();
        if ($adminCount <= 1) {
            return $this->response->setJSON(['success' => false, 'message' => 'Tidak dapat menghapus satu-satunya admin']);
        }
        
        // Delete account
        $this->userModel->delete($id);
        
        return $this->response->setJSON(['success' => true, 'message' => 'Akun berhasil dihapus']);
    }

    public function extend_session()
    {
        // Refresh session
        session()->set('last_activity', time());
        return $this->response->setJSON(['success' => true]);
    }

    // ========================= REKAP BULANAN =========================
    public function rekap_bulanan()
    {
        $bulan = $this->request->getGet('bulan') ?? date('n');
        $tahun = $this->request->getGet('tahun') ?? date('Y');
        $kelas = $this->request->getGet('kelas');
        
        $data = [
            'title' => 'Rekap Bulanan',
            'selectedMonth' => $bulan,
            'selectedYear' => $tahun,
            'selectedMonthName' => $this->getMonthName($bulan),
            'kelas' => $this->kelasModel->findAll(),
            'rekap' => $this->pembayaranModel->getRekapBulanan($bulan, $tahun, $kelas),
            'chart_comparison' => $this->pembayaranModel->getComparisonChart($tahun),
            'chart_methods' => $this->pembayaranModel->getPaymentMethodChart($bulan, $tahun)
        ];
        
        return view('admin/rekap_bulanan', $data);
    }

    public function export_rekap($format)
    {
        $bulan = $this->request->getGet('bulan') ?? date('n');
        $tahun = $this->request->getGet('tahun') ?? date('Y');
        $kelas = $this->request->getGet('kelas');
        
        $rekap = $this->pembayaranModel->getRekapBulanan($bulan, $tahun, $kelas);
        
        switch ($format) {
            case 'excel':
                return $this->exportToExcel($rekap, "Rekap_Bulanan_{$bulan}_{$tahun}");
            case 'pdf':
                return $this->exportToPDF($rekap, "Rekap_Bulanan_{$bulan}_{$tahun}");
            case 'print':
                return $this->exportToPrint($rekap);
            default:
                return redirect()->to('/admin/rekap_bulanan');
        }
    }

    // ========================= LAPORAN TUNGGKAN =========================
    public function laporan_tunggakan()
    {
        $filter = [
            'kelas' => $this->request->getGet('kelas'),
            'bulan' => $this->request->getGet('bulan'),
            'tahun' => $this->request->getGet('tahun'),
            'status' => $this->request->getGet('status')
        ];
        
        $data = [
            'title' => 'Laporan Tunggakan',
            'kelas' => $this->kelasModel->findAll(),
            'tunggakan' => $this->pembayaranModel->getTunggakan($filter),
            'summary' => $this->pembayaranModel->getTunggakanSummary($filter),
            'chart_kelas' => $this->pembayaranModel->getTunggakanPerKelas($filter),
            'chart_status' => $this->pembayaranModel->getTunggakanStatus($filter)
        ];
        
        return view('admin/laporan_tunggakan', $data);
    }

    public function print_tunggakan()
    {
        $filter = [
            'kelas' => $this->request->getGet('kelas'),
            'bulan' => $this->request->getGet('bulan'),
            'tahun' => $this->request->getGet('tahun'),
            'status' => $this->request->getGet('status')
        ];
        
        $data = [
            'title' => 'Laporan Tunggakan',
            'tunggakan' => $this->pembayaranModel->getTunggakan($filter),
            'summary' => $this->pembayaranModel->getTunggakanSummary($filter)
        ];
        
        return view('admin/print_tunggakan', $data);
    }

    public function export_tunggakan()
    {
        $filter = [
            'kelas' => $this->request->getGet('kelas'),
            'bulan' => $this->request->getGet('bulan'),
            'tahun' => $this->request->getGet('tahun'),
            'status' => $this->request->getGet('status'),
            'format' => $this->request->getGet('format') ?? 'excel'
        ];
        
        $tunggakan = $this->pembayaranModel->getTunggakan($filter);
        
        switch ($filter['format']) {
            case 'excel':
                return $this->exportToExcel($tunggakan, "Laporan_Tunggakan");
            case 'pdf':
                return $this->exportToPDF($tunggakan, "Laporan_Tunggakan");
            case 'csv':
                return $this->exportToCSV($tunggakan, "Laporan_Tunggakan");
            default:
                return redirect()->to('/admin/laporan_tunggakan');
        }
    }

    public function send_reminder()
    {
        $filter = $this->request->getPost('filter');
        $tunggakan = $this->pembayaranModel->getTunggakan(json_decode($filter, true));
        
        $sent = 0;
        $failed = 0;
        
        foreach ($tunggakan as $t) {
            // Send email/WA reminder logic here
            // This is just a placeholder
            if ($this->sendEmailReminder($t)) {
                $sent++;
            } else {
                $failed++;
            }
        }
        
        $this->logModel->createLog(session()->get('id'), 'reminder', "Mengirim {$sent} pengingat pembayaran");
        
        return $this->response->setJSON([
            'success' => true,
            'message' => "Berhasil mengirim {$sent} pengingat, gagal {$failed}",
            'sent' => $sent,
            'failed' => $failed
        ]);
    }

    // ========================= NOTIFIKASI =========================
    public function notifikasi()
    {
        $data = [
            'title' => 'Pengaturan Notifikasi',
            'notification_settings' => $this->settingModel->getNotificationSettings()
        ];
        
        return view('admin/notifikasi', $data);
    }

    public function update_notifications()
    {
        $post = $this->request->getPost();
        
        try {
            $result = $this->settingModel->saveNotificationSettings($post);
            
            if ($result) {
                $this->logModel->createLog(session()->get('id'), 'settings', 'Mengubah pengaturan notifikasi');
                session()->setFlashdata('success', 'Pengaturan notifikasi berhasil disimpan');
            } else {
                session()->setFlashdata('error', 'Gagal menyimpan pengaturan notifikasi');
            }
        } catch (\Exception $e) {
            session()->setFlashdata('error', 'Error: ' . $e->getMessage());
        }
        
        return redirect()->to('/admin/notifikasi');
    }

    // ========================= ACTIVITY LOG =========================
    public function activity_log()
    {
        $page = $this->request->getGet('page') ?? 1;
        $perPage = 50;
        
        $data = [
            'title' => 'Activity Log',
            'logs' => $this->logModel->getAllLogs($perPage, ($page - 1) * $perPage),
            'pager' => $this->logModel->pager,
            'log_types' => $this->logModel->getLogTypes(),
            'users' => $this->userModel->findAll()
        ];
        
        return view('admin/activity_log', $data);
    }

    public function clear_logs()
    {
        $days = $this->request->getGet('days') ?? 30;
        
        try {
            $deleted = $this->logModel->clearOldLogs($days);
            $this->logModel->createLog(session()->get('id'), 'maintenance', "Membersihkan {$deleted} log lebih dari {$days} hari");
            
            session()->setFlashdata('success', "Berhasil menghapus {$deleted} log");
        } catch (\Exception $e) {
            session()->setFlashdata('error', 'Error: ' . $e->getMessage());
        }
        
        return redirect()->to('/admin/activity_log');
    }

    // ========================= LAPORAN KEUANGAN =========================
    public function laporan_keuangan()
    {
        $startDate = $this->request->getGet('start_date') ?? date('Y-m-01');
        $endDate = $this->request->getGet('end_date') ?? date('Y-m-t');
        
        $data = [
            'title' => 'Laporan Keuangan',
            'start_date' => $startDate,
            'end_date' => $endDate,
            'summary' => $this->pembayaranModel->getFinancialSummary($startDate, $endDate),
            'monthly_data' => $this->pembayaranModel->getMonthlyFinancialData(date('Y')),
            'top_payers' => $this->pembayaranModel->getTopPayers($startDate, $endDate),
            'payment_methods' => $this->pembayaranModel->getPaymentMethodStats($startDate, $endDate)
        ];
        
        return view('admin/laporan_keuangan', $data);
    }

    public function export_keuangan($format)
    {
        $startDate = $this->request->getGet('start_date') ?? date('Y-m-01');
        $endDate = $this->request->getGet('end_date') ?? date('Y-m-t');
        
        $data = $this->pembayaranModel->getFinancialSummary($startDate, $endDate);
        
        switch ($format) {
            case 'excel':
                return $this->exportToExcel($data, "Laporan_Keuangan_{$startDate}_to_{$endDate}");
            case 'pdf':
                return $this->exportToPDF($data, "Laporan_Keuangan_{$startDate}_to_{$endDate}");
            default:
                return redirect()->to('/admin/laporan_keuangan');
        }
    }

    // ========================= HELPER METHODS =========================
    private function getMonthName($month)
    {
        $months = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret',
            4 => 'April', 5 => 'Mei', 6 => 'Juni',
            7 => 'Juli', 8 => 'Agustus', 9 => 'September',
            10 => 'Oktober', 11 => 'November', 12 => 'Desember'
        ];
        
        return $months[$month] ?? '';
    }

    private function sendEmailReminder($data)
    {
        // Placeholder for email sending logic
        // In real implementation, use email library
        return true;
    }

    private function exportToExcel($data, $filename)
    {
        // Placeholder for Excel export
        // In real implementation, use PHPExcel or PhpSpreadsheet
        return "Excel export for {$filename}";
    }

    private function exportToPDF($data, $filename)
    {
        // Placeholder for PDF export
        // In real implementation, use DomPDF or TCPDF
        return "PDF export for {$filename}";
    }

    private function exportToCSV($data, $filename)
    {
        // Placeholder for CSV export
        return "CSV export for {$filename}";
    }

    private function exportToPrint($data)
    {
        // Placeholder for print view
        return view('admin/print_template', $data);
    }
}