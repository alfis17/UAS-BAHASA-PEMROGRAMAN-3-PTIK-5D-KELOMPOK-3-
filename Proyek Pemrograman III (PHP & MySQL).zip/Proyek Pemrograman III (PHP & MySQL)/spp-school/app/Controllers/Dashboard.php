<?php

namespace App\Controllers;

use App\Models\SiswaModel;
use App\Models\KelasModel;
use App\Models\PembayaranModel;
use CodeIgniter\Controller;

class Dashboard extends BaseController
{
    protected $siswaModel;
    protected $kelasModel;
    protected $pembayaranModel;
    
    public function __construct()
    {
        $this->siswaModel = new SiswaModel();
        $this->kelasModel = new KelasModel();
        $this->pembayaranModel = new PembayaranModel();
        
        // Cek login
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }
        
        // Jika siswa login, redirect ke dashboard siswa
        if (session()->get('role') === 'siswa') {
            return redirect()->to('siswa/dashboard_siswa');
        }
    }

    public function index()
    {
        // Hanya admin/petugas yang bisa akses
        if (!in_array(session()->get('role'), ['admin', 'petugas'])) {
            return redirect()->to('admin/dashboard_admin');
        }
        
        $data = [
            'title' => 'Dashboard Admin - Sistem SPP',
            'total_siswa' => $this->siswaModel->countAll(),
            'total_kelas' => $this->kelasModel->countAll(),
            'recent_pembayaran' => $this->pembayaranModel->getPembayaranWithDetails(),
            'chart_data' => $this->getChartData(),
            'user' => session()->get()
        ];
        
        return view('admin/dashboard_admin', $data);
    }

    private function getChartData()
    {
        $bulan = [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        
        $currentYear = date('Y');
        $chartData = [];
        
        foreach ($bulan as $b) {
            $builder = $this->pembayaranModel->where('bulan', $b)->where('tahun', $currentYear);
            $total = $builder->selectSum('jumlah_bayar')->get()->getRow();
            $chartData[] = $total->jumlah_bayar ?? 0;
        }
        
        return [
            'labels' => $bulan,
            'data' => $chartData,
            'currentYear' => $currentYear
        ];
    }
}
